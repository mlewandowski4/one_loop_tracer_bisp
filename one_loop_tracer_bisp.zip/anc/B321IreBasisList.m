(* Created with the Wolfram Language : www.wolfram.com *)
{-1/441*(144*f1^3*dot[k1, hat[z]]^4*dot[k2, hat[z]]^2*magM[k2]^2*magM[k3]^2 + 
    72*f1^2*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*magM[k3]^2*
     (4*f1*dot[k2, hat[z]]^2 - magM[k1]^2 - magM[k2]^2 + magM[k3]^2) + 
    6*f1^2*dot[k2, hat[z]]^4*(magM[k2]^2 + magM[k3]^2)*
     (magM[k1]^4 + (magM[k2]^2 - magM[k3]^2)^2 - 
      2*magM[k1]^2*(magM[k2]^2 + magM[k3]^2)) + magM[k2]^2*magM[k3]^2*
     (7*magM[k1]^4*(magM[k2]^2 + magM[k3]^2) + 7*(magM[k2]^2 - magM[k3]^2)^2*
       (magM[k2]^2 + magM[k3]^2) - 2*magM[k1]^2*(7*magM[k2]^4 - 
        4*magM[k2]^2*magM[k3]^2 + 7*magM[k3]^4)) + 
    f1*dot[k2, hat[z]]^2*(magM[k1]^4*(3*magM[k2]^4 + 
        28*magM[k2]^2*magM[k3]^2 + 3*magM[k3]^4) + 
      (magM[k2]^2 - magM[k3]^2)^2*(3*magM[k2]^4 + 28*magM[k2]^2*magM[k3]^2 + 
        3*magM[k3]^4) - 2*magM[k1]^2*(3*magM[k2]^6 + 
        13*magM[k2]^4*magM[k3]^2 + 13*magM[k2]^2*magM[k3]^4 + 
        3*magM[k3]^6)) + 2*f1*dot[k1, hat[z]]*dot[k2, hat[z]]*
     (6*f1*dot[k2, hat[z]]^2*(magM[k2]^6 - 13*magM[k2]^4*magM[k3]^2 + 
        11*magM[k2]^2*magM[k3]^4 + magM[k3]^6 + magM[k1]^4*
         (magM[k2]^2 + magM[k3]^2) - 2*magM[k1]^2*(magM[k2]^2 + magM[k3]^2)^
          2) + magM[k2]^2*(3*magM[k2]^6 - 10*magM[k2]^4*magM[k3]^2 - 
        25*magM[k2]^2*magM[k3]^4 + 32*magM[k3]^6 + 
        magM[k1]^4*(3*magM[k2]^2 + 14*magM[k3]^2) + 
        magM[k1]^2*(-6*magM[k2]^4 + 20*magM[k2]^2*magM[k3]^2 - 
          46*magM[k3]^4))) + f1*dot[k1, hat[z]]^2*
     (144*f1^2*dot[k2, hat[z]]^4*magM[k2]^2*magM[k3]^2 + 
      magM[k2]^2*(3*magM[k2]^6 - 28*magM[k2]^4*magM[k3]^2 - 
        25*magM[k2]^2*magM[k3]^4 + 14*magM[k3]^6 + 
        magM[k1]^4*(3*magM[k2]^2 + 14*magM[k3]^2) + 
        magM[k1]^2*(-6*magM[k2]^4 + 38*magM[k2]^2*magM[k3]^2 - 
          28*magM[k3]^4)) + 6*f1*dot[k2, hat[z]]^2*
       (magM[k2]^6 - 37*magM[k2]^4*magM[k3]^2 + 35*magM[k2]^2*magM[k3]^4 + 
        magM[k3]^6 + magM[k1]^4*(magM[k2]^2 + magM[k3]^2) - 
        2*magM[k1]^2*(magM[k2]^4 + 8*magM[k2]^2*magM[k3]^2 + magM[k3]^4))))/
   (knl^4*magM[k1]^2*magM[k2]^2*magM[k3]^2), 
 -1/22050*(5436*f1^3*dot[k1, hat[z]]^4*dot[k2, hat[z]]^2*magM[k2]^2*
     magM[k3]^2 + 3*f1^2*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*
     (-125*magM[k1]^4 - 27*magM[k2]^4 + 3624*f1*dot[k2, hat[z]]^2*
       magM[k3]^2 - 4*(349 + 147*f1)*magM[k2]^2*magM[k3]^2 + 
      1087*magM[k3]^4 + 2*magM[k1]^2*(76*magM[k2]^2 - 481*magM[k3]^2)) + 
    25*magM[k2]^2*magM[k3]^2*(7*magM[k1]^6 + 14*(magM[k2]^2 - magM[k3]^2)^2*
       (magM[k2]^2 + magM[k3]^2) + magM[k1]^2*(-21*magM[k2]^4 + 
        2*magM[k2]^2*magM[k3]^2 - 21*magM[k3]^4)) + 
    3*f1^2*dot[k2, hat[z]]^4*(15*magM[k1]^6 - 69*magM[k1]^4*
       (magM[k2]^2 + magM[k3]^2) + 59*(magM[k2]^2 - magM[k3]^2)^2*
       (magM[k2]^2 + magM[k3]^2) - magM[k1]^2*(5*magM[k2]^4 + 
        1042*magM[k2]^2*magM[k3]^2 + 5*magM[k3]^4)) + 
    f1*dot[k2, hat[z]]^2*(90*magM[k1]^6*(magM[k2]^2 + magM[k3]^2) - 
      3*magM[k1]^4*(15*magM[k2]^4 + 2*(86 + 105*f1)*magM[k2]^2*magM[k3]^2 + 
        15*magM[k3]^4) - 2*magM[k1]^2*(magM[k2]^2 + magM[k3]^2)*
       (90*magM[k2]^4 + (620 - 189*f1)*magM[k2]^2*magM[k3]^2 + 
        90*magM[k3]^4) + (magM[k2]^2 - magM[k3]^2)^2*(135*magM[k2]^4 + 
        4*(304 + 63*f1)*magM[k2]^2*magM[k3]^2 + 135*magM[k3]^4)) + 
    f1*dot[k1, hat[z]]^2*(5436*f1^2*dot[k2, hat[z]]^4*magM[k2]^2*magM[k3]^2 - 
      3*f1*dot[k2, hat[z]]^2*(-15*magM[k1]^6 - 5*magM[k2]^6 + 
        2*(1969 + 588*f1)*magM[k2]^4*magM[k3]^2 - (3511 + 588*f1)*magM[k2]^2*
         magM[k3]^4 - 86*magM[k3]^6 + magM[k1]^4*(319*magM[k2]^2 - 
          56*magM[k3]^2) + magM[k1]^2*(-299*magM[k2]^4 + 
          2004*magM[k2]^2*magM[k3]^2 + 157*magM[k3]^4)) + 
      magM[k2]^2*(90*magM[k1]^6 + 135*magM[k2]^6 - 1667*magM[k2]^4*
         magM[k3]^2 - 885*magM[k2]^2*magM[k3]^4 + 617*magM[k3]^6 + 
        magM[k1]^4*(-45*magM[k2]^2 + 437*magM[k3]^2) - 
        2*magM[k1]^2*(90*magM[k2]^4 - 165*magM[k2]^2*magM[k3]^2 + 
          572*magM[k3]^4))) + f1*dot[k1, hat[z]]*dot[k2, hat[z]]*
     (-3*f1*dot[k2, hat[z]]^2*(-30*magM[k1]^6 + magM[k1]^4*
         (263*magM[k2]^2 + 13*magM[k3]^2) - (magM[k2]^2 - magM[k3]^2)*
         (91*magM[k2]^4 - 2*(1255 + 294*f1)*magM[k2]^2*magM[k3]^2 - 
          145*magM[k3]^4) + magM[k1]^2*(-142*magM[k2]^4 + 
          2084*magM[k2]^2*magM[k3]^2 + 162*magM[k3]^4)) + 
      2*magM[k2]^2*(90*magM[k1]^6 - 3*magM[k1]^4*(15*magM[k2]^2 + 
          (86 + 105*f1)*magM[k3]^2) + (magM[k2]^2 - magM[k3]^2)*
         (135*magM[k2]^4 + 6*(-89 + 21*f1)*magM[k2]^2*magM[k3]^2 - 
          (1615 + 126*f1)*magM[k3]^4) + magM[k1]^2*(-180*magM[k2]^4 + 
          27*(1 + 7*f1)*magM[k2]^2*magM[k3]^2 + (-1447 + 189*f1)*
           magM[k3]^4))))/(knl^4*magM[k1]^2*magM[k2]^2*magM[k3]^2), 
 -1/252*(f1^2*(-36*f1*dot[k1, hat[z]]^4*magM[k2]^4*magM[k3]^2 - 
     36*f1*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*magM[k3]^2*
      (magM[k1]^2 + 3*magM[k2]^2 - magM[k3]^2) + 2*dot[k2, hat[z]]^2*
      magM[k2]^2*magM[k3]^2*(7*magM[k1]^4 + 7*(magM[k2]^2 - magM[k3]^2)^2 + 
       4*magM[k1]^2*(magM[k2]^2 + magM[k3]^2)) + 3*f1*dot[k2, hat[z]]^4*
      (magM[k1]^4*(magM[k2]^2 + magM[k3]^2) + (magM[k2]^2 - magM[k3]^2)^2*
        (magM[k2]^2 + magM[k3]^2) - 2*magM[k1]^2*(magM[k2]^4 - 
         10*magM[k2]^2*magM[k3]^2 + magM[k3]^4)) + 
     2*dot[k1, hat[z]]*(dot[k2, hat[z]]*magM[k2]^2*magM[k3]^2*
        (7*magM[k1]^4 + 2*magM[k1]^2*(11*magM[k2]^2 - 7*magM[k3]^2) + 
         7*(magM[k2]^2 - magM[k3]^2)^2) + 3*f1*dot[k2, hat[z]]^3*
        (magM[k2]^6 - 13*magM[k2]^4*magM[k3]^2 + 11*magM[k2]^2*magM[k3]^4 + 
         magM[k3]^6 + magM[k1]^4*(magM[k2]^2 + magM[k3]^2) - 
         2*magM[k1]^2*(magM[k2]^4 - 10*magM[k2]^2*magM[k3]^2 + 
           magM[k3]^4))) + dot[k1, hat[z]]^2*
      (magM[k2]^2*magM[k3]^2*(7*magM[k1]^4 + 2*magM[k1]^2*
          (11*magM[k2]^2 - 7*magM[k3]^2) + 7*(magM[k2]^2 - magM[k3]^2)^2) + 
       3*f1*dot[k2, hat[z]]^2*(magM[k2]^6 - 49*magM[k2]^4*magM[k3]^2 + 
         23*magM[k2]^2*magM[k3]^4 + magM[k3]^6 + magM[k1]^4*
          (magM[k2]^2 + magM[k3]^2) - 2*magM[k1]^2*(magM[k2]^4 - 
           4*magM[k2]^2*magM[k3]^2 + magM[k3]^4)))))/
   (knl^4*magM[k1]^2*magM[k2]^2*magM[k3]^2), 
 -1/1260*(f1^2*(108*f1^2*dot[k1, hat[z]]^6*dot[k2, hat[z]]^2*magM[k2]^2 + 
     108*f1*dot[k1, hat[z]]^5*dot[k2, hat[z]]*magM[k2]^2*
      (6*f1*dot[k2, hat[z]]^2 - magM[k1]^2 + magM[k3]^2) + 
     dot[k2, hat[z]]^4*(21*magM[k1]^4*(magM[k2]^2 + magM[k3]^2) - 
       6*(magM[k2]^2 - magM[k3]^2)^2*(magM[k2]^2 + magM[k3]^2) - 
       5*magM[k1]^2*(3*magM[k2]^4 - 2*(11 + 36*f1)*magM[k2]^2*magM[k3]^2 + 
         3*magM[k3]^4) + 6*f1*dot[k2, hat[z]]^2*(3*magM[k1]^4 - 
         6*(magM[k2]^2 - magM[k3]^2)^2 - 10*magM[k1]^2*(magM[k2]^2 + 
           magM[k3]^2))) + 3*dot[k1, hat[z]]^4*
      (36*f1^2*dot[k2, hat[z]]^4*(14*magM[k2]^2 - magM[k3]^2) + 
       f1*dot[k2, hat[z]]^2*(3*magM[k1]^4 - 19*magM[k2]^4 + 
         124*magM[k2]^2*magM[k3]^2 + 3*magM[k3]^4 - 2*magM[k1]^2*
          (77*magM[k2]^2 + 3*magM[k3]^2)) - magM[k2]^2*
        (-7*magM[k1]^4 + 2*magM[k2]^4 + 5*magM[k2]^2*magM[k3]^2 - 
         7*magM[k3]^4 + magM[k1]^2*(5*magM[k2]^2 + 14*magM[k3]^2))) + 
     4*dot[k1, hat[z]]^3*(108*f1^2*dot[k2, hat[z]]^5*(4*magM[k2]^2 - 
         magM[k3]^2) + 3*f1*dot[k2, hat[z]]^3*(3*magM[k1]^4 - 18*magM[k2]^4 + 
         50*magM[k2]^2*magM[k3]^2 + 4*magM[k3]^4 - magM[k1]^2*
          (65*magM[k2]^2 + 7*magM[k3]^2)) - dot[k2, hat[z]]*magM[k2]^2*
        (-21*magM[k1]^4 + (magM[k2]^2 - magM[k3]^2)*(6*magM[k2]^2 + 
           (28 + 9*f1)*magM[k3]^2) + magM[k1]^2*(15*magM[k2]^2 + 
           (49 + 9*f1)*magM[k3]^2))) + 2*dot[k1, hat[z]]*
      (108*f1^2*dot[k2, hat[z]]^7*(magM[k2]^2 - magM[k3]^2) + 
       3*f1*dot[k2, hat[z]]^5*(9*magM[k1]^4 - 29*magM[k2]^4 + 
         36*magM[k2]^2*magM[k3]^2 - 7*magM[k3]^4 - 10*magM[k1]^2*
          (5*magM[k2]^2 + magM[k3]^2)) + 2*dot[k2, hat[z]]^3*magM[k2]^2*
        (21*magM[k1]^4 - (magM[k2]^2 - magM[k3]^2)*(6*magM[k2]^2 + 
           (35 + 18*f1)*magM[k3]^2) + 5*magM[k1]^2*(-3*magM[k2]^2 + 
           (11 + 36*f1)*magM[k3]^2))) + dot[k1, hat[z]]^2*
      (108*f1^2*dot[k2, hat[z]]^6*(9*magM[k2]^2 - 5*magM[k3]^2) + 
       3*f1*dot[k2, hat[z]]^4*(21*magM[k1]^4 - 99*magM[k2]^4 + 
         160*magM[k2]^2*magM[k3]^2 + 11*magM[k3]^4 - 2*magM[k1]^2*
          (111*magM[k2]^2 + 11*magM[k3]^2)) + 2*dot[k2, hat[z]]^2*magM[k2]^2*
        (63*magM[k1]^4 - 3*(magM[k2]^2 - magM[k3]^2)*(6*magM[k2]^2 + 
           (35 + 18*f1)*magM[k3]^2) + magM[k1]^2*(-45*magM[k2]^2 + 
           (-43 + 162*f1)*magM[k3]^2)))))/(knl^4*magM[k1]^2*magM[k2]^2*
    magM[k3]^2), (f1^4*dot[k2, hat[z]]^2*(dot[k1, hat[z]] + dot[k2, hat[z]])^
    2*(f1*dot[k1, hat[z]]^2 - magM[k1]^2))/(4*knl^4*magM[k1]^2), 
 (2*(12*f1^2*dot[k2, hat[z]]^4 + f1*dot[k1, hat[z]]^2*
     (12*f1*dot[k2, hat[z]]^2 + 5*magM[k2]^2) + 2*f1*dot[k1, hat[z]]*
     dot[k2, hat[z]]*(12*f1*dot[k2, hat[z]]^2 + 5*magM[k2]^2) + 
    2*magM[k2]^2*magM[k3]^2 + 5*f1*dot[k2, hat[z]]^2*
     (magM[k2]^2 + magM[k3]^2)))/(63*knl^4), 
 (-72*f1^2*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*magM[k3]^2*
    (magM[k1]^2 + magM[k2]^2 - magM[k3]^2) + 6*f1^2*dot[k2, hat[z]]^4*
    (-2*magM[k1]^2*(magM[k2]^2 - magM[k3]^2)^2 + 
     magM[k1]^4*(magM[k2]^2 + magM[k3]^2) + (magM[k2]^2 - magM[k3]^2)^2*
      (magM[k2]^2 + magM[k3]^2)) + 7*magM[k2]^2*magM[k3]^2*
    (-2*magM[k1]^2*(magM[k2]^2 - magM[k3]^2)^2 + 
     magM[k1]^4*(magM[k2]^2 + magM[k3]^2) + (magM[k2]^2 - magM[k3]^2)^2*
      (magM[k2]^2 + magM[k3]^2)) + f1*dot[k2, hat[z]]^2*
    (-6*magM[k1]^2*(magM[k2]^2 - magM[k3]^2)^2*(magM[k2]^2 + magM[k3]^2) + 
     magM[k1]^4*(3*magM[k2]^4 + 28*magM[k2]^2*magM[k3]^2 + 3*magM[k3]^4) + 
     (magM[k2]^2 - magM[k3]^2)^2*(3*magM[k2]^4 + 28*magM[k2]^2*magM[k3]^2 + 
       3*magM[k3]^4)) + 2*f1*dot[k1, hat[z]]*dot[k2, hat[z]]*
    (6*f1*dot[k2, hat[z]]^2*(magM[k2]^6 - 13*magM[k2]^4*magM[k3]^2 + 
       11*magM[k2]^2*magM[k3]^4 + magM[k3]^6 - 2*magM[k1]^2*
        (magM[k2]^2 - magM[k3]^2)^2 + magM[k1]^4*(magM[k2]^2 + magM[k3]^2)) + 
     magM[k2]^2*(3*magM[k2]^6 - 10*magM[k2]^4*magM[k3]^2 - 
       25*magM[k2]^2*magM[k3]^4 + 32*magM[k3]^6 + 
       magM[k1]^4*(3*magM[k2]^2 + 14*magM[k3]^2) + 
       magM[k1]^2*(-6*magM[k2]^4 + 52*magM[k2]^2*magM[k3]^2 - 
         46*magM[k3]^4))) + f1*dot[k1, hat[z]]^2*
    (magM[k2]^2*(3*magM[k2]^6 - 28*magM[k2]^4*magM[k3]^2 + 
       11*magM[k2]^2*magM[k3]^4 + 14*magM[k3]^6 + 
       magM[k1]^4*(3*magM[k2]^2 + 14*magM[k3]^2) + 
       magM[k1]^2*(-6*magM[k2]^4 + 70*magM[k2]^2*magM[k3]^2 - 
         28*magM[k3]^4)) + 6*f1*dot[k2, hat[z]]^2*
      (magM[k2]^6 - 37*magM[k2]^4*magM[k3]^2 + 35*magM[k2]^2*magM[k3]^4 + 
       magM[k3]^6 + magM[k1]^4*(magM[k2]^2 + magM[k3]^2) - 
       2*magM[k1]^2*(magM[k2]^4 + 4*magM[k2]^2*magM[k3]^2 + magM[k3]^4))))/
  (882*knl^4*magM[k1]^2*magM[k2]^2*magM[k3]^2), 
 (75*f1^2*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*
    (-magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 35*magM[k2]^2*magM[k3]^2*
    (-magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2 - 2*f1*dot[k2, hat[z]]^2*
    (magM[k1]^2 - magM[k2]^2 - magM[k3]^2)*(9*magM[k2]^4 + 
     (157 + 63*f1)*magM[k2]^2*magM[k3]^2 + 9*magM[k3]^4 - 
     9*magM[k1]^2*(magM[k2]^2 + magM[k3]^2)) + 3*f1^2*dot[k2, hat[z]]^4*
    (3*magM[k1]^4 - 31*magM[k1]^2*(magM[k2]^2 + magM[k3]^2) + 
     28*(magM[k2]^4 + 5*magM[k2]^2*magM[k3]^2 + magM[k3]^4)) + 
   9*f1*dot[k1, hat[z]]^2*
    (2*magM[k2]^2*(-magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2 + 
     f1*dot[k2, hat[z]]^2*(magM[k1]^4 + 26*magM[k2]^4 + 
       55*magM[k2]^2*magM[k3]^2 + magM[k3]^4 - 
       magM[k1]^2*(27*magM[k2]^2 + 2*magM[k3]^2))) + 
   f1*dot[k1, hat[z]]*dot[k2, hat[z]]*
    (2*magM[k2]^2*(-magM[k1]^2 + magM[k2]^2 + magM[k3]^2)*
      (-18*magM[k1]^2 + 18*magM[k2]^2 + (157 + 63*f1)*magM[k3]^2) + 
     3*f1*dot[k2, hat[z]]^2*(6*magM[k1]^4 + 81*magM[k2]^4 + 
       280*magM[k2]^2*magM[k3]^2 + 31*magM[k3]^4 - 
       magM[k1]^2*(87*magM[k2]^2 + 37*magM[k3]^2))))/
  (2205*knl^4*magM[k2]^2*magM[k3]^2), 
 (6*f1^2*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*
    (-25*magM[k1]^2 + 25*magM[k2]^2 - 109*magM[k3]^2)*
    (magM[k1]^2 - magM[k3]^2) + (magM[k1]^4 - (magM[k2]^2 - magM[k3]^2)^2)*
    (-70*magM[k2]^2*magM[k3]^2*(-magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
     3*f1^2*dot[k2, hat[z]]^4*(6*magM[k1]^2 - 31*(magM[k2]^2 + magM[k3]^2)) - 
     2*f1*dot[k2, hat[z]]^2*(18*magM[k2]^4 + 7*(25 + 9*f1)*magM[k2]^2*
        magM[k3]^2 + 18*magM[k3]^4 - 18*magM[k1]^2*(magM[k2]^2 + 
         magM[k3]^2))) + f1*dot[k1, hat[z]]^2*
    (magM[k2]^2*(36*magM[k1]^6 + 36*magM[k2]^6 - 175*magM[k2]^4*magM[k3]^2 - 
       36*magM[k2]^2*magM[k3]^4 + 175*magM[k3]^6 + 
       magM[k1]^4*(-36*magM[k2]^2 + 103*magM[k3]^2) + 
       magM[k1]^2*(-36*magM[k2]^4 + 72*magM[k2]^2*magM[k3]^2 - 
         314*magM[k3]^4)) + 3*f1*dot[k2, hat[z]]^2*
      (6*magM[k1]^6 + 31*magM[k2]^6 - 349*magM[k2]^4*magM[k3]^2 + 
       455*magM[k2]^2*magM[k3]^4 + 31*magM[k3]^6 + 
       magM[k1]^4*(-131*magM[k2]^2 + 19*magM[k3]^2) + 
       2*magM[k1]^2*(47*magM[k2]^4 - 78*magM[k2]^2*magM[k3]^2 - 
         28*magM[k3]^4))) + 2*f1*dot[k1, hat[z]]*dot[k2, hat[z]]*
    (3*f1*dot[k2, hat[z]]^2*(6*magM[k1]^6 + 31*magM[k2]^6 - 
       165*magM[k2]^4*magM[k3]^2 + 103*magM[k2]^2*magM[k3]^4 + 
       31*magM[k3]^6 - 2*magM[k1]^4*(28*magM[k2]^2 + 3*magM[k3]^2) + 
       magM[k1]^2*(19*magM[k2]^4 + 12*magM[k2]^2*magM[k3]^2 - 
         31*magM[k3]^4)) + magM[k2]^2*(36*magM[k1]^6 - 
       magM[k1]^4*(36*magM[k2]^2 + 7*(25 + 9*f1)*magM[k3]^2) + 
       magM[k1]^2*(-36*magM[k2]^4 + 211*magM[k2]^2*magM[k3]^2 - 
         175*magM[k3]^4) + (magM[k2]^2 - magM[k3]^2)*(36*magM[k2]^4 + 
         63*f1*magM[k2]^2*magM[k3]^2 - (314 + 63*f1)*magM[k3]^4))))/
  (8820*knl^4*magM[k1]^2*magM[k2]^2*magM[k3]^2), 
 (-42*f1^2*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*magM[k3]^2*
    (magM[k1]^2 + magM[k2]^2 - magM[k3]^2) + 9*f1^2*dot[k2, hat[z]]^4*
    (-2*magM[k1]^2*(magM[k2]^2 - magM[k3]^2)^2 + 
     magM[k1]^4*(magM[k2]^2 + magM[k3]^2) + (magM[k2]^2 - magM[k3]^2)^2*
      (magM[k2]^2 + magM[k3]^2)) + 5*magM[k2]^2*magM[k3]^2*
    (-2*magM[k1]^2*(magM[k2]^2 - magM[k3]^2)^2 + 
     magM[k1]^4*(magM[k2]^2 + magM[k3]^2) + (magM[k2]^2 - magM[k3]^2)^2*
      (magM[k2]^2 + magM[k3]^2)) + 3*f1*dot[k2, hat[z]]^2*
    (-2*magM[k1]^2*(magM[k2]^2 - magM[k3]^2)^2*(magM[k2]^2 + magM[k3]^2) + 
     magM[k1]^4*(magM[k2]^4 + 10*magM[k2]^2*magM[k3]^2 + magM[k3]^4) + 
     (magM[k2]^2 - magM[k3]^2)^2*(magM[k2]^4 + 10*magM[k2]^2*magM[k3]^2 + 
       magM[k3]^4)) + 2*f1*dot[k1, hat[z]]*dot[k2, hat[z]]*
    (3*f1*dot[k2, hat[z]]^2*(3*magM[k2]^6 - 17*magM[k2]^4*magM[k3]^2 + 
       11*magM[k2]^2*magM[k3]^4 + 3*magM[k3]^6 - 6*magM[k1]^2*
        (magM[k2]^2 - magM[k3]^2)^2 + 3*magM[k1]^4*(magM[k2]^2 + 
         magM[k3]^2)) + magM[k2]^2*(3*magM[k2]^6 + 2*magM[k2]^4*magM[k3]^2 - 
       27*magM[k2]^2*magM[k3]^4 + 22*magM[k3]^6 + 
       3*magM[k1]^4*(magM[k2]^2 + 5*magM[k3]^2) + 
       magM[k1]^2*(-6*magM[k2]^4 + 43*magM[k2]^2*magM[k3]^2 - 
         37*magM[k3]^4))) + f1*dot[k1, hat[z]]^2*
    (magM[k2]^2*(3*magM[k2]^6 - 5*magM[k2]^4*magM[k3]^2 - 
       13*magM[k2]^2*magM[k3]^4 + 15*magM[k3]^6 + 
       3*magM[k1]^4*(magM[k2]^2 + 5*magM[k3]^2) + 
       magM[k1]^2*(-6*magM[k2]^4 + 50*magM[k2]^2*magM[k3]^2 - 
         30*magM[k3]^4)) + 3*f1*dot[k2, hat[z]]^2*
      (3*magM[k1]^4*(magM[k2]^2 + magM[k3]^2) - 2*magM[k1]^2*
        (3*magM[k2]^4 + magM[k2]^2*magM[k3]^2 + 3*magM[k3]^4) + 
       3*(magM[k2]^6 - 15*magM[k2]^4*magM[k3]^2 + 13*magM[k2]^2*magM[k3]^4 + 
         magM[k3]^6))))/(630*knl^4*magM[k1]^2*magM[k2]^2*magM[k3]^2), 
 (f1^2*(dot[k1, hat[z]]^2*(4*f1*dot[k2, hat[z]]^2 + magM[k2]^2) + 
    2*dot[k1, hat[z]]*dot[k2, hat[z]]*(4*f1*dot[k2, hat[z]]^2 + magM[k2]^2) + 
    dot[k2, hat[z]]^2*(4*f1*dot[k2, hat[z]]^2 + magM[k2]^2 + magM[k3]^2)))/
  (7*knl^4), (f1^2*dot[k1, hat[z]]^2*
   (dot[k1, hat[z]]^2*(4*f1*dot[k2, hat[z]]^2 + magM[k2]^2) + 
    2*dot[k1, hat[z]]*dot[k2, hat[z]]*(4*f1*dot[k2, hat[z]]^2 + magM[k2]^2) + 
    dot[k2, hat[z]]^2*(4*f1*dot[k2, hat[z]]^2 + magM[k2]^2 + magM[k3]^2)))/
  (7*knl^4*magM[k1]^2), (f1^2*dot[k2, hat[z]]^2*
   (dot[k1, hat[z]] + dot[k2, hat[z]])^2*(3*f1*dot[k1, hat[z]]^2*magM[k2]^2 + 
    6*f1*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2 + 
    2*(5 + 7*f1)*magM[k2]^2*magM[k3]^2 + 3*f1*dot[k2, hat[z]]^2*
     (magM[k2]^2 + magM[k3]^2)))/(35*knl^4*magM[k2]^2*magM[k3]^2), 
 (f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]*(dot[k1, hat[z]] + dot[k2, hat[z]])*
   (2*f1*dot[k1, hat[z]]^2*dot[k2, hat[z]]*magM[k2]^2*
     (3*magM[k1]^2 - 3*magM[k2]^2 + 17*magM[k3]^2) - 
    2*dot[k2, hat[z]]*(magM[k2]^2 - magM[k3]^2)*
     ((10 + 7*f1)*magM[k2]^2*magM[k3]^2 + 3*f1*dot[k2, hat[z]]^2*
       (-magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
    dot[k1, hat[z]]*(-((10 + 7*f1)*magM[k2]^2*magM[k3]^2*
        (magM[k1]^2 + magM[k2]^2 - magM[k3]^2)) + 2*f1*dot[k2, hat[z]]^2*
       (-6*magM[k2]^4 + 17*magM[k2]^2*magM[k3]^2 + 3*magM[k3]^4 + 
        magM[k1]^2*(6*magM[k2]^2 - 3*magM[k3]^2)))))/
  (140*knl^4*magM[k1]^2*magM[k2]^2*magM[k3]^2), 
 -1/140*(f1^2*(14*f1*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*magM[k3]^2*
      (magM[k1]^2 + magM[k2]^2 - magM[k3]^2) - 10*dot[k2, hat[z]]^2*
      magM[k2]^2*magM[k3]^2*(magM[k1]^4 + (magM[k2]^2 - magM[k3]^2)^2) - 
     3*f1*dot[k2, hat[z]]^4*(-2*magM[k1]^2*(magM[k2]^2 - magM[k3]^2)^2 + 
       magM[k1]^4*(magM[k2]^2 + magM[k3]^2) + (magM[k2]^2 - magM[k3]^2)^2*
        (magM[k2]^2 + magM[k3]^2)) - 2*dot[k1, hat[z]]*
      (5*dot[k2, hat[z]]*magM[k2]^2*magM[k3]^2*
        (magM[k1]^2 + magM[k2]^2 - magM[k3]^2)^2 + f1*dot[k2, hat[z]]^3*
        (3*magM[k2]^6 - 17*magM[k2]^4*magM[k3]^2 + 11*magM[k2]^2*magM[k3]^4 + 
         3*magM[k3]^6 - 6*magM[k1]^2*(magM[k2]^2 - magM[k3]^2)^2 + 
         3*magM[k1]^4*(magM[k2]^2 + magM[k3]^2))) - 
     dot[k1, hat[z]]^2*(5*magM[k2]^2*magM[k3]^2*
        (magM[k1]^2 + magM[k2]^2 - magM[k3]^2)^2 + f1*dot[k2, hat[z]]^2*
        (3*magM[k1]^4*(magM[k2]^2 + magM[k3]^2) - 2*magM[k1]^2*
          (3*magM[k2]^4 + magM[k2]^2*magM[k3]^2 + 3*magM[k3]^4) + 
         3*(magM[k2]^6 - 15*magM[k2]^4*magM[k3]^2 + 13*magM[k2]^2*
            magM[k3]^4 + magM[k3]^6)))))/(knl^4*magM[k1]^2*magM[k2]^2*
    magM[k3]^2), 
 (f1^2*(dot[k1, hat[z]]^2*(6*f1*dot[k2, hat[z]]^2 + magM[k2]^2) + 
    2*dot[k1, hat[z]]*dot[k2, hat[z]]*(6*f1*dot[k2, hat[z]]^2 + magM[k2]^2) + 
    dot[k2, hat[z]]^2*(6*f1*dot[k2, hat[z]]^2 + magM[k2]^2 + magM[k3]^2)))/
  (18*knl^4), (f1^2*(-36*f1*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*
     magM[k3]^2*(magM[k1]^2 + magM[k2]^2 - magM[k3]^2) + 
    14*dot[k2, hat[z]]^2*magM[k2]^2*magM[k3]^2*
     (magM[k1]^4 + (magM[k2]^2 - magM[k3]^2)^2) + 3*f1*dot[k2, hat[z]]^4*
     (-2*magM[k1]^2*(magM[k2]^2 - magM[k3]^2)^2 + 
      magM[k1]^4*(magM[k2]^2 + magM[k3]^2) + (magM[k2]^2 - magM[k3]^2)^2*
       (magM[k2]^2 + magM[k3]^2)) + 2*dot[k1, hat[z]]*
     (7*dot[k2, hat[z]]*magM[k2]^2*magM[k3]^2*
       (magM[k1]^2 + magM[k2]^2 - magM[k3]^2)^2 + 3*f1*dot[k2, hat[z]]^3*
       (magM[k2]^6 - 13*magM[k2]^4*magM[k3]^2 + 11*magM[k2]^2*magM[k3]^4 + 
        magM[k3]^6 - 2*magM[k1]^2*(magM[k2]^2 - magM[k3]^2)^2 + 
        magM[k1]^4*(magM[k2]^2 + magM[k3]^2))) + 
    dot[k1, hat[z]]^2*(7*magM[k2]^2*magM[k3]^2*
       (magM[k1]^2 + magM[k2]^2 - magM[k3]^2)^2 + 3*f1*dot[k2, hat[z]]^2*
       (magM[k2]^6 - 37*magM[k2]^4*magM[k3]^2 + 35*magM[k2]^2*magM[k3]^4 + 
        magM[k3]^6 + magM[k1]^4*(magM[k2]^2 + magM[k3]^2) - 
        2*magM[k1]^2*(magM[k2]^4 + 4*magM[k2]^2*magM[k3]^2 + magM[k3]^4)))))/
  (504*knl^4*magM[k1]^2*magM[k2]^2*magM[k3]^2), 
 (f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]*(dot[k1, hat[z]] + dot[k2, hat[z]])*
   (3*f1*dot[k1, hat[z]]^2*dot[k2, hat[z]]*magM[k2]^2*
     (magM[k1]^2 - magM[k2]^2 + 13*magM[k3]^2) - 
    dot[k2, hat[z]]*(magM[k2]^2 - magM[k3]^2)*
     (2*(7 + 9*f1)*magM[k2]^2*magM[k3]^2 + 3*f1*dot[k2, hat[z]]^2*
       (-magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
    dot[k1, hat[z]]*(-((7 + 9*f1)*magM[k2]^2*magM[k3]^2*
        (magM[k1]^2 + magM[k2]^2 - magM[k3]^2)) + 3*f1*dot[k2, hat[z]]^2*
       (-2*magM[k2]^4 + 13*magM[k2]^2*magM[k3]^2 + magM[k3]^4 + 
        magM[k1]^2*(2*magM[k2]^2 - magM[k3]^2)))))/
  (252*knl^4*magM[k1]^2*magM[k2]^2*magM[k3]^2), 
 (f1^2*dot[k1, hat[z]]^2*(dot[k1, hat[z]]^2*(6*f1*dot[k2, hat[z]]^2 + 
      magM[k2]^2) + 2*dot[k1, hat[z]]*dot[k2, hat[z]]*
     (6*f1*dot[k2, hat[z]]^2 + magM[k2]^2) + dot[k2, hat[z]]^2*
     (6*f1*dot[k2, hat[z]]^2 + magM[k2]^2 + magM[k3]^2)))/
  (18*knl^4*magM[k1]^2)}
