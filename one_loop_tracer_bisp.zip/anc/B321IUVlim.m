(* Created with the Wolfram Language : www.wolfram.com *)
(IntdqP112oq2*(1 + f1*dot[hat[k1], hat[z]]^2)*
  (-4*f1*dot[hat[k1], hat[z]]^2*(-954 + 343*f1*dot[hat[k1], hat[z]]^2 - 
     477*f1*dot[hat[k2], hat[z]]^2 + 147*f1^2*dot[hat[k1], hat[z]]^2*
      dot[hat[k2], hat[z]]^2)*magM[k1]^8 + 4*f1*dot[hat[k1], hat[z]]*
    dot[hat[k2], hat[z]]*(1908 + f1*(-5347*dot[hat[k1], hat[z]]^2 + 
       954*dot[hat[k2], hat[z]]^2) + 588*f1^2*(3*dot[hat[k1], hat[z]]^4 - 
       dot[hat[k1], hat[z]]^2*dot[hat[k2], hat[z]]^2))*magM[k1]^7*magM[k2] + 
   magM[k1]^6*(f1*(-7056*f1^3*dot[hat[k1], hat[z]]^6*dot[hat[k2], hat[z]]^2 + 
       1908*dot[hat[k2], hat[z]]^2*(2 + f1*dot[hat[k2], hat[z]]^2) + 
       20*f1*dot[hat[k1], hat[z]]^4*(49 + 2832*f1*dot[hat[k2], hat[z]]^2) - 
       3*dot[hat[k1], hat[z]]^2*(2693 + 20102*f1*dot[hat[k2], hat[z]]^2 + 
         f1^2*dot[hat[k2], hat[z]]^2*(-45 + 1372*dot[hat[k2], hat[z]]^2)))*
      magM[k2]^2 + (7420 + 3*f1^3*dot[hat[k1], hat[z]]^2*
        (45 + 392*dot[hat[k1], hat[z]]^2)*dot[hat[k2], hat[z]]^2 + 
       f1^2*dot[hat[k1], hat[z]]^2*(603 + 2744*dot[hat[k1], hat[z]]^2 - 
         4374*dot[hat[k2], hat[z]]^2) + f1*(-9522*dot[hat[k1], hat[z]]^2 + 
         3816*dot[hat[k2], hat[z]]^2))*magM[k3]^2) - 
   2*f1*dot[hat[k1], hat[z]]*dot[hat[k2], hat[z]]*magM[k1]^5*magM[k2]*
    ((8079 + 21168*f1^3*dot[hat[k1], hat[z]]^4*dot[hat[k2], hat[z]]^2 + 
       9*f1^2*dot[hat[k2], hat[z]]^2*(-15 - 8476*dot[hat[k1], hat[z]]^2 + 
         196*dot[hat[k2], hat[z]]^2) + f1*(-9532*dot[hat[k1], hat[z]]^2 + 
         30968*dot[hat[k2], hat[z]]^2))*magM[k2]^2 + 
     (38990 + f1*(11829 - 17216*dot[hat[k1], hat[z]]^2 + 
         12324*dot[hat[k2], hat[z]]^2) + 
       3*f1^2*(1176*dot[hat[k1], hat[z]]^4 - 45*dot[hat[k2], hat[z]]^2 + 
         dot[hat[k1], hat[z]]^2*(1414 - 212*dot[hat[k2], hat[z]]^2)))*
      magM[k3]^2) + (magM[k2]^2 - magM[k3]^2)^2*
    (f1*dot[hat[k2], hat[z]]^2*(-447 + 590*f1*dot[hat[k2], hat[z]]^2 + 
       3*f1^2*dot[hat[k2], hat[z]]^2*(45 + 784*dot[hat[k2], hat[z]]^2))*
      magM[k2]^4 + (-1519 - 3612*f1*dot[hat[k2], hat[z]]^2 + 
       135*f1^3*dot[hat[k2], hat[z]]^4 + f1^2*(702*dot[hat[k2], hat[z]]^2 + 
         590*dot[hat[k2], hat[z]]^4))*magM[k2]^2*magM[k3]^2 - 
     (1519 + 447*f1*dot[hat[k2], hat[z]]^2)*magM[k3]^4) - 
   2*f1*dot[hat[k1], hat[z]]*dot[hat[k2], hat[z]]*magM[k1]*magM[k2]*
    (magM[k2]^2 - magM[k3]^2)*((447 - 1360*f1*dot[hat[k2], hat[z]]^2 + 
       7056*f1^3*dot[hat[k2], hat[z]]^6 - 3*f1^2*dot[hat[k2], hat[z]]^2*
        (45 + 1192*dot[hat[k2], hat[z]]^2))*magM[k2]^4 + 
     (-3983 + 12*f1^2*dot[hat[k2], hat[z]]^2*
        (21 + 290*dot[hat[k2], hat[z]]^2) - 
       f1*(351 + 18700*dot[hat[k2], hat[z]]^2))*magM[k2]^2*magM[k3]^2 + 
     (-7148 + 135*f1^2*dot[hat[k2], hat[z]]^2 - 
       9*f1*(-39 + 20*dot[hat[k2], hat[z]]^2))*magM[k3]^4) - 
   magM[k1]^4*(f1*(4*f1*dot[hat[k1], hat[z]]^4*
        (-98 + 123*f1*dot[hat[k2], hat[z]]^2 + 24696*f1^2*
          dot[hat[k2], hat[z]]^4) + dot[hat[k2], hat[z]]^2*
        (8079 + 21646*f1*dot[hat[k2], hat[z]]^2 + 
         3*f1^2*dot[hat[k2], hat[z]]^2*(-45 + 392*dot[hat[k2], hat[z]]^2)) - 
       6*dot[hat[k1], hat[z]]^2*(785 + 9056*f1*dot[hat[k2], hat[z]]^2 + 
         5*f1^2*dot[hat[k2], hat[z]]^2*(-9 + 6320*dot[hat[k2], hat[z]]^2)))*
      magM[k2]^4 + (16359 - 12348*f1^5*dot[hat[k1], hat[z]]^4*
        dot[hat[k2], hat[z]]^2 + 2*f1*(8609*dot[hat[k1], hat[z]]^2 + 
         38990*dot[hat[k2], hat[z]]^2) - 252*f1^4*dot[hat[k1], hat[z]]^2*
        dot[hat[k2], hat[z]]^2*(193 + 4*dot[hat[k1], hat[z]]^2*
          (25 + 7*dot[hat[k2], hat[z]]^2)) + 
       3*f1^3*(-45*dot[hat[k2], hat[z]]^4 - 8*dot[hat[k1], hat[z]]^2*
          dot[hat[k2], hat[z]]^2*(2684 + 755*dot[hat[k2], hat[z]]^2) + 
         4*dot[hat[k1], hat[z]]^4*(245 + 3166*dot[hat[k2], hat[z]]^2)) + 
       2*f1^2*(1062*dot[hat[k1], hat[z]]^4 + dot[hat[k1], hat[z]]^2*
          (4065 - 83276*dot[hat[k2], hat[z]]^2) + dot[hat[k2], hat[z]]^2*
          (11829 + 10823*dot[hat[k2], hat[z]]^2)))*magM[k2]^2*magM[k3]^2 + 
     (16359 + 6*f1^3*dot[hat[k1], hat[z]]^2*(45 + 98*dot[hat[k1], hat[z]]^2)*
        dot[hat[k2], hat[z]]^2 + 2*f1^2*dot[hat[k1], hat[z]]^2*
        (603 + 686*dot[hat[k1], hat[z]]^2 - 1512*dot[hat[k2], hat[z]]^2) + 
       f1*(-7596*dot[hat[k1], hat[z]]^2 + 8079*dot[hat[k2], hat[z]]^2))*
      magM[k3]^4) + 4*f1*dot[hat[k1], hat[z]]*dot[hat[k2], hat[z]]*magM[k1]^3*
    magM[k2]*((2355 - 28224*f1^3*dot[hat[k1], hat[z]]^2*
        dot[hat[k2], hat[z]]^4 + 3*f1^2*dot[hat[k2], hat[z]]^2*
        (-45 + 122*dot[hat[k1], hat[z]]^2 + 9398*dot[hat[k2], hat[z]]^2) + 
       f1*(581*dot[hat[k1], hat[z]]^2 + 13850*dot[hat[k2], hat[z]]^2))*
      magM[k2]^4 + 3*(2918 + 2058*f1^4*dot[hat[k1], hat[z]]^2*
        dot[hat[k2], hat[z]]^2 + 3*f1*(253 + 592*dot[hat[k1], hat[z]]^2 + 
         7340*dot[hat[k2], hat[z]]^2) + 42*f1^3*dot[hat[k2], hat[z]]^2*
        (193 + 4*dot[hat[k1], hat[z]]^2*(25 + 14*dot[hat[k2], hat[z]]^2)) + 
       f1^2*(dot[hat[k1], hat[z]]^2*(175 - 5548*dot[hat[k2], hat[z]]^2) + 
         2*dot[hat[k2], hat[z]]^2*(6075 + 1841*dot[hat[k2], hat[z]]^2)))*
      magM[k2]^2*magM[k3]^2 + 
     (21161 + f1*(5739 - 3261*dot[hat[k1], hat[z]]^2 + 
         5298*dot[hat[k2], hat[z]]^2) + 3*f1^2*(-45*dot[hat[k2], hat[z]]^2 + 
         dot[hat[k1], hat[z]]^2*(707 + 90*dot[hat[k2], hat[z]]^2)))*
      magM[k3]^4) + magM[k1]^2*
    (f1*(2*dot[hat[k2], hat[z]]^2*(2355 + 9574*f1*dot[hat[k2], hat[z]]^2 + 
         15*f1^2*dot[hat[k2], hat[z]]^2*(-9 + 872*dot[hat[k2], hat[z]]^2)) + 
       dot[hat[k1], hat[z]]^2*(-447 + 4062*f1*dot[hat[k2], hat[z]]^2 - 
         63504*f1^3*dot[hat[k2], hat[z]]^6 + 3*f1^2*dot[hat[k2], hat[z]]^2*
          (45 + 2252*dot[hat[k2], hat[z]]^2)))*magM[k2]^6 + 
     (10458 + 12348*f1^5*dot[hat[k1], hat[z]]^2*dot[hat[k2], hat[z]]^4 + 
       f1*(9688*dot[hat[k1], hat[z]]^2 + 59830*dot[hat[k2], hat[z]]^2) + 
       252*f1^4*dot[hat[k2], hat[z]]^4*(193 + 20*dot[hat[k1], hat[z]]^2*
          (5 + 7*dot[hat[k2], hat[z]]^2)) + 
       f1^2*(24*dot[hat[k2], hat[z]]^2*(668 + 5505*dot[hat[k2], hat[z]]^2) + 
         dot[hat[k1], hat[z]]^2*(603 + 57334*dot[hat[k2], hat[z]]^2)) + 
       f1^3*(60*dot[hat[k2], hat[z]]^4*(1215 + 436*dot[hat[k2], hat[z]]^2) + 
         dot[hat[k1], hat[z]]^2*(4401*dot[hat[k2], hat[z]]^2 - 
           45048*dot[hat[k2], hat[z]]^4)))*magM[k2]^4*magM[k3]^2 + 
     (7168 + f1*(3989*dot[hat[k1], hat[z]]^2 + 59830*dot[hat[k2], hat[z]]^
           2) + 3*f1^3*(-90*dot[hat[k2], hat[z]]^4 + dot[hat[k1], hat[z]]^2*
          dot[hat[k2], hat[z]]^2*(1971 + 2092*dot[hat[k2], hat[z]]^2)) + 
       2*f1^2*(8016*dot[hat[k2], hat[z]]^2 + 9574*dot[hat[k2], hat[z]]^4 - 
         dot[hat[k1], hat[z]]^2*(603 + 25123*dot[hat[k2], hat[z]]^2)))*
      magM[k2]^2*magM[k3]^4 + 3*(3486 + 45*f1^3*dot[hat[k1], hat[z]]^2*
        dot[hat[k2], hat[z]]^2 - 3*f1^2*dot[hat[k1], hat[z]]^2*
        (-67 + 62*dot[hat[k2], hat[z]]^2) + f1*(-630*dot[hat[k1], hat[z]]^2 + 
         1570*dot[hat[k2], hat[z]]^2))*magM[k3]^6))*P11[magM[k1]])/
 (246960*Pi^2*magM[k1]^2*magM[k3]^2)
