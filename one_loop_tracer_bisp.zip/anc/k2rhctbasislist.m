(* Created with the Wolfram Language : www.wolfram.com *)
{-1/28*(28*dot[k1, k2]^2*magM[k1]^4 + 28*f1*dot[k1, k2]*dot[k1, hat[z]]*
     dot[k2, hat[z]]*magM[k1]^4 + 28*f1*dot[k1, k2]*dot[k2, hat[z]]^2*
     magM[k1]^4 + 14*dot[k1, k2]*magM[k1]^6 + 14*f1*dot[k1, hat[z]]*
     dot[k2, hat[z]]*magM[k1]^6 + 14*f1*dot[k2, hat[z]]^2*magM[k1]^6 + 
    14*dot[k1, k2]*magM[k1]^4*magM[k2]^2 + 14*f1*dot[k1, hat[z]]*
     dot[k2, hat[z]]*magM[k1]^4*magM[k2]^2 + 14*f1*dot[k2, hat[z]]^2*
     magM[k1]^4*magM[k2]^2 + 28*dot[k1, k2]^2*magM[k2]^4 + 
    28*f1*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k2]^4 + 
    28*f1*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^4 + 
    14*dot[k1, k2]*magM[k1]^2*magM[k2]^4 + 14*f1*dot[k1, hat[z]]^2*magM[k1]^2*
     magM[k2]^4 + 14*f1*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*
     magM[k2]^4 + 14*dot[k1, k2]*magM[k2]^6 + 14*f1*dot[k1, hat[z]]^2*
     magM[k2]^6 + 14*f1*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^6)/
   (knl^2*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)), 
 -1/28*(32*dot[k1, k2]^4 + 88*dot[k1, k2]^3*magM[k1]^2 + 
    36*dot[k1, k2]^2*magM[k1]^4 + 88*dot[k1, k2]^3*magM[k2]^2 + 
    208*dot[k1, k2]^2*magM[k1]^2*magM[k2]^2 + 108*dot[k1, k2]*magM[k1]^4*
     magM[k2]^2 + 20*magM[k1]^6*magM[k2]^2 + 36*dot[k1, k2]^2*magM[k2]^4 + 
    108*dot[k1, k2]*magM[k1]^2*magM[k2]^4 + 40*magM[k1]^4*magM[k2]^4 + 
    20*magM[k1]^2*magM[k2]^6)/(knl^2*magM[k1]^2*magM[k2]^2*
    (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)), 
 -1/28*(112*dot[k1, k2]^2*magM[k1]^2*magM[k2]^2 + 112*dot[k1, k2]*magM[k1]^4*
     magM[k2]^2 + 28*magM[k1]^6*magM[k2]^2 + 112*dot[k1, k2]*magM[k1]^2*
     magM[k2]^4 + 56*magM[k1]^4*magM[k2]^4 + 28*magM[k1]^2*magM[k2]^6)/
   (knl^2*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)), 
 -1/28*(112*dot[k1, k2]^4 + 112*dot[k1, k2]^3*magM[k1]^2 + 
    28*dot[k1, k2]^2*magM[k1]^4 + 112*dot[k1, k2]^3*magM[k2]^2 + 
    56*dot[k1, k2]^2*magM[k1]^2*magM[k2]^2 + 28*dot[k1, k2]^2*magM[k2]^4)/
   (knl^2*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)), 
 -1/28*(56*dot[k1, k2]^2*magM[k1]^2*magM[k2]^2 + 28*dot[k1, k2]*magM[k1]^4*
     magM[k2]^2 + 28*dot[k1, k2]*magM[k1]^2*magM[k2]^4)/
   (knl^2*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)), 
 -1/28*(-28*f1*dot[k1, k2]^2*dot[k1, hat[z]]^2*magM[k1]^2 - 
    28*f1*dot[k1, k2]^2*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2 - 
    28*f1^2*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k1]^2 - 
    56*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^2 - 
    28*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k1]^2 - 
    14*f1*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^4 - 
    14*f1*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^4 - 
    14*f1^2*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k1]^4 - 
    28*f1^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^4 - 
    14*f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k1]^4 - 
    28*f1*dot[k1, k2]^2*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2 - 
    28*f1^2*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2 - 
    28*f1*dot[k1, k2]^2*dot[k2, hat[z]]^2*magM[k2]^2 - 
    56*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k2]^2 - 
    28*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k2]^2 - 
    14*f1*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2 - 
    28*f1*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*magM[k2]^2 - 
    28*f1^2*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k1]^2*magM[k2]^2 - 
    14*f1*dot[k1, k2]*dot[k2, hat[z]]^2*magM[k1]^2*magM[k2]^2 - 
    56*f1^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^2*magM[k2]^2 - 
    28*f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k1]^2*magM[k2]^2 - 
    14*f1*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^4 - 
    14*f1^2*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^4 - 
    14*f1*dot[k1, k2]*dot[k2, hat[z]]^2*magM[k2]^4 - 
    28*f1^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k2]^4 - 
    14*f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k2]^4)/
   (knl^2*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)), 
 -1/28*(-28*f1*dot[k1, k2]^3*dot[k1, hat[z]]^2 - 56*f1*dot[k1, k2]^3*
     dot[k1, hat[z]]*dot[k2, hat[z]] - 28*f1*dot[k1, k2]^3*
     dot[k2, hat[z]]^2 - 28*f1*dot[k1, k2]^2*dot[k1, hat[z]]^2*magM[k1]^2 - 
    56*f1*dot[k1, k2]^2*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2 - 
    28*f1*dot[k1, k2]^2*dot[k2, hat[z]]^2*magM[k1]^2 - 
    28*f1*dot[k1, k2]^2*dot[k1, hat[z]]^2*magM[k2]^2 - 
    56*f1*dot[k1, k2]^2*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2 - 
    28*f1*dot[k1, k2]^2*dot[k2, hat[z]]^2*magM[k2]^2 - 
    28*f1*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2 - 
    56*f1*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*magM[k2]^2 - 
    28*f1*dot[k1, k2]*dot[k2, hat[z]]^2*magM[k1]^2*magM[k2]^2)/
   (knl^2*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)), 
 -1/28*(14*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]^4 + 
    28*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]^3*dot[k2, hat[z]] + 
    14*f1^3*dot[k1, k2]*dot[k1, hat[z]]^5*dot[k2, hat[z]] + 
    28*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2 + 
    56*f1^3*dot[k1, k2]*dot[k1, hat[z]]^4*dot[k2, hat[z]]^2 + 
    28*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]*dot[k2, hat[z]]^3 + 
    84*f1^3*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]^3 + 
    14*f1^2*dot[k1, k2]^2*dot[k2, hat[z]]^4 + 56*f1^3*dot[k1, k2]*
     dot[k1, hat[z]]^2*dot[k2, hat[z]]^4 + 14*f1^3*dot[k1, k2]*
     dot[k1, hat[z]]*dot[k2, hat[z]]^5 + 7*f1^2*dot[k1, k2]*dot[k1, hat[z]]^4*
     magM[k1]^2 + 14*f1^2*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
     magM[k1]^2 + 7*f1^3*dot[k1, hat[z]]^5*dot[k2, hat[z]]*magM[k1]^2 + 
    14*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^2 + 
    28*f1^3*dot[k1, hat[z]]^4*dot[k2, hat[z]]^2*magM[k1]^2 + 
    14*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k1]^2 + 
    42*f1^3*dot[k1, hat[z]]^3*dot[k2, hat[z]]^3*magM[k1]^2 + 
    7*f1^2*dot[k1, k2]*dot[k2, hat[z]]^4*magM[k1]^2 + 
    28*f1^3*dot[k1, hat[z]]^2*dot[k2, hat[z]]^4*magM[k1]^2 + 
    7*f1^3*dot[k1, hat[z]]*dot[k2, hat[z]]^5*magM[k1]^2 + 
    7*f1^2*dot[k1, k2]*dot[k1, hat[z]]^4*magM[k2]^2 + 
    14*f1^2*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2 + 
    7*f1^3*dot[k1, hat[z]]^5*dot[k2, hat[z]]*magM[k2]^2 + 
    14*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k2]^2 + 
    28*f1^3*dot[k1, hat[z]]^4*dot[k2, hat[z]]^2*magM[k2]^2 + 
    14*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k2]^2 + 
    42*f1^3*dot[k1, hat[z]]^3*dot[k2, hat[z]]^3*magM[k2]^2 + 
    7*f1^2*dot[k1, k2]*dot[k2, hat[z]]^4*magM[k2]^2 + 
    28*f1^3*dot[k1, hat[z]]^2*dot[k2, hat[z]]^4*magM[k2]^2 + 
    7*f1^3*dot[k1, hat[z]]*dot[k2, hat[z]]^5*magM[k2]^2)/
   (knl^2*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)), 
 -1/28*(-10*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]^4 - 
    12*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]^3*dot[k2, hat[z]] - 
    4*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2 - 
    12*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]*dot[k2, hat[z]]^3 - 
    10*f1^2*dot[k1, k2]^2*dot[k2, hat[z]]^4 + 14*f1^2*dot[k1, k2]*
     dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k1]^2 + 
    28*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^2 + 
    14*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k1]^2 + 
    14*f1^2*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2 + 
    28*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k2]^2 + 
    14*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k2]^2 + 
    10*f1^2*dot[k1, hat[z]]^4*magM[k1]^2*magM[k2]^2 + 
    40*f1^2*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k1]^2*magM[k2]^2 + 
    60*f1^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^2*magM[k2]^2 + 
    40*f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k1]^2*magM[k2]^2 + 
    10*f1^2*dot[k2, hat[z]]^4*magM[k1]^2*magM[k2]^2)/
   (knl^2*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)), 
 -1/28*(14*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]^2*magM[k1]^2 + 
    28*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2 + 
    14*f1^3*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k1]^2 + 
    14*f1^2*dot[k1, k2]^2*dot[k2, hat[z]]^2*magM[k1]^2 + 
    42*f1^3*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^2 + 
    42*f1^3*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k1]^2 + 
    14*f1^3*dot[k1, k2]*dot[k2, hat[z]]^4*magM[k1]^2 + 
    7*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^4 + 
    14*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^4 + 
    7*f1^3*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k1]^4 + 
    7*f1^2*dot[k1, k2]*dot[k2, hat[z]]^2*magM[k1]^4 + 
    21*f1^3*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^4 + 
    21*f1^3*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k1]^4 + 
    7*f1^3*dot[k2, hat[z]]^4*magM[k1]^4 + 14*f1^2*dot[k1, k2]^2*
     dot[k1, hat[z]]^2*magM[k2]^2 + 14*f1^3*dot[k1, k2]*dot[k1, hat[z]]^4*
     magM[k2]^2 + 28*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]*dot[k2, hat[z]]*
     magM[k2]^2 + 42*f1^3*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
     magM[k2]^2 + 14*f1^2*dot[k1, k2]^2*dot[k2, hat[z]]^2*magM[k2]^2 + 
    42*f1^3*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k2]^2 + 
    14*f1^3*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k2]^2 + 
    14*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2 + 
    7*f1^3*dot[k1, hat[z]]^4*magM[k1]^2*magM[k2]^2 + 
    28*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*
     magM[k2]^2 + 28*f1^3*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k1]^2*
     magM[k2]^2 + 14*f1^2*dot[k1, k2]*dot[k2, hat[z]]^2*magM[k1]^2*
     magM[k2]^2 + 42*f1^3*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^2*
     magM[k2]^2 + 28*f1^3*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k1]^2*
     magM[k2]^2 + 7*f1^3*dot[k2, hat[z]]^4*magM[k1]^2*magM[k2]^2 + 
    7*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k2]^4 + 
    7*f1^3*dot[k1, hat[z]]^4*magM[k2]^4 + 14*f1^2*dot[k1, k2]*dot[k1, hat[z]]*
     dot[k2, hat[z]]*magM[k2]^4 + 21*f1^3*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
     magM[k2]^4 + 7*f1^2*dot[k1, k2]*dot[k2, hat[z]]^2*magM[k2]^4 + 
    21*f1^3*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k2]^4 + 
    7*f1^3*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k2]^4)/
   (knl^2*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)), 
 -1/28*(8*f1^2*dot[k1, k2]^3*dot[k1, hat[z]]^2 + 16*f1^2*dot[k1, k2]^3*
     dot[k1, hat[z]]*dot[k2, hat[z]] + 8*f1^2*dot[k1, k2]^3*
     dot[k2, hat[z]]^2 + 4*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]^2*magM[k1]^2 + 
    8*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2 + 
    4*f1^2*dot[k1, k2]^2*dot[k2, hat[z]]^2*magM[k1]^2 + 
    4*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]^2*magM[k2]^2 + 
    8*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2 + 
    4*f1^2*dot[k1, k2]^2*dot[k2, hat[z]]^2*magM[k2]^2 + 
    20*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2 + 
    40*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*
     magM[k2]^2 + 20*f1^2*dot[k1, k2]*dot[k2, hat[z]]^2*magM[k1]^2*
     magM[k2]^2 + 10*f1^2*dot[k1, hat[z]]^2*magM[k1]^4*magM[k2]^2 + 
    20*f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^4*magM[k2]^2 + 
    10*f1^2*dot[k2, hat[z]]^2*magM[k1]^4*magM[k2]^2 + 
    10*f1^2*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^4 + 
    20*f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*magM[k2]^4 + 
    10*f1^2*dot[k2, hat[z]]^2*magM[k1]^2*magM[k2]^4)/
   (knl^2*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)), 
 -1/28*(14*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^2 + 
    28*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k1]^2 + 
    14*f1^2*dot[k1, k2]*dot[k2, hat[z]]^4*magM[k1]^2 + 
    7*f1^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^4 + 
    14*f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k1]^4 + 
    7*f1^2*dot[k2, hat[z]]^4*magM[k1]^4 + 14*f1^2*dot[k1, k2]*
     dot[k1, hat[z]]^4*magM[k2]^2 + 28*f1^2*dot[k1, k2]*dot[k1, hat[z]]^3*
     dot[k2, hat[z]]*magM[k2]^2 + 14*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*
     dot[k2, hat[z]]^2*magM[k2]^2 + 7*f1^2*dot[k1, hat[z]]^4*magM[k1]^2*
     magM[k2]^2 + 14*f1^2*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k1]^2*
     magM[k2]^2 + 14*f1^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^2*
     magM[k2]^2 + 14*f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k1]^2*
     magM[k2]^2 + 7*f1^2*dot[k2, hat[z]]^4*magM[k1]^2*magM[k2]^2 + 
    7*f1^2*dot[k1, hat[z]]^4*magM[k2]^4 + 14*f1^2*dot[k1, hat[z]]^3*
     dot[k2, hat[z]]*magM[k2]^4 + 7*f1^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
     magM[k2]^4)/(knl^2*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + 
     magM[k2]^2)), 
 -1/28*(28*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]^3*dot[k2, hat[z]] + 
    56*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2 + 
    28*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]*dot[k2, hat[z]]^3 + 
    14*f1^2*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k1]^2 + 
    28*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^2 + 
    14*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k1]^2 + 
    14*f1^2*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2 + 
    28*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k2]^2 + 
    14*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k2]^2)/
   (knl^2*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)), 
 -1/28*(28*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2 + 
    56*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*
     magM[k2]^2 + 28*f1^2*dot[k1, k2]*dot[k2, hat[z]]^2*magM[k1]^2*
     magM[k2]^2 + 14*f1^2*dot[k1, hat[z]]^2*magM[k1]^4*magM[k2]^2 + 
    28*f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^4*magM[k2]^2 + 
    14*f1^2*dot[k2, hat[z]]^2*magM[k1]^4*magM[k2]^2 + 
    14*f1^2*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^4 + 
    28*f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*magM[k2]^4 + 
    14*f1^2*dot[k2, hat[z]]^2*magM[k1]^2*magM[k2]^4)/
   (knl^2*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2))}
