(* Created with the Wolfram Language : www.wolfram.com *)
{(-8*(2*f1*dot[k1, hat[z]]^2 + magM[k1]^2)*(2*f1*dot[k2, hat[z]]^2 + 
    magM[k2]^2)*(2*f1*dot[k3, hat[z]]^2 + magM[k3]^2))/(343*knl^6), 
 (-4*(42*f1^2*dot[k1, hat[z]]^3*magM[k2]^2*magM[k3]^2*
     (dot[k1, k3]*dot[k3, hat[z]]*(2*f1*dot[k2, hat[z]]^2 + magM[k2]^2) + 
      dot[k1, k2]*dot[k2, hat[z]]*(2*f1*dot[k3, hat[z]]^2 + magM[k3]^2)) + 
    7*f1*dot[k1, hat[z]]*magM[k1]^2*(dot[k1, k2]*dot[k2, hat[z]]*
       (6*f1*dot[k2, hat[z]]^2 + (20 + 7*f1)*magM[k2]^2)*magM[k3]^2*
       (2*f1*dot[k3, hat[z]]^2 + magM[k3]^2) + dot[k1, k3]*dot[k3, hat[z]]*
       magM[k2]^2*(2*f1*dot[k2, hat[z]]^2 + magM[k2]^2)*
       (6*f1*dot[k3, hat[z]]^2 + (20 + 7*f1)*magM[k3]^2)) + 
    magM[k1]^2*(10*dot[k1, k3]^2*magM[k2]^2*(2*f1*dot[k2, hat[z]]^2 + 
        magM[k2]^2)*(3*f1*dot[k3, hat[z]]^2 + 5*magM[k3]^2) + 
      2*dot[k2, k3]^2*magM[k1]^2*(3*f1*dot[k2, hat[z]]^2 + 5*magM[k2]^2)*
       (3*f1*dot[k3, hat[z]]^2 + 5*magM[k3]^2) + 7*f1*dot[k2, k3]*
       dot[k2, hat[z]]*dot[k3, hat[z]]*magM[k1]^2*
       (6*f1*dot[k3, hat[z]]^2*magM[k2]^2 + (6*f1*dot[k2, hat[z]]^2 + 
          (20 + 7*f1)*magM[k2]^2)*magM[k3]^2) + 
      magM[k3]^2*(49*f1^2*dot[k2, hat[z]]^2*dot[k3, hat[z]]^2*magM[k1]^2*
         magM[k2]^2 + 10*dot[k1, k2]^2*(3*f1*dot[k2, hat[z]]^2 + 
          5*magM[k2]^2)*(2*f1*dot[k3, hat[z]]^2 + magM[k3]^2))) + 
    f1*dot[k1, hat[z]]^2*(6*dot[k1, k3]^2*magM[k2]^2*
       (2*f1*dot[k2, hat[z]]^2 + magM[k2]^2)*(3*f1*dot[k3, hat[z]]^2 + 
        5*magM[k3]^2) + 4*dot[k2, k3]^2*magM[k1]^2*(3*f1*dot[k2, hat[z]]^2 + 
        5*magM[k2]^2)*(3*f1*dot[k3, hat[z]]^2 + 5*magM[k3]^2) + 
      14*f1*dot[k2, k3]*dot[k2, hat[z]]*dot[k3, hat[z]]*magM[k1]^2*
       (6*f1*dot[k3, hat[z]]^2*magM[k2]^2 + (6*f1*dot[k2, hat[z]]^2 + 
          (20 + 7*f1)*magM[k2]^2)*magM[k3]^2) + 
      magM[k3]^2*(6*dot[k1, k2]^2*(3*f1*dot[k2, hat[z]]^2 + 5*magM[k2]^2)*
         (2*f1*dot[k3, hat[z]]^2 + magM[k3]^2) + 49*f1*magM[k1]^2*magM[k2]^2*
         (dot[k3, hat[z]]^2*magM[k2]^2 + dot[k2, hat[z]]^2*
           (6*f1*dot[k3, hat[z]]^2 + magM[k3]^2))))))/
  (8575*knl^6*magM[k1]^2*magM[k2]^2*magM[k3]^2), 
 (-2*(7*f1*dot[k1, hat[z]]*dot[k2, hat[z]]*
     (7*f1*dot[k1, hat[z]]*dot[k3, hat[z]]*
       (7*f1*dot[k2, hat[z]]*dot[k3, hat[z]]*magM[k1]^2*magM[k2]^2*
         magM[k3]^2 + dot[k2, k3]*(3*f1*dot[k3, hat[z]]^2*magM[k1]^2*
           magM[k2]^2 + (3*f1*dot[k2, hat[z]]^2*magM[k1]^2 + 
            (3*f1*dot[k1, hat[z]]^2 + (15 + 7*f1)*magM[k1]^2)*magM[k2]^2)*
           magM[k3]^2)) + dot[k1, k3]*
       (dot[k2, k3]*(6*f1*dot[k2, hat[z]]^2*magM[k1]^2 + 
          (6*f1*dot[k1, hat[z]]^2 + (20 + 7*f1)*magM[k1]^2)*magM[k2]^2)*
         (3*f1*dot[k3, hat[z]]^2 + 5*magM[k3]^2) + 7*f1*dot[k2, hat[z]]*
         dot[k3, hat[z]]*(3*f1*dot[k3, hat[z]]^2*magM[k1]^2*magM[k2]^2 + 
          (3*f1*dot[k2, hat[z]]^2*magM[k1]^2 + (3*f1*dot[k1, hat[z]]^2 + 
              (15 + 7*f1)*magM[k1]^2)*magM[k2]^2)*magM[k3]^2))) + 
    dot[k1, k2]*(dot[k1, k3]*(3*f1*dot[k1, hat[z]]^2 + 5*magM[k1]^2)*
       (4*dot[k2, k3]*(3*f1*dot[k2, hat[z]]^2 + 5*magM[k2]^2)*
         (3*f1*dot[k3, hat[z]]^2 + 5*magM[k3]^2) + 7*f1*dot[k2, hat[z]]*
         dot[k3, hat[z]]*(6*f1*dot[k3, hat[z]]^2*magM[k2]^2 + 
          (6*f1*dot[k2, hat[z]]^2 + (20 + 7*f1)*magM[k2]^2)*magM[k3]^2)) + 
      7*f1*dot[k1, hat[z]]*dot[k3, hat[z]]*
       (dot[k2, k3]*(3*f1*dot[k2, hat[z]]^2 + 5*magM[k2]^2)*
         (6*f1*dot[k3, hat[z]]^2*magM[k1]^2 + (6*f1*dot[k1, hat[z]]^2 + 
            (20 + 7*f1)*magM[k1]^2)*magM[k3]^2) + 7*f1*dot[k2, hat[z]]*
         dot[k3, hat[z]]*(3*f1*dot[k3, hat[z]]^2*magM[k1]^2*magM[k2]^2 + 
          (3*f1*dot[k2, hat[z]]^2*magM[k1]^2 + (3*f1*dot[k1, hat[z]]^2 + 
              (15 + 7*f1)*magM[k1]^2)*magM[k2]^2)*magM[k3]^2)))))/
  (42875*knl^6*magM[k1]^2*magM[k2]^2*magM[k3]^2), 
 (-2*f1^2*(magM[k1]^2*(dot[k3, hat[z]]^2*magM[k2]^2 + 
      dot[k2, hat[z]]^2*(4*f1*dot[k3, hat[z]]^2 + magM[k3]^2)) + 
    dot[k1, hat[z]]^2*(4*f1*dot[k2, hat[z]]^2*(3*f1*dot[k3, hat[z]]^2 + 
        magM[k3]^2) + magM[k2]^2*(4*f1*dot[k3, hat[z]]^2 + magM[k3]^2))))/
  (49*knl^6), (-2*f1^2*(dot[k2, hat[z]]^2*dot[k3, hat[z]]^2*magM[k1]^4*
     (3*f1*dot[k3, hat[z]]^2*magM[k2]^2 + (3*f1*dot[k2, hat[z]]^2 + 
        2*(5 + 7*f1)*magM[k2]^2)*magM[k3]^2) + 3*f1*dot[k1, hat[z]]^4*
     magM[k2]^2*magM[k3]^2*(dot[k3, hat[z]]^2*magM[k2]^2 + 
      dot[k2, hat[z]]^2*(4*f1*dot[k3, hat[z]]^2 + magM[k3]^2)) + 
    dot[k1, hat[z]]^2*magM[k1]^2*(3*f1*dot[k2, hat[z]]^4*magM[k3]^2*
       (4*f1*dot[k3, hat[z]]^2 + magM[k3]^2) + dot[k3, hat[z]]^2*magM[k2]^4*
       (3*f1*dot[k3, hat[z]]^2 + 2*(5 + 7*f1)*magM[k3]^2) + 
      2*dot[k2, hat[z]]^2*magM[k2]^2*(6*f1^2*dot[k3, hat[z]]^4 + 
        6*f1*(5 + 7*f1)*dot[k3, hat[z]]^2*magM[k3]^2 + 
        (5 + 7*f1)*magM[k3]^4))))/(245*knl^6*magM[k1]^2*magM[k2]^2*
   magM[k3]^2), 
 -1/1225*(f1^2*(42*f1^2*dot[k1, hat[z]]^3*dot[k2, hat[z]]*dot[k3, hat[z]]*
      (dot[k1, k3]*dot[k2, hat[z]] + dot[k1, k2]*dot[k3, hat[z]])*magM[k2]^2*
      magM[k3]^2 + 10*magM[k1]^2*(dot[k1, k2]^2*dot[k3, hat[z]]^2*
        (3*f1*dot[k2, hat[z]]^2 + 5*magM[k2]^2)*magM[k3]^2 + 
       dot[k1, k3]^2*dot[k2, hat[z]]^2*magM[k2]^2*(3*f1*dot[k3, hat[z]]^2 + 
         5*magM[k3]^2)) + 7*f1*dot[k1, hat[z]]*dot[k2, hat[z]]*
      dot[k3, hat[z]]*magM[k1]^2*(dot[k1, k2]*dot[k3, hat[z]]*
        (6*f1*dot[k2, hat[z]]^2 + (20 + 7*f1)*magM[k2]^2)*magM[k3]^2 + 
       dot[k1, k3]*dot[k2, hat[z]]*magM[k2]^2*(6*f1*dot[k3, hat[z]]^2 + 
         (20 + 7*f1)*magM[k3]^2)) + dot[k1, hat[z]]^2*
      (2*dot[k2, k3]^2*magM[k1]^2*(3*f1*dot[k2, hat[z]]^2 + 5*magM[k2]^2)*
        (3*f1*dot[k3, hat[z]]^2 + 5*magM[k3]^2) + 7*f1*dot[k2, k3]*
        dot[k2, hat[z]]*dot[k3, hat[z]]*magM[k1]^2*
        (6*f1*dot[k3, hat[z]]^2*magM[k2]^2 + (6*f1*dot[k2, hat[z]]^2 + 
           (20 + 7*f1)*magM[k2]^2)*magM[k3]^2) + 
       3*f1*(dot[k3, hat[z]]^2*(49*f1*dot[k2, hat[z]]^2*magM[k1]^2*
            magM[k2]^2 + 2*dot[k1, k2]^2*(3*f1*dot[k2, hat[z]]^2 + 
             5*magM[k2]^2))*magM[k3]^2 + 2*dot[k1, k3]^2*dot[k2, hat[z]]^2*
          magM[k2]^2*(3*f1*dot[k3, hat[z]]^2 + 5*magM[k3]^2)))))/
   (knl^6*magM[k1]^2*magM[k2]^2*magM[k3]^2), 
 -1/2450*(f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]*dot[k3, hat[z]]*
    (84*f1^2*dot[k1, hat[z]]^3*dot[k2, hat[z]]*dot[k3, hat[z]]*magM[k2]^2*
      magM[k3]^2 + 6*f1*dot[k1, hat[z]]^2*(dot[k1, k2]*dot[k3, hat[z]]*
        (6*f1*dot[k2, hat[z]]^2 + (10 + 7*f1)*magM[k2]^2)*magM[k3]^2 + 
       dot[k1, k3]*dot[k2, hat[z]]*magM[k2]^2*(6*f1*dot[k3, hat[z]]^2 + 
         (10 + 7*f1)*magM[k3]^2)) + (10 + 7*f1)*magM[k1]^2*
      (dot[k1, k2]*dot[k3, hat[z]]*(6*f1*dot[k2, hat[z]]^2 + 
         (10 + 7*f1)*magM[k2]^2)*magM[k3]^2 + dot[k1, k3]*dot[k2, hat[z]]*
        magM[k2]^2*(6*f1*dot[k3, hat[z]]^2 + (10 + 7*f1)*magM[k3]^2)) + 
     dot[k1, hat[z]]*magM[k1]^2*(dot[k2, k3]*(6*f1*dot[k2, hat[z]]^2 + 
         (10 + 7*f1)*magM[k2]^2)*(6*f1*dot[k3, hat[z]]^2 + 
         (10 + 7*f1)*magM[k3]^2) + 21*f1*dot[k2, hat[z]]*dot[k3, hat[z]]*
        (4*f1*dot[k3, hat[z]]^2*magM[k2]^2 + (4*f1*dot[k2, hat[z]]^2 + 
           (20 + 21*f1)*magM[k2]^2)*magM[k3]^2))))/
   (knl^6*magM[k1]^2*magM[k2]^2*magM[k3]^2), 
 -1/14*(f1^4*(dot[k2, hat[z]]^2*dot[k3, hat[z]]^2*magM[k1]^2 + 
     dot[k1, hat[z]]^2*(dot[k3, hat[z]]^2*magM[k2]^2 + 
       dot[k2, hat[z]]^2*(6*f1*dot[k3, hat[z]]^2 + magM[k3]^2))))/knl^6, 
 (-3*f1^4*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*dot[k3, hat[z]]^2*
   (f1*dot[k3, hat[z]]^2*magM[k1]^2*magM[k2]^2 + 
    (f1*dot[k2, hat[z]]^2*magM[k1]^2 + (f1*dot[k1, hat[z]]^2 + 
        (5 + 7*f1)*magM[k1]^2)*magM[k2]^2)*magM[k3]^2))/
  (35*knl^6*magM[k1]^2*magM[k2]^2*magM[k3]^2), 
 -1/8*(f1^6*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*dot[k3, hat[z]]^2)/knl^6}
