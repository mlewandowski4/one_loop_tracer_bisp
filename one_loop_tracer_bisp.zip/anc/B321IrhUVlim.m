(* Created with the Wolfram Language : www.wolfram.com *)
(26*b1^3*Intdqq2P112*P11[magM[k1]])/(21*Pi^2) - 
 (6*b1^2*b10*Intdqq2P112*P11[magM[k1]])/Pi^2 + 
 (2*b1^2*b2*Intdqq2P112*P11[magM[k1]])/Pi^2 + 
 (6*b1*b10*b2*Intdqq2P112*P11[magM[k1]])/Pi^2 - 
 (68*b1*b2^2*Intdqq2P112*P11[magM[k1]])/(21*Pi^2) - 
 (94*b1^2*b3*Intdqq2P112*P11[magM[k1]])/(21*Pi^2) + 
 (94*b1*b2*b3*Intdqq2P112*P11[magM[k1]])/(21*Pi^2) + 
 (58*b1^2*b5*Intdqq2P112*P11[magM[k1]])/(21*Pi^2) + 
 (6*b1*b10*b5*Intdqq2P112*P11[magM[k1]])/Pi^2 - 
 (152*b1*b2*b5*Intdqq2P112*P11[magM[k1]])/(21*Pi^2) + 
 (94*b1*b3*b5*Intdqq2P112*P11[magM[k1]])/(21*Pi^2) - 
 (4*b1*b5^2*Intdqq2P112*P11[magM[k1]])/Pi^2 - 
 (220*b1^2*b6*Intdqq2P112*P11[magM[k1]])/(21*Pi^2) + 
 (220*b1*b2*b6*Intdqq2P112*P11[magM[k1]])/(21*Pi^2) + 
 (220*b1*b5*b6*Intdqq2P112*P11[magM[k1]])/(21*Pi^2) - 
 (164*b1^2*b8*Intdqq2P112*P11[magM[k1]])/(21*Pi^2) + 
 (164*b1*b2*b8*Intdqq2P112*P11[magM[k1]])/(21*Pi^2) + 
 (164*b1*b5*b8*Intdqq2P112*P11[magM[k1]])/(21*Pi^2) + 
 (11*b1^3*IntdqP112*dot[k1, k3]*P11[magM[k1]])/(70*Pi^2) - 
 (3*b1^2*b2*IntdqP112*dot[k1, k3]*P11[magM[k1]])/(10*Pi^2) + 
 (b1*b2^2*IntdqP112*dot[k1, k3]*P11[magM[k1]])/(7*Pi^2) + 
 (64*b1^2*b3*IntdqP112*dot[k1, k3]*P11[magM[k1]])/(315*Pi^2) - 
 (64*b1*b2*b3*IntdqP112*dot[k1, k3]*P11[magM[k1]])/(315*Pi^2) - 
 (103*b1^2*b5*IntdqP112*dot[k1, k3]*P11[magM[k1]])/(210*Pi^2) + 
 (10*b1*b2*b5*IntdqP112*dot[k1, k3]*P11[magM[k1]])/(21*Pi^2) - 
 (64*b1*b3*b5*IntdqP112*dot[k1, k3]*P11[magM[k1]])/(315*Pi^2) + 
 (b1*b5^2*IntdqP112*dot[k1, k3]*P11[magM[k1]])/(3*Pi^2) + 
 (64*b1^2*b8*IntdqP112*dot[k1, k3]*P11[magM[k1]])/(21*Pi^2) - 
 (64*b1*b2*b8*IntdqP112*dot[k1, k3]*P11[magM[k1]])/(21*Pi^2) - 
 (64*b1*b5*b8*IntdqP112*dot[k1, k3]*P11[magM[k1]])/(21*Pi^2) + 
 (19*b1^3*f1*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]*P11[magM[k1]])/
  (210*Pi^2) - (89*b1^2*b2*f1*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]*
   P11[magM[k1]])/(210*Pi^2) + (b1*b2^2*f1*IntdqP112*dot[k1, hat[z]]*
   dot[k2, hat[z]]*P11[magM[k1]])/(3*Pi^2) - 
 (89*b1^2*b5*f1*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]*P11[magM[k1]])/
  (210*Pi^2) + (2*b1*b2*b5*f1*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]*
   P11[magM[k1]])/(3*Pi^2) + (b1*b5^2*f1*IntdqP112*dot[k1, hat[z]]*
   dot[k2, hat[z]]*P11[magM[k1]])/(3*Pi^2) + 
 (16*b1^2*f1^2*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]*P11[magM[k1]])/
  (35*Pi^2) + (b1^3*f1^2*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]*
   P11[magM[k1]])/(3*Pi^2) - (16*b1*b2*f1^2*IntdqP112*dot[k1, hat[z]]*
   dot[k2, hat[z]]*P11[magM[k1]])/(35*Pi^2) - 
 (b1^2*b2*f1^2*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]*P11[magM[k1]])/
  (3*Pi^2) - (16*b1*b5*f1^2*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]*
   P11[magM[k1]])/(35*Pi^2) - (b1^2*b5*f1^2*IntdqP112*dot[k1, hat[z]]*
   dot[k2, hat[z]]*P11[magM[k1]])/(3*Pi^2) + 
 (179*b1^2*f1*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(1470*Pi^2) - 
 (b1^3*f1*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(35*Pi^2) - 
 (9*b1*b10*f1*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(14*Pi^2) + 
 (b1^2*b10*f1*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(2*Pi^2) + 
 (247*b1*b2*f1*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(735*Pi^2) - 
 (51*b1^2*b2*f1*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(70*Pi^2) + 
 (b1*b2^2*f1*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(3*Pi^2) - 
 (673*b1*b3*f1*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(1470*Pi^2) + 
 (89*b1^2*b3*f1*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(210*Pi^2) + 
 (3*b1*b5*f1*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(7*Pi^2) - 
 (23*b1^2*b5*f1*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(30*Pi^2) + 
 (2*b1*b2*b5*f1*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(3*Pi^2) + 
 (b1*b5^2*f1*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(3*Pi^2) - 
 (809*b1*b6*f1*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(735*Pi^2) + 
 (97*b1^2*b6*f1*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(105*Pi^2) - 
 (571*b1*b8*f1*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(735*Pi^2) + 
 (83*b1^2*b8*f1*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(105*Pi^2) + 
 (67*b1^2*f1^2*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(210*Pi^2) + 
 (b1^3*f1^2*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(6*Pi^2) - 
 (b1*b10*f1^2*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(2*Pi^2) + 
 (b1*b2*f1^2*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(35*Pi^2) - 
 (b1^2*b2*f1^2*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(6*Pi^2) - 
 (73*b1*b3*f1^2*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(210*Pi^2) + 
 (11*b1*b5*f1^2*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(105*Pi^2) - 
 (b1^2*b5*f1^2*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(6*Pi^2) - 
 (89*b1*b6*f1^2*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(105*Pi^2) - 
 (61*b1*b8*f1^2*IntdqP112*dot[k2, hat[z]]^2*P11[magM[k1]])/(105*Pi^2) + 
 (19*b1^3*f1*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]*P11[magM[k1]])/
  (210*Pi^2) - (89*b1^2*b2*f1*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]*
   P11[magM[k1]])/(210*Pi^2) + (b1*b2^2*f1*IntdqP112*dot[k1, hat[z]]*
   dot[k3, hat[z]]*P11[magM[k1]])/(3*Pi^2) - 
 (89*b1^2*b5*f1*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]*P11[magM[k1]])/
  (210*Pi^2) + (2*b1*b2*b5*f1*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]*
   P11[magM[k1]])/(3*Pi^2) + (b1*b5^2*f1*IntdqP112*dot[k1, hat[z]]*
   dot[k3, hat[z]]*P11[magM[k1]])/(3*Pi^2) + 
 (16*b1^2*f1^2*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]*P11[magM[k1]])/
  (35*Pi^2) + (b1^3*f1^2*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]*
   P11[magM[k1]])/(3*Pi^2) - (16*b1*b2*f1^2*IntdqP112*dot[k1, hat[z]]*
   dot[k3, hat[z]]*P11[magM[k1]])/(35*Pi^2) - 
 (b1^2*b2*f1^2*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]*P11[magM[k1]])/
  (3*Pi^2) - (16*b1*b5*f1^2*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]*
   P11[magM[k1]])/(35*Pi^2) - (b1^2*b5*f1^2*IntdqP112*dot[k1, hat[z]]*
   dot[k3, hat[z]]*P11[magM[k1]])/(3*Pi^2) + 
 (179*b1^2*f1*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(1470*Pi^2) - 
 (b1^3*f1*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(35*Pi^2) - 
 (9*b1*b10*f1*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(14*Pi^2) + 
 (b1^2*b10*f1*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(2*Pi^2) + 
 (247*b1*b2*f1*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(735*Pi^2) - 
 (51*b1^2*b2*f1*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(70*Pi^2) + 
 (b1*b2^2*f1*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(3*Pi^2) - 
 (673*b1*b3*f1*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(1470*Pi^2) + 
 (89*b1^2*b3*f1*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(210*Pi^2) + 
 (3*b1*b5*f1*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(7*Pi^2) - 
 (23*b1^2*b5*f1*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(30*Pi^2) + 
 (2*b1*b2*b5*f1*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(3*Pi^2) + 
 (b1*b5^2*f1*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(3*Pi^2) - 
 (809*b1*b6*f1*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(735*Pi^2) + 
 (97*b1^2*b6*f1*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(105*Pi^2) - 
 (571*b1*b8*f1*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(735*Pi^2) + 
 (83*b1^2*b8*f1*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(105*Pi^2) + 
 (67*b1^2*f1^2*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(210*Pi^2) + 
 (b1^3*f1^2*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(6*Pi^2) - 
 (b1*b10*f1^2*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(2*Pi^2) + 
 (b1*b2*f1^2*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(35*Pi^2) - 
 (b1^2*b2*f1^2*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(6*Pi^2) - 
 (73*b1*b3*f1^2*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(210*Pi^2) + 
 (11*b1*b5*f1^2*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(105*Pi^2) - 
 (b1^2*b5*f1^2*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(6*Pi^2) - 
 (89*b1*b6*f1^2*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(105*Pi^2) - 
 (61*b1*b8*f1^2*IntdqP112*dot[k3, hat[z]]^2*P11[magM[k1]])/(105*Pi^2) + 
 (b1^2*f1*Intdqq2P112*dot[k1, k2]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (Pi^2*magM[k1]^4) - (2*b1*b2*f1*Intdqq2P112*dot[k1, k2]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(Pi^2*magM[k1]^4) + 
 (b2^2*f1*Intdqq2P112*dot[k1, k2]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (Pi^2*magM[k1]^4) - (2*b1*b5*f1*Intdqq2P112*dot[k1, k2]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(Pi^2*magM[k1]^4) + 
 (2*b2*b5*f1*Intdqq2P112*dot[k1, k2]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (Pi^2*magM[k1]^4) + (b5^2*f1*Intdqq2P112*dot[k1, k2]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(Pi^2*magM[k1]^4) - 
 (b1^2*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^4) + (563*b1*b2*f1*IntdqP112*dot[k1, k2]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(1470*Pi^2*magM[k1]^4) - 
 (66*b2^2*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (245*Pi^2*magM[k1]^4) - (61*b1*b3*f1*IntdqP112*dot[k1, k2]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(315*Pi^2*magM[k1]^4) + 
 (187*b2*b3*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (2205*Pi^2*magM[k1]^4) + (17*b1*b5*f1*IntdqP112*dot[k1, k2]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(210*Pi^2*magM[k1]^4) - 
 (26*b2*b5*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) + (13*b3*b5*f1*IntdqP112*dot[k1, k2]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(315*Pi^2*magM[k1]^4) - 
 (4*b1*b6*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (15*Pi^2*magM[k1]^4) + (116*b2*b6*f1*IntdqP112*dot[k1, k2]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(735*Pi^2*magM[k1]^4) + 
 (4*b5*b6*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^4) - (32*b1*b8*f1*IntdqP112*dot[k1, k2]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) + 
 (4*b2*b8*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (735*Pi^2*magM[k1]^4) - (4*b5*b8*f1*IntdqP112*dot[k1, k2]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(35*Pi^2*magM[k1]^4) + 
 (4*b1^2*f1*Intdqq2P11P11pp*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) - (4*b2^2*f1*Intdqq2P11P11pp*dot[k1, k2]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) - 
 (8*b1*b3*f1*Intdqq2P11P11pp*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) + (8*b2*b3*f1*Intdqq2P11P11pp*dot[k1, k2]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) - 
 (4*b1*b5*f1*Intdqq2P11P11pp*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) - (4*b2*b5*f1*Intdqq2P11P11pp*dot[k1, k2]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) + 
 (8*b3*b5*f1*Intdqq2P11P11pp*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) - (8*b1*b6*f1*Intdqq2P11P11pp*dot[k1, k2]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) + 
 (8*b2*b6*f1*Intdqq2P11P11pp*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) + (8*b5*b6*f1*Intdqq2P11P11pp*dot[k1, k2]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) - 
 (22*b1*b8*f1*Intdqq2P11P11pp*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) + (22*b2*b8*f1*Intdqq2P11P11pp*dot[k1, k2]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) + 
 (22*b5*b8*f1*Intdqq2P11P11pp*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) + (8*b1^2*f1*IntdqqP11P11p*dot[k1, k2]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) - 
 (8*b2^2*f1*IntdqqP11P11p*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) - (16*b1*b3*f1*IntdqqP11P11p*dot[k1, k2]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) + 
 (16*b2*b3*f1*IntdqqP11P11p*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) - (8*b1*b5*f1*IntdqqP11P11p*dot[k1, k2]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) - 
 (8*b2*b5*f1*IntdqqP11P11p*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) + (16*b3*b5*f1*IntdqqP11P11p*dot[k1, k2]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) - 
 (16*b1*b6*f1*IntdqqP11P11p*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) + (16*b2*b6*f1*IntdqqP11P11p*dot[k1, k2]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) + 
 (16*b5*b6*f1*IntdqqP11P11p*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) - (44*b1*b8*f1*IntdqqP11P11p*dot[k1, k2]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) + 
 (44*b2*b8*f1*IntdqqP11P11p*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) + (44*b5*b8*f1*IntdqqP11P11p*dot[k1, k2]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) + 
 (b1^2*f1*Intdqq2P112*dot[k1, k3]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (Pi^2*magM[k1]^4) - (2*b1*b2*f1*Intdqq2P112*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(Pi^2*magM[k1]^4) + 
 (b2^2*f1*Intdqq2P112*dot[k1, k3]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (Pi^2*magM[k1]^4) - (2*b1*b5*f1*Intdqq2P112*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(Pi^2*magM[k1]^4) + 
 (2*b2*b5*f1*Intdqq2P112*dot[k1, k3]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (Pi^2*magM[k1]^4) + (b5^2*f1*Intdqq2P112*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(Pi^2*magM[k1]^4) + 
 (4*b1^2*f1*Intdqq2P11P11pp*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) - (4*b2^2*f1*Intdqq2P11P11pp*dot[k1, k3]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) - 
 (8*b1*b3*f1*Intdqq2P11P11pp*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) + (8*b2*b3*f1*Intdqq2P11P11pp*dot[k1, k3]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) - 
 (4*b1*b5*f1*Intdqq2P11P11pp*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) - (4*b2*b5*f1*Intdqq2P11P11pp*dot[k1, k3]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) + 
 (8*b3*b5*f1*Intdqq2P11P11pp*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) - (8*b1*b6*f1*Intdqq2P11P11pp*dot[k1, k3]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) + 
 (8*b2*b6*f1*Intdqq2P11P11pp*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) + (8*b5*b6*f1*Intdqq2P11P11pp*dot[k1, k3]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) - 
 (22*b1*b8*f1*Intdqq2P11P11pp*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) + (22*b2*b8*f1*Intdqq2P11P11pp*dot[k1, k3]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) + 
 (22*b5*b8*f1*Intdqq2P11P11pp*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) + (8*b1^2*f1*IntdqqP11P11p*dot[k1, k3]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) - 
 (8*b2^2*f1*IntdqqP11P11p*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) - (16*b1*b3*f1*IntdqqP11P11p*dot[k1, k3]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) + 
 (16*b2*b3*f1*IntdqqP11P11p*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) - (8*b1*b5*f1*IntdqqP11P11p*dot[k1, k3]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) - 
 (8*b2*b5*f1*IntdqqP11P11p*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) + (16*b3*b5*f1*IntdqqP11P11p*dot[k1, k3]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) - 
 (16*b1*b6*f1*IntdqqP11P11p*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) + (16*b2*b6*f1*IntdqqP11P11p*dot[k1, k3]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) + 
 (16*b5*b6*f1*IntdqqP11P11p*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) - (44*b1*b8*f1*IntdqqP11P11p*dot[k1, k3]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) + 
 (44*b2*b8*f1*IntdqqP11P11p*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) + (44*b5*b8*f1*IntdqqP11P11p*dot[k1, k3]^2*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) + 
 (2*b1^2*f1^2*Intdqq2P112*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (Pi^2*magM[k1]^4) - (4*b1*b2*f1^2*Intdqq2P112*dot[k1, hat[z]]^4*
   P11[magM[k1]])/(Pi^2*magM[k1]^4) + 
 (2*b2^2*f1^2*Intdqq2P112*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (Pi^2*magM[k1]^4) - (4*b1*b5*f1^2*Intdqq2P112*dot[k1, hat[z]]^4*
   P11[magM[k1]])/(Pi^2*magM[k1]^4) + 
 (4*b2*b5*f1^2*Intdqq2P112*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (Pi^2*magM[k1]^4) + (2*b5^2*f1^2*Intdqq2P112*dot[k1, hat[z]]^4*
   P11[magM[k1]])/(Pi^2*magM[k1]^4) - 
 (23*b1^2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^4) + (3*b1*b2*f1^2*IntdqP112*dot[k1, k3]*
   dot[k1, hat[z]]^4*P11[magM[k1]])/(10*Pi^2*magM[k1]^4) - 
 (4*b2^2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^4) + (23*b1*b5*f1^2*IntdqP112*dot[k1, k3]*
   dot[k1, hat[z]]^4*P11[magM[k1]])/(210*Pi^2*magM[k1]^4) - 
 (4*b2*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^4) + (b1*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*
   P11[magM[k1]])/(6*Pi^2*magM[k1]^4) - 
 (b2*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^4) - (b5*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*
   P11[magM[k1]])/(6*Pi^2*magM[k1]^4) + 
 (b1^2*f1^2*Intdqq2P112*dot[k1, hat[z]]^3*dot[k2, hat[z]]*P11[magM[k1]])/
  (Pi^2*magM[k1]^4) - (2*b1*b2*f1^2*Intdqq2P112*dot[k1, hat[z]]^3*
   dot[k2, hat[z]]*P11[magM[k1]])/(Pi^2*magM[k1]^4) + 
 (b2^2*f1^2*Intdqq2P112*dot[k1, hat[z]]^3*dot[k2, hat[z]]*P11[magM[k1]])/
  (Pi^2*magM[k1]^4) - (2*b1*b5*f1^2*Intdqq2P112*dot[k1, hat[z]]^3*
   dot[k2, hat[z]]*P11[magM[k1]])/(Pi^2*magM[k1]^4) + 
 (2*b2*b5*f1^2*Intdqq2P112*dot[k1, hat[z]]^3*dot[k2, hat[z]]*P11[magM[k1]])/
  (Pi^2*magM[k1]^4) + (b5^2*f1^2*Intdqq2P112*dot[k1, hat[z]]^3*
   dot[k2, hat[z]]*P11[magM[k1]])/(Pi^2*magM[k1]^4) - 
 (b1^2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
   P11[magM[k1]])/(5*Pi^2*magM[k1]^4) + 
 (19*b1*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
   P11[magM[k1]])/(35*Pi^2*magM[k1]^4) - 
 (4*b2^2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^4) - 
 (16*b1*b3*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4) + 
 (29*b1*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4) - 
 (4*b2*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^4) - 
 (16*b1*b6*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4) - 
 (44*b1*b8*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4) + 
 (b1*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) - 
 (b2*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) - 
 (b5*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) + 
 (137*b1*f1^3*IntdqP112*dot[k1, hat[z]]^5*dot[k2, hat[z]]*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^4) - (b1^2*f1^3*IntdqP112*dot[k1, hat[z]]^5*
   dot[k2, hat[z]]*P11[magM[k1]])/(6*Pi^2*magM[k1]^4) - 
 (137*b2*f1^3*IntdqP112*dot[k1, hat[z]]^5*dot[k2, hat[z]]*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^4) + (b1*b2*f1^3*IntdqP112*dot[k1, hat[z]]^5*
   dot[k2, hat[z]]*P11[magM[k1]])/(6*Pi^2*magM[k1]^4) - 
 (137*b5*f1^3*IntdqP112*dot[k1, hat[z]]^5*dot[k2, hat[z]]*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^4) + (b1*b5*f1^3*IntdqP112*dot[k1, hat[z]]^5*
   dot[k2, hat[z]]*P11[magM[k1]])/(6*Pi^2*magM[k1]^4) + 
 (b1*f1^4*IntdqP112*dot[k1, hat[z]]^5*dot[k2, hat[z]]*P11[magM[k1]])/
  (2*Pi^2*magM[k1]^4) - (b2*f1^4*IntdqP112*dot[k1, hat[z]]^5*dot[k2, hat[z]]*
   P11[magM[k1]])/(2*Pi^2*magM[k1]^4) - 
 (b5*f1^4*IntdqP112*dot[k1, hat[z]]^5*dot[k2, hat[z]]*P11[magM[k1]])/
  (2*Pi^2*magM[k1]^4) + (9*b1*f1^3*IntdqP112*dot[k1, hat[z]]^4*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(10*Pi^2*magM[k1]^4) - 
 (b1^2*f1^3*IntdqP112*dot[k1, hat[z]]^4*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (2*Pi^2*magM[k1]^4) - (173*b2*f1^3*IntdqP112*dot[k1, hat[z]]^4*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(210*Pi^2*magM[k1]^4) + 
 (b1*b2*f1^3*IntdqP112*dot[k1, hat[z]]^4*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (2*Pi^2*magM[k1]^4) - (8*b3*f1^3*IntdqP112*dot[k1, hat[z]]^4*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) - 
 (181*b5*f1^3*IntdqP112*dot[k1, hat[z]]^4*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^4) + (b1*b5*f1^3*IntdqP112*dot[k1, hat[z]]^4*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(2*Pi^2*magM[k1]^4) - 
 (8*b6*f1^3*IntdqP112*dot[k1, hat[z]]^4*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) - (22*b8*f1^3*IntdqP112*dot[k1, hat[z]]^4*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) + 
 (2*b1*f1^4*IntdqP112*dot[k1, hat[z]]^4*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4) - (2*b2*f1^4*IntdqP112*dot[k1, hat[z]]^4*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4) - 
 (2*b5*f1^4*IntdqP112*dot[k1, hat[z]]^4*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4) + (3*b1*f1^3*IntdqP112*dot[k1, hat[z]]^3*
   dot[k2, hat[z]]^3*P11[magM[k1]])/(7*Pi^2*magM[k1]^4) - 
 (b1^2*f1^3*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]^3*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4) - (3*b2*f1^3*IntdqP112*dot[k1, hat[z]]^3*
   dot[k2, hat[z]]^3*P11[magM[k1]])/(7*Pi^2*magM[k1]^4) + 
 (b1*b2*f1^3*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]^3*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4) - (3*b5*f1^3*IntdqP112*dot[k1, hat[z]]^3*
   dot[k2, hat[z]]^3*P11[magM[k1]])/(7*Pi^2*magM[k1]^4) + 
 (b1*b5*f1^3*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]^3*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4) + (b1*f1^4*IntdqP112*dot[k1, hat[z]]^3*
   dot[k2, hat[z]]^3*P11[magM[k1]])/(3*Pi^2*magM[k1]^4) - 
 (b2*f1^4*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]^3*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4) - (b5*f1^4*IntdqP112*dot[k1, hat[z]]^3*
   dot[k2, hat[z]]^3*P11[magM[k1]])/(3*Pi^2*magM[k1]^4) + 
 (b1^2*f1^2*Intdqq2P112*dot[k1, hat[z]]^3*dot[k3, hat[z]]*P11[magM[k1]])/
  (Pi^2*magM[k1]^4) - (2*b1*b2*f1^2*Intdqq2P112*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*P11[magM[k1]])/(Pi^2*magM[k1]^4) + 
 (b2^2*f1^2*Intdqq2P112*dot[k1, hat[z]]^3*dot[k3, hat[z]]*P11[magM[k1]])/
  (Pi^2*magM[k1]^4) - (2*b1*b5*f1^2*Intdqq2P112*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*P11[magM[k1]])/(Pi^2*magM[k1]^4) + 
 (2*b2*b5*f1^2*Intdqq2P112*dot[k1, hat[z]]^3*dot[k3, hat[z]]*P11[magM[k1]])/
  (Pi^2*magM[k1]^4) + (b5^2*f1^2*Intdqq2P112*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*P11[magM[k1]])/(Pi^2*magM[k1]^4) + 
 (137*b1*f1^3*IntdqP112*dot[k1, hat[z]]^5*dot[k3, hat[z]]*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^4) - (b1^2*f1^3*IntdqP112*dot[k1, hat[z]]^5*
   dot[k3, hat[z]]*P11[magM[k1]])/(6*Pi^2*magM[k1]^4) - 
 (137*b2*f1^3*IntdqP112*dot[k1, hat[z]]^5*dot[k3, hat[z]]*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^4) + (b1*b2*f1^3*IntdqP112*dot[k1, hat[z]]^5*
   dot[k3, hat[z]]*P11[magM[k1]])/(6*Pi^2*magM[k1]^4) - 
 (137*b5*f1^3*IntdqP112*dot[k1, hat[z]]^5*dot[k3, hat[z]]*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^4) + (b1*b5*f1^3*IntdqP112*dot[k1, hat[z]]^5*
   dot[k3, hat[z]]*P11[magM[k1]])/(6*Pi^2*magM[k1]^4) + 
 (b1*f1^4*IntdqP112*dot[k1, hat[z]]^5*dot[k3, hat[z]]*P11[magM[k1]])/
  (2*Pi^2*magM[k1]^4) - (b2*f1^4*IntdqP112*dot[k1, hat[z]]^5*dot[k3, hat[z]]*
   P11[magM[k1]])/(2*Pi^2*magM[k1]^4) - 
 (b5*f1^4*IntdqP112*dot[k1, hat[z]]^5*dot[k3, hat[z]]*P11[magM[k1]])/
  (2*Pi^2*magM[k1]^4) + (9*b1*f1^3*IntdqP112*dot[k1, hat[z]]^4*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(10*Pi^2*magM[k1]^4) - 
 (b1^2*f1^3*IntdqP112*dot[k1, hat[z]]^4*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (2*Pi^2*magM[k1]^4) - (173*b2*f1^3*IntdqP112*dot[k1, hat[z]]^4*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(210*Pi^2*magM[k1]^4) + 
 (b1*b2*f1^3*IntdqP112*dot[k1, hat[z]]^4*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (2*Pi^2*magM[k1]^4) - (8*b3*f1^3*IntdqP112*dot[k1, hat[z]]^4*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) - 
 (181*b5*f1^3*IntdqP112*dot[k1, hat[z]]^4*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^4) + (b1*b5*f1^3*IntdqP112*dot[k1, hat[z]]^4*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(2*Pi^2*magM[k1]^4) - 
 (8*b6*f1^3*IntdqP112*dot[k1, hat[z]]^4*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4) - (22*b8*f1^3*IntdqP112*dot[k1, hat[z]]^4*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4) + 
 (2*b1*f1^4*IntdqP112*dot[k1, hat[z]]^4*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4) - (2*b2*f1^4*IntdqP112*dot[k1, hat[z]]^4*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4) - 
 (2*b5*f1^4*IntdqP112*dot[k1, hat[z]]^4*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4) + (3*b1*f1^3*IntdqP112*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]^3*P11[magM[k1]])/(7*Pi^2*magM[k1]^4) - 
 (b1^2*f1^3*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]^3*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4) - (3*b2*f1^3*IntdqP112*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]^3*P11[magM[k1]])/(7*Pi^2*magM[k1]^4) + 
 (b1*b2*f1^3*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]^3*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4) - (3*b5*f1^3*IntdqP112*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]^3*P11[magM[k1]])/(7*Pi^2*magM[k1]^4) + 
 (b1*b5*f1^3*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]^3*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4) + (b1*f1^4*IntdqP112*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]^3*P11[magM[k1]])/(3*Pi^2*magM[k1]^4) - 
 (b2*f1^4*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]^3*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4) - (b5*f1^4*IntdqP112*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]^3*P11[magM[k1]])/(3*Pi^2*magM[k1]^4) + 
 (b1^3*Intdqq2P112*dot[k1, k2]*P11[magM[k1]])/(Pi^2*magM[k1]^2) - 
 (2*b1^2*b2*Intdqq2P112*dot[k1, k2]*P11[magM[k1]])/(Pi^2*magM[k1]^2) + 
 (b1*b2^2*Intdqq2P112*dot[k1, k2]*P11[magM[k1]])/(Pi^2*magM[k1]^2) - 
 (2*b1^2*b5*Intdqq2P112*dot[k1, k2]*P11[magM[k1]])/(Pi^2*magM[k1]^2) + 
 (2*b1*b2*b5*Intdqq2P112*dot[k1, k2]*P11[magM[k1]])/(Pi^2*magM[k1]^2) + 
 (b1*b5^2*Intdqq2P112*dot[k1, k2]*P11[magM[k1]])/(Pi^2*magM[k1]^2) - 
 (b1^3*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/(210*Pi^2*magM[k1]^2) + 
 (563*b1^2*b2*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/(1470*Pi^2*magM[k1]^2) - 
 (66*b1*b2^2*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/(245*Pi^2*magM[k1]^2) - 
 (61*b1^2*b3*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/(315*Pi^2*magM[k1]^2) + 
 (187*b1*b2*b3*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/
  (2205*Pi^2*magM[k1]^2) + (17*b1^2*b5*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^2) - (26*b1*b2*b5*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (13*b1*b3*b5*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/
  (315*Pi^2*magM[k1]^2) - (4*b1^2*b6*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/
  (15*Pi^2*magM[k1]^2) + (116*b1*b2*b6*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/
  (735*Pi^2*magM[k1]^2) + (4*b1*b5*b6*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2) - (32*b1^2*b8*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (4*b1*b2*b8*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/
  (735*Pi^2*magM[k1]^2) - (4*b1*b5*b8*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2) + (4*b1^3*Intdqq2P11P11pp*dot[k1, k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) - (4*b1*b2^2*Intdqq2P11P11pp*dot[k1, k2]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) - 
 (8*b1^2*b3*Intdqq2P11P11pp*dot[k1, k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (8*b1*b2*b3*Intdqq2P11P11pp*dot[k1, k2]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) - 
 (4*b1^2*b5*Intdqq2P11P11pp*dot[k1, k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) - (4*b1*b2*b5*Intdqq2P11P11pp*dot[k1, k2]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (8*b1*b3*b5*Intdqq2P11P11pp*dot[k1, k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) - (8*b1^2*b6*Intdqq2P11P11pp*dot[k1, k2]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (8*b1*b2*b6*Intdqq2P11P11pp*dot[k1, k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (8*b1*b5*b6*Intdqq2P11P11pp*dot[k1, k2]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) - 
 (22*b1^2*b8*Intdqq2P11P11pp*dot[k1, k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (22*b1*b2*b8*Intdqq2P11P11pp*dot[k1, k2]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (22*b1*b5*b8*Intdqq2P11P11pp*dot[k1, k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (8*b1^3*IntdqqP11P11p*dot[k1, k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) - (8*b1*b2^2*IntdqqP11P11p*dot[k1, k2]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) - 
 (16*b1^2*b3*IntdqqP11P11p*dot[k1, k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (16*b1*b2*b3*IntdqqP11P11p*dot[k1, k2]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) - 
 (8*b1^2*b5*IntdqqP11P11p*dot[k1, k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) - (8*b1*b2*b5*IntdqqP11P11p*dot[k1, k2]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (16*b1*b3*b5*IntdqqP11P11p*dot[k1, k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) - (16*b1^2*b6*IntdqqP11P11p*dot[k1, k2]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (16*b1*b2*b6*IntdqqP11P11p*dot[k1, k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (16*b1*b5*b6*IntdqqP11P11p*dot[k1, k2]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) - 
 (44*b1^2*b8*IntdqqP11P11p*dot[k1, k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (44*b1*b2*b8*IntdqqP11P11p*dot[k1, k2]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (44*b1*b5*b8*IntdqqP11P11p*dot[k1, k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (b1^3*Intdqq2P112*dot[k1, k3]*P11[magM[k1]])/
  (Pi^2*magM[k1]^2) - (2*b1^2*b2*Intdqq2P112*dot[k1, k3]*P11[magM[k1]])/
  (Pi^2*magM[k1]^2) + (b1*b2^2*Intdqq2P112*dot[k1, k3]*P11[magM[k1]])/
  (Pi^2*magM[k1]^2) - (2*b1^2*b5*Intdqq2P112*dot[k1, k3]*P11[magM[k1]])/
  (Pi^2*magM[k1]^2) + (2*b1*b2*b5*Intdqq2P112*dot[k1, k3]*P11[magM[k1]])/
  (Pi^2*magM[k1]^2) + (b1*b5^2*Intdqq2P112*dot[k1, k3]*P11[magM[k1]])/
  (Pi^2*magM[k1]^2) + (4*b1^3*Intdqq2P11P11pp*dot[k1, k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) - (4*b1*b2^2*Intdqq2P11P11pp*dot[k1, k3]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) - 
 (8*b1^2*b3*Intdqq2P11P11pp*dot[k1, k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (8*b1*b2*b3*Intdqq2P11P11pp*dot[k1, k3]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) - 
 (4*b1^2*b5*Intdqq2P11P11pp*dot[k1, k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) - (4*b1*b2*b5*Intdqq2P11P11pp*dot[k1, k3]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (8*b1*b3*b5*Intdqq2P11P11pp*dot[k1, k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) - (8*b1^2*b6*Intdqq2P11P11pp*dot[k1, k3]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (8*b1*b2*b6*Intdqq2P11P11pp*dot[k1, k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (8*b1*b5*b6*Intdqq2P11P11pp*dot[k1, k3]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) - 
 (22*b1^2*b8*Intdqq2P11P11pp*dot[k1, k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (22*b1*b2*b8*Intdqq2P11P11pp*dot[k1, k3]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (22*b1*b5*b8*Intdqq2P11P11pp*dot[k1, k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (8*b1^3*IntdqqP11P11p*dot[k1, k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) - (8*b1*b2^2*IntdqqP11P11p*dot[k1, k3]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) - 
 (16*b1^2*b3*IntdqqP11P11p*dot[k1, k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (16*b1*b2*b3*IntdqqP11P11p*dot[k1, k3]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) - 
 (8*b1^2*b5*IntdqqP11P11p*dot[k1, k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) - (8*b1*b2*b5*IntdqqP11P11p*dot[k1, k3]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (16*b1*b3*b5*IntdqqP11P11p*dot[k1, k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) - (16*b1^2*b6*IntdqqP11P11p*dot[k1, k3]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (16*b1*b2*b6*IntdqqP11P11p*dot[k1, k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (16*b1*b5*b6*IntdqqP11P11p*dot[k1, k3]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) - 
 (44*b1^2*b8*IntdqqP11P11p*dot[k1, k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (44*b1*b2*b8*IntdqqP11P11p*dot[k1, k3]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (44*b1*b5*b8*IntdqqP11P11p*dot[k1, k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (26*b1^2*f1*Intdqq2P112*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^2) + 
 (2*b1^3*f1*Intdqq2P112*dot[k1, hat[z]]^2*P11[magM[k1]])/(Pi^2*magM[k1]^2) - 
 (6*b1*b10*f1*Intdqq2P112*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (Pi^2*magM[k1]^2) + (2*b1*b2*f1*Intdqq2P112*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(Pi^2*magM[k1]^2) - 
 (4*b1^2*b2*f1*Intdqq2P112*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (Pi^2*magM[k1]^2) + (6*b10*b2*f1*Intdqq2P112*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(Pi^2*magM[k1]^2) - 
 (68*b2^2*f1*Intdqq2P112*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2) + (2*b1*b2^2*f1*Intdqq2P112*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(Pi^2*magM[k1]^2) - 
 (94*b1*b3*f1*Intdqq2P112*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2) + (94*b2*b3*f1*Intdqq2P112*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^2) + 
 (58*b1*b5*f1*Intdqq2P112*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2) - (4*b1^2*b5*f1*Intdqq2P112*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(Pi^2*magM[k1]^2) + 
 (6*b10*b5*f1*Intdqq2P112*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (Pi^2*magM[k1]^2) - (152*b2*b5*f1*Intdqq2P112*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^2) + 
 (4*b1*b2*b5*f1*Intdqq2P112*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (Pi^2*magM[k1]^2) + (94*b3*b5*f1*Intdqq2P112*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^2) - 
 (4*b5^2*f1*Intdqq2P112*dot[k1, hat[z]]^2*P11[magM[k1]])/(Pi^2*magM[k1]^2) + 
 (2*b1*b5^2*f1*Intdqq2P112*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (Pi^2*magM[k1]^2) - (220*b1*b6*f1*Intdqq2P112*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^2) + 
 (220*b2*b6*f1*Intdqq2P112*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2) + (220*b5*b6*f1*Intdqq2P112*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^2) - 
 (164*b1*b8*f1*Intdqq2P112*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2) + (164*b2*b8*f1*Intdqq2P112*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^2) + 
 (164*b5*b8*f1*Intdqq2P112*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2) + (11*b1^2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(70*Pi^2*magM[k1]^2) - 
 (23*b1^3*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^2) - (3*b1*b2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(10*Pi^2*magM[k1]^2) + 
 (3*b1^2*b2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (10*Pi^2*magM[k1]^2) + (b2^2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(7*Pi^2*magM[k1]^2) - 
 (4*b1*b2^2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2) + (64*b1*b3*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(315*Pi^2*magM[k1]^2) - 
 (64*b2*b3*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (315*Pi^2*magM[k1]^2) - (103*b1*b5*f1*IntdqP112*dot[k1, k3]*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(210*Pi^2*magM[k1]^2) + 
 (23*b1^2*b5*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^2) + (10*b2*b5*f1*IntdqP112*dot[k1, k3]*
   dot[k1, hat[z]]^2*P11[magM[k1]])/(21*Pi^2*magM[k1]^2) - 
 (4*b1*b2*b5*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2) - (64*b3*b5*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(315*Pi^2*magM[k1]^2) + 
 (b5^2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) + (64*b1*b8*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^2) - 
 (64*b2*b8*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2) - (64*b5*b8*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^2) + 
 (b1^2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^2) - (b1*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(6*Pi^2*magM[k1]^2) - 
 (b1*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^2) + (b1^3*f1*Intdqq2P112*dot[k1, hat[z]]*dot[k2, hat[z]]*
   P11[magM[k1]])/(Pi^2*magM[k1]^2) - 
 (2*b1^2*b2*f1*Intdqq2P112*dot[k1, hat[z]]*dot[k2, hat[z]]*P11[magM[k1]])/
  (Pi^2*magM[k1]^2) + (b1*b2^2*f1*Intdqq2P112*dot[k1, hat[z]]*dot[k2, hat[z]]*
   P11[magM[k1]])/(Pi^2*magM[k1]^2) - 
 (2*b1^2*b5*f1*Intdqq2P112*dot[k1, hat[z]]*dot[k2, hat[z]]*P11[magM[k1]])/
  (Pi^2*magM[k1]^2) + (2*b1*b2*b5*f1*Intdqq2P112*dot[k1, hat[z]]*
   dot[k2, hat[z]]*P11[magM[k1]])/(Pi^2*magM[k1]^2) + 
 (b1*b5^2*f1*Intdqq2P112*dot[k1, hat[z]]*dot[k2, hat[z]]*P11[magM[k1]])/
  (Pi^2*magM[k1]^2) - (b1^3*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]*
   dot[k2, hat[z]]*P11[magM[k1]])/(5*Pi^2*magM[k1]^2) + 
 (19*b1^2*b2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*
   P11[magM[k1]])/(35*Pi^2*magM[k1]^2) - 
 (4*b1*b2^2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^2) - 
 (16*b1^2*b3*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (29*b1^2*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) - 
 (4*b1*b2*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^2) - 
 (16*b1^2*b6*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) - 
 (44*b1^2*b8*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (b1^2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) - 
 (b1*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) - 
 (b1*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (26*b1^2*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2) - (b1^3*f1^2*IntdqP112*dot[k1, hat[z]]^3*
   dot[k2, hat[z]]*P11[magM[k1]])/(6*Pi^2*magM[k1]^2) - 
 (113*b1*b2*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (b1^2*b2*f1^2*IntdqP112*dot[k1, hat[z]]^3*
   dot[k2, hat[z]]*P11[magM[k1]])/(6*Pi^2*magM[k1]^2) + 
 (b2^2*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) - (113*b1*b5*f1^2*IntdqP112*dot[k1, hat[z]]^3*
   dot[k2, hat[z]]*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (b1^2*b5*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^2) + (2*b2*b5*f1^2*IntdqP112*dot[k1, hat[z]]^3*
   dot[k2, hat[z]]*P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (b5^2*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) + (16*b1*f1^3*IntdqP112*dot[k1, hat[z]]^3*
   dot[k2, hat[z]]*P11[magM[k1]])/(35*Pi^2*magM[k1]^2) + 
 (5*b1^2*f1^3*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^2) - (16*b2*f1^3*IntdqP112*dot[k1, hat[z]]^3*
   dot[k2, hat[z]]*P11[magM[k1]])/(35*Pi^2*magM[k1]^2) - 
 (5*b1*b2*f1^3*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^2) - (16*b5*f1^3*IntdqP112*dot[k1, hat[z]]^3*
   dot[k2, hat[z]]*P11[magM[k1]])/(35*Pi^2*magM[k1]^2) - 
 (5*b1*b5*f1^3*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^2) + (179*b1*f1^2*IntdqP112*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(1470*Pi^2*magM[k1]^2) + 
 (61*b1^2*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (70*Pi^2*magM[k1]^2) - (b1^3*f1^2*IntdqP112*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(2*Pi^2*magM[k1]^2) - 
 (9*b10*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (14*Pi^2*magM[k1]^2) + (b1*b10*f1^2*IntdqP112*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(2*Pi^2*magM[k1]^2) + 
 (247*b2*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (735*Pi^2*magM[k1]^2) - (163*b1*b2*f1^2*IntdqP112*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (b1^2*b2*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (2*Pi^2*magM[k1]^2) + (b2^2*f1^2*IntdqP112*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2) - 
 (673*b3*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (1470*Pi^2*magM[k1]^2) + (73*b1*b3*f1^2*IntdqP112*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(210*Pi^2*magM[k1]^2) + 
 (3*b5*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (7*Pi^2*magM[k1]^2) - (57*b1*b5*f1^2*IntdqP112*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(35*Pi^2*magM[k1]^2) + 
 (b1^2*b5*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (2*Pi^2*magM[k1]^2) + (2*b2*b5*f1^2*IntdqP112*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (b5^2*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) - (809*b6*f1^2*IntdqP112*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(735*Pi^2*magM[k1]^2) + 
 (89*b1*b6*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) - (571*b8*f1^2*IntdqP112*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(735*Pi^2*magM[k1]^2) + 
 (61*b1*b8*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (67*b1*f1^3*IntdqP112*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(210*Pi^2*magM[k1]^2) + 
 (5*b1^2*f1^3*IntdqP112*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^2) - (b10*f1^3*IntdqP112*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(2*Pi^2*magM[k1]^2) + 
 (b2*f1^3*IntdqP112*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2) - (5*b1*b2*f1^3*IntdqP112*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(6*Pi^2*magM[k1]^2) - 
 (73*b3*f1^3*IntdqP112*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^2) + (11*b5*f1^3*IntdqP112*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) - 
 (5*b1*b5*f1^3*IntdqP112*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^2) - (89*b6*f1^3*IntdqP112*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) - 
 (61*b8*f1^3*IntdqP112*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (3*b1^2*f1^2*IntdqP112*dot[k1, hat[z]]*
   dot[k2, hat[z]]^3*P11[magM[k1]])/(7*Pi^2*magM[k1]^2) - 
 (b1^3*f1^2*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]^3*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) - (3*b1*b2*f1^2*IntdqP112*dot[k1, hat[z]]*
   dot[k2, hat[z]]^3*P11[magM[k1]])/(7*Pi^2*magM[k1]^2) + 
 (b1^2*b2*f1^2*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]^3*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) - (3*b1*b5*f1^2*IntdqP112*dot[k1, hat[z]]*
   dot[k2, hat[z]]^3*P11[magM[k1]])/(7*Pi^2*magM[k1]^2) + 
 (b1^2*b5*f1^2*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]^3*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) + (b1^2*f1^3*IntdqP112*dot[k1, hat[z]]*
   dot[k2, hat[z]]^3*P11[magM[k1]])/(3*Pi^2*magM[k1]^2) - 
 (b1*b2*f1^3*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]^3*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) - (b1*b5*f1^3*IntdqP112*dot[k1, hat[z]]*
   dot[k2, hat[z]]^3*P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (b1^3*f1*Intdqq2P112*dot[k1, hat[z]]*dot[k3, hat[z]]*P11[magM[k1]])/
  (Pi^2*magM[k1]^2) - (2*b1^2*b2*f1*Intdqq2P112*dot[k1, hat[z]]*
   dot[k3, hat[z]]*P11[magM[k1]])/(Pi^2*magM[k1]^2) + 
 (b1*b2^2*f1*Intdqq2P112*dot[k1, hat[z]]*dot[k3, hat[z]]*P11[magM[k1]])/
  (Pi^2*magM[k1]^2) - (2*b1^2*b5*f1*Intdqq2P112*dot[k1, hat[z]]*
   dot[k3, hat[z]]*P11[magM[k1]])/(Pi^2*magM[k1]^2) + 
 (2*b1*b2*b5*f1*Intdqq2P112*dot[k1, hat[z]]*dot[k3, hat[z]]*P11[magM[k1]])/
  (Pi^2*magM[k1]^2) + (b1*b5^2*f1*Intdqq2P112*dot[k1, hat[z]]*dot[k3, hat[z]]*
   P11[magM[k1]])/(Pi^2*magM[k1]^2) + 
 (26*b1^2*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2) - (b1^3*f1^2*IntdqP112*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*P11[magM[k1]])/(6*Pi^2*magM[k1]^2) - 
 (113*b1*b2*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (b1^2*b2*f1^2*IntdqP112*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*P11[magM[k1]])/(6*Pi^2*magM[k1]^2) + 
 (b2^2*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) - (113*b1*b5*f1^2*IntdqP112*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (b1^2*b5*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^2) + (2*b2*b5*f1^2*IntdqP112*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (b5^2*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) + (16*b1*f1^3*IntdqP112*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*P11[magM[k1]])/(35*Pi^2*magM[k1]^2) + 
 (5*b1^2*f1^3*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^2) - (16*b2*f1^3*IntdqP112*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*P11[magM[k1]])/(35*Pi^2*magM[k1]^2) - 
 (5*b1*b2*f1^3*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^2) - (16*b5*f1^3*IntdqP112*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*P11[magM[k1]])/(35*Pi^2*magM[k1]^2) - 
 (5*b1*b5*f1^3*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^2) + (179*b1*f1^2*IntdqP112*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(1470*Pi^2*magM[k1]^2) + 
 (61*b1^2*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (70*Pi^2*magM[k1]^2) - (b1^3*f1^2*IntdqP112*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(2*Pi^2*magM[k1]^2) - 
 (9*b10*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (14*Pi^2*magM[k1]^2) + (b1*b10*f1^2*IntdqP112*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(2*Pi^2*magM[k1]^2) + 
 (247*b2*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (735*Pi^2*magM[k1]^2) - (163*b1*b2*f1^2*IntdqP112*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (b1^2*b2*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (2*Pi^2*magM[k1]^2) + (b2^2*f1^2*IntdqP112*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2) - 
 (673*b3*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (1470*Pi^2*magM[k1]^2) + (73*b1*b3*f1^2*IntdqP112*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(210*Pi^2*magM[k1]^2) + 
 (3*b5*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (7*Pi^2*magM[k1]^2) - (57*b1*b5*f1^2*IntdqP112*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(35*Pi^2*magM[k1]^2) + 
 (b1^2*b5*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (2*Pi^2*magM[k1]^2) + (2*b2*b5*f1^2*IntdqP112*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (b5^2*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) - (809*b6*f1^2*IntdqP112*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(735*Pi^2*magM[k1]^2) + 
 (89*b1*b6*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) - (571*b8*f1^2*IntdqP112*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(735*Pi^2*magM[k1]^2) + 
 (61*b1*b8*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (67*b1*f1^3*IntdqP112*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(210*Pi^2*magM[k1]^2) + 
 (5*b1^2*f1^3*IntdqP112*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^2) - (b10*f1^3*IntdqP112*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(2*Pi^2*magM[k1]^2) + 
 (b2*f1^3*IntdqP112*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2) - (5*b1*b2*f1^3*IntdqP112*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(6*Pi^2*magM[k1]^2) - 
 (73*b3*f1^3*IntdqP112*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^2) + (11*b5*f1^3*IntdqP112*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) - 
 (5*b1*b5*f1^3*IntdqP112*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^2) - (89*b6*f1^3*IntdqP112*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) - 
 (61*b8*f1^3*IntdqP112*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (3*b1^2*f1^2*IntdqP112*dot[k1, hat[z]]*
   dot[k3, hat[z]]^3*P11[magM[k1]])/(7*Pi^2*magM[k1]^2) - 
 (b1^3*f1^2*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]^3*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) - (3*b1*b2*f1^2*IntdqP112*dot[k1, hat[z]]*
   dot[k3, hat[z]]^3*P11[magM[k1]])/(7*Pi^2*magM[k1]^2) + 
 (b1^2*b2*f1^2*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]^3*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) - (3*b1*b5*f1^2*IntdqP112*dot[k1, hat[z]]*
   dot[k3, hat[z]]^3*P11[magM[k1]])/(7*Pi^2*magM[k1]^2) + 
 (b1^2*b5*f1^2*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]^3*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) + (b1^2*f1^3*IntdqP112*dot[k1, hat[z]]*
   dot[k3, hat[z]]^3*P11[magM[k1]])/(3*Pi^2*magM[k1]^2) - 
 (b1*b2*f1^3*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]^3*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) - (b1*b5*f1^3*IntdqP112*dot[k1, hat[z]]*
   dot[k3, hat[z]]^3*P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (8*b1*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(245*Pi^2*magM[k1]^4*magM[k2]^2) + 
 (8*b2*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(245*Pi^2*magM[k1]^4*magM[k2]^2) - 
 (16*b3*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(245*Pi^2*magM[k1]^4*magM[k2]^2) - 
 (16*b6*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(245*Pi^2*magM[k1]^4*magM[k2]^2) - 
 (44*b8*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(245*Pi^2*magM[k1]^4*magM[k2]^2) + 
 (8*b1^2*f1*IntdqP112*dot[k1, k2]^2*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (245*Pi^2*magM[k1]^2*magM[k2]^2) + 
 (8*b1*b2*f1*IntdqP112*dot[k1, k2]^2*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (245*Pi^2*magM[k1]^2*magM[k2]^2) - 
 (16*b1*b3*f1*IntdqP112*dot[k1, k2]^2*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (245*Pi^2*magM[k1]^2*magM[k2]^2) - 
 (16*b1*b6*f1*IntdqP112*dot[k1, k2]^2*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (245*Pi^2*magM[k1]^2*magM[k2]^2) - 
 (44*b1*b8*f1*IntdqP112*dot[k1, k2]^2*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (245*Pi^2*magM[k1]^2*magM[k2]^2) - 
 (43*b1^3*IntdqP112*magM[k2]^2*P11[magM[k1]])/(210*Pi^2) + 
 (b1^2*b10*IntdqP112*magM[k2]^2*P11[magM[k1]])/(2*Pi^2) - 
 (328*b1^2*b2*IntdqP112*magM[k2]^2*P11[magM[k1]])/(735*Pi^2) - 
 (4*b1*b10*b2*IntdqP112*magM[k2]^2*P11[magM[k1]])/(7*Pi^2) + 
 (491*b1*b2^2*IntdqP112*magM[k2]^2*P11[magM[k1]])/(735*Pi^2) + 
 (61*b1^2*b3*IntdqP112*magM[k2]^2*P11[magM[k1]])/(70*Pi^2) - 
 (653*b1*b2*b3*IntdqP112*magM[k2]^2*P11[magM[k1]])/(735*Pi^2) - 
 (62*b1^2*b5*IntdqP112*magM[k2]^2*P11[magM[k1]])/(105*Pi^2) + 
 (16*b1*b2*b5*IntdqP112*magM[k2]^2*P11[magM[k1]])/(15*Pi^2) - 
 (47*b1*b3*b5*IntdqP112*magM[k2]^2*P11[magM[k1]])/(105*Pi^2) + 
 (b1*b5^2*IntdqP112*magM[k2]^2*P11[magM[k1]])/(3*Pi^2) + 
 (47*b1^2*b6*IntdqP112*magM[k2]^2*P11[magM[k1]])/(35*Pi^2) - 
 (1052*b1*b2*b6*IntdqP112*magM[k2]^2*P11[magM[k1]])/(735*Pi^2) - 
 (44*b1*b5*b6*IntdqP112*magM[k2]^2*P11[magM[k1]])/(105*Pi^2) + 
 (319*b1^2*b8*IntdqP112*magM[k2]^2*P11[magM[k1]])/(105*Pi^2) - 
 (2228*b1*b2*b8*IntdqP112*magM[k2]^2*P11[magM[k1]])/(735*Pi^2) - 
 (236*b1*b5*b8*IntdqP112*magM[k2]^2*P11[magM[k1]])/(105*Pi^2) + 
 (19*b1^3*Intdqq2P11P11pp*magM[k2]^2*P11[magM[k1]])/(210*Pi^2) - 
 (b1^2*b10*Intdqq2P11P11pp*magM[k2]^2*P11[magM[k1]])/(2*Pi^2) + 
 (b1^2*b2*Intdqq2P11P11pp*magM[k2]^2*P11[magM[k1]])/(6*Pi^2) + 
 (b1*b10*b2*Intdqq2P11P11pp*magM[k2]^2*P11[magM[k1]])/(2*Pi^2) - 
 (9*b1*b2^2*Intdqq2P11P11pp*magM[k2]^2*P11[magM[k1]])/(35*Pi^2) - 
 (73*b1^2*b3*Intdqq2P11P11pp*magM[k2]^2*P11[magM[k1]])/(210*Pi^2) + 
 (73*b1*b2*b3*Intdqq2P11P11pp*magM[k2]^2*P11[magM[k1]])/(210*Pi^2) + 
 (17*b1^2*b5*Intdqq2P11P11pp*magM[k2]^2*P11[magM[k1]])/(70*Pi^2) + 
 (b1*b10*b5*Intdqq2P11P11pp*magM[k2]^2*P11[magM[k1]])/(2*Pi^2) - 
 (62*b1*b2*b5*Intdqq2P11P11pp*magM[k2]^2*P11[magM[k1]])/(105*Pi^2) + 
 (73*b1*b3*b5*Intdqq2P11P11pp*magM[k2]^2*P11[magM[k1]])/(210*Pi^2) - 
 (b1*b5^2*Intdqq2P11P11pp*magM[k2]^2*P11[magM[k1]])/(3*Pi^2) - 
 (89*b1^2*b6*Intdqq2P11P11pp*magM[k2]^2*P11[magM[k1]])/(105*Pi^2) + 
 (89*b1*b2*b6*Intdqq2P11P11pp*magM[k2]^2*P11[magM[k1]])/(105*Pi^2) + 
 (89*b1*b5*b6*Intdqq2P11P11pp*magM[k2]^2*P11[magM[k1]])/(105*Pi^2) - 
 (61*b1^2*b8*Intdqq2P11P11pp*magM[k2]^2*P11[magM[k1]])/(105*Pi^2) + 
 (61*b1*b2*b8*Intdqq2P11P11pp*magM[k2]^2*P11[magM[k1]])/(105*Pi^2) + 
 (61*b1*b5*b8*Intdqq2P11P11pp*magM[k2]^2*P11[magM[k1]])/(105*Pi^2) + 
 (19*b1^3*IntdqqP11P11p*magM[k2]^2*P11[magM[k1]])/(105*Pi^2) - 
 (b1^2*b10*IntdqqP11P11p*magM[k2]^2*P11[magM[k1]])/Pi^2 + 
 (b1^2*b2*IntdqqP11P11p*magM[k2]^2*P11[magM[k1]])/(3*Pi^2) + 
 (b1*b10*b2*IntdqqP11P11p*magM[k2]^2*P11[magM[k1]])/Pi^2 - 
 (18*b1*b2^2*IntdqqP11P11p*magM[k2]^2*P11[magM[k1]])/(35*Pi^2) - 
 (73*b1^2*b3*IntdqqP11P11p*magM[k2]^2*P11[magM[k1]])/(105*Pi^2) + 
 (73*b1*b2*b3*IntdqqP11P11p*magM[k2]^2*P11[magM[k1]])/(105*Pi^2) + 
 (17*b1^2*b5*IntdqqP11P11p*magM[k2]^2*P11[magM[k1]])/(35*Pi^2) + 
 (b1*b10*b5*IntdqqP11P11p*magM[k2]^2*P11[magM[k1]])/Pi^2 - 
 (124*b1*b2*b5*IntdqqP11P11p*magM[k2]^2*P11[magM[k1]])/(105*Pi^2) + 
 (73*b1*b3*b5*IntdqqP11P11p*magM[k2]^2*P11[magM[k1]])/(105*Pi^2) - 
 (2*b1*b5^2*IntdqqP11P11p*magM[k2]^2*P11[magM[k1]])/(3*Pi^2) - 
 (178*b1^2*b6*IntdqqP11P11p*magM[k2]^2*P11[magM[k1]])/(105*Pi^2) + 
 (178*b1*b2*b6*IntdqqP11P11p*magM[k2]^2*P11[magM[k1]])/(105*Pi^2) + 
 (178*b1*b5*b6*IntdqqP11P11p*magM[k2]^2*P11[magM[k1]])/(105*Pi^2) - 
 (122*b1^2*b8*IntdqqP11P11p*magM[k2]^2*P11[magM[k1]])/(105*Pi^2) + 
 (122*b1*b2*b8*IntdqqP11P11p*magM[k2]^2*P11[magM[k1]])/(105*Pi^2) + 
 (122*b1*b5*b8*IntdqqP11P11p*magM[k2]^2*P11[magM[k1]])/(105*Pi^2) - 
 (b1^2*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4) + (5*b1*b2*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*
   P11[magM[k1]])/(7*Pi^2*magM[k1]^4) - 
 (8*b2^2*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^4) + (b1*b5*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) - 
 (8*b2*b5*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^4) + (b1^2*f1^2*Intdqq2P11P11pp*dot[k1, hat[z]]^4*
   magM[k2]^2*P11[magM[k1]])/(6*Pi^2*magM[k1]^4) - 
 (b1*b2*f1^2*Intdqq2P11P11pp*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4) + (b2^2*f1^2*Intdqq2P11P11pp*dot[k1, hat[z]]^4*
   magM[k2]^2*P11[magM[k1]])/(6*Pi^2*magM[k1]^4) - 
 (b1*b5*f1^2*Intdqq2P11P11pp*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4) + (b2*b5*f1^2*Intdqq2P11P11pp*dot[k1, hat[z]]^4*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4) + 
 (b5^2*f1^2*Intdqq2P11P11pp*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^4) + (b1^2*f1^2*IntdqqP11P11p*dot[k1, hat[z]]^4*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) - 
 (2*b1*b2*f1^2*IntdqqP11P11p*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4) + (b2^2*f1^2*IntdqqP11P11p*dot[k1, hat[z]]^4*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) - 
 (2*b1*b5*f1^2*IntdqqP11P11p*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4) + (2*b2*b5*f1^2*IntdqqP11P11p*dot[k1, hat[z]]^4*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4) + 
 (b5^2*f1^2*IntdqqP11P11p*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4) - (b1^2*f1^2*IntdqP112*dot[k1, hat[z]]^3*
   dot[k2, hat[z]]*magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4) + 
 (5*b1*b2*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(7*Pi^2*magM[k1]^4) - 
 (8*b2^2*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^4) + 
 (b1*b5*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) - 
 (8*b2*b5*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^4) + 
 (b1^2*f1^2*Intdqq2P11P11pp*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(6*Pi^2*magM[k1]^4) - 
 (b1*b2*f1^2*Intdqq2P11P11pp*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) + 
 (b2^2*f1^2*Intdqq2P11P11pp*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(6*Pi^2*magM[k1]^4) - 
 (b1*b5*f1^2*Intdqq2P11P11pp*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) + 
 (b2*b5*f1^2*Intdqq2P11P11pp*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) + 
 (b5^2*f1^2*Intdqq2P11P11pp*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(6*Pi^2*magM[k1]^4) + 
 (b1^2*f1^2*IntdqqP11P11p*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) - 
 (2*b1*b2*f1^2*IntdqqP11P11p*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) + 
 (b2^2*f1^2*IntdqqP11P11p*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) - 
 (2*b1*b5*f1^2*IntdqqP11P11p*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) + 
 (2*b2*b5*f1^2*IntdqqP11P11p*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) + 
 (b5^2*f1^2*IntdqqP11P11p*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) - 
 (43*b1^2*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^2) - (b1^3*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (b1*b10*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (2*Pi^2*magM[k1]^2) - (328*b1*b2*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(735*Pi^2*magM[k1]^2) + 
 (5*b1^2*b2*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (7*Pi^2*magM[k1]^2) - (4*b10*b2*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(7*Pi^2*magM[k1]^2) + 
 (491*b2^2*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (735*Pi^2*magM[k1]^2) - (8*b1*b2^2*f1*IntdqP112*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(21*Pi^2*magM[k1]^2) + 
 (61*b1*b3*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (70*Pi^2*magM[k1]^2) - (653*b2*b3*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(735*Pi^2*magM[k1]^2) - 
 (62*b1*b5*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (b1^2*b5*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (16*b2*b5*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (15*Pi^2*magM[k1]^2) - (8*b1*b2*b5*f1*IntdqP112*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(21*Pi^2*magM[k1]^2) - 
 (47*b3*b5*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (b5^2*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (47*b1*b6*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2) - (1052*b2*b6*f1*IntdqP112*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(735*Pi^2*magM[k1]^2) - 
 (44*b5*b6*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (319*b1*b8*f1*IntdqP112*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) - 
 (2228*b2*b8*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (735*Pi^2*magM[k1]^2) - (236*b5*b8*f1*IntdqP112*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (19*b1^2*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^2) + (b1^3*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(6*Pi^2*magM[k1]^2) - 
 (b1*b10*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (2*Pi^2*magM[k1]^2) + (b1*b2*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(6*Pi^2*magM[k1]^2) - 
 (b1^2*b2*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) + (b10*b2*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(2*Pi^2*magM[k1]^2) - 
 (9*b2^2*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2) + (b1*b2^2*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(6*Pi^2*magM[k1]^2) - 
 (73*b1*b3*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^2) + (73*b2*b3*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(210*Pi^2*magM[k1]^2) + 
 (17*b1*b5*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (70*Pi^2*magM[k1]^2) - (b1^2*b5*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (b10*b5*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (2*Pi^2*magM[k1]^2) - (62*b2*b5*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (b1*b2*b5*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) + (73*b3*b5*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(210*Pi^2*magM[k1]^2) - 
 (b5^2*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) + (b1*b5^2*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(6*Pi^2*magM[k1]^2) - 
 (89*b1*b6*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (89*b2*b6*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (89*b5*b6*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) - (61*b1*b8*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (61*b2*b8*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (61*b5*b8*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (19*b1^2*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (b1^3*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) - 
 (b1*b10*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (Pi^2*magM[k1]^2) + (b1*b2*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) - 
 (2*b1^2*b2*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) + (b10*b2*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(Pi^2*magM[k1]^2) - 
 (18*b2^2*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2) + (b1*b2^2*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2) - 
 (73*b1*b3*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (73*b2*b3*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (17*b1*b5*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2) - (2*b1^2*b5*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (b10*b5*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (Pi^2*magM[k1]^2) - (124*b2*b5*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (2*b1*b2*b5*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) + (73*b3*b5*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) - 
 (2*b5^2*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) + (b1*b5^2*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2) - 
 (178*b1*b6*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (178*b2*b6*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (178*b5*b6*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) - (122*b1*b8*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (122*b2*b8*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (122*b5*b8*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) - 
 (b1^3*f1*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) + (5*b1^2*b2*f1*IntdqP112*dot[k1, hat[z]]*
   dot[k2, hat[z]]*magM[k2]^2*P11[magM[k1]])/(7*Pi^2*magM[k1]^2) - 
 (8*b1*b2^2*f1*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^2) + 
 (b1^2*b5*f1*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) - 
 (8*b1*b2*b5*f1*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^2) + 
 (b1^3*f1*Intdqq2P11P11pp*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(6*Pi^2*magM[k1]^2) - 
 (b1^2*b2*f1*Intdqq2P11P11pp*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (b1*b2^2*f1*Intdqq2P11P11pp*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(6*Pi^2*magM[k1]^2) - 
 (b1^2*b5*f1*Intdqq2P11P11pp*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (b1*b2*b5*f1*Intdqq2P11P11pp*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (b1*b5^2*f1*Intdqq2P11P11pp*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(6*Pi^2*magM[k1]^2) + 
 (b1^3*f1*IntdqqP11P11p*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) - 
 (2*b1^2*b2*f1*IntdqqP11P11p*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (b1*b2^2*f1*IntdqqP11P11p*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) - 
 (2*b1^2*b5*f1*IntdqqP11P11p*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (2*b1*b2*b5*f1*IntdqqP11P11p*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (b1*b5^2*f1*IntdqqP11P11p*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (11*b1^3*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (3*b1^2*b2*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/
  (5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (2*b1*b2^2*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/
  (7*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (128*b1^2*b3*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (128*b1*b2*b3*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (103*b1^2*b5*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (20*b1*b2*b5*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (128*b1*b3*b5*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (2*b1*b5^2*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (128*b1^2*b8*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (128*b1*b2*b8*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (128*b1*b5*b8*IntdqP112*dot[k1, k2]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (11*b1^2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (70*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (23*b1^3*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (210*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (3*b1*b2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (3*b1^2*b2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b2^2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (7*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (4*b1*b2^2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (64*b1*b3*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (64*b2*b3*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (103*b1*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (210*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (23*b1^2*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (210*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (10*b2*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (4*b1*b2*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (64*b3*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b5^2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (64*b1*b8*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (64*b2*b8*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (64*b5*b8*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1^2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (6*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (b1*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (6*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (b1*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (6*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (36*b1^2*f1*IntdqP112*dot[k1, k2]*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (b1^3*f1*IntdqP112*dot[k1, k2]*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (36*b1*b2*f1*IntdqP112*dot[k1, k2]*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1^2*b2*f1*IntdqP112*dot[k1, k2]*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (36*b1*b5*f1*IntdqP112*dot[k1, k2]*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1^2*b5*f1*IntdqP112*dot[k1, k2]*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1^2*f1^2*IntdqP112*dot[k1, k2]*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (b1*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (b1*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k2, hat[z]]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (23*b1^2*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (3*b1*b2*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (5*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (8*b2^2*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (23*b1*b5*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (8*b2*b5*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1*f1^3*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (b2*f1^3*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (b5*f1^3*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (97*b1*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (97*b2*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^3*
   dot[k2, hat[z]]*P11[magM[k1]])/(105*Pi^2*magM[k1]^4*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (97*b5*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (187*b1*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(210*Pi^2*magM[k1]^4*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (2*b1^2*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (187*b2*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(210*Pi^2*magM[k1]^4*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (2*b1*b2*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (187*b5*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(210*Pi^2*magM[k1]^4*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (2*b1*b5*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (2*b1*f1^3*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (2*b2*f1^3*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (2*b5*f1^3*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (11*b1^2*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (23*b1^3*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (3*b1*b2*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (5*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (3*b1^2*b2*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (5*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (2*b2^2*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (7*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (8*b1*b2^2*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (128*b1*b3*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (315*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (128*b2*b3*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (315*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (103*b1*b5*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (23*b1^2*b5*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (20*b2*b5*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (8*b1*b2*b5*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (128*b3*b5*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (315*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (2*b5^2*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (128*b1*b8*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (128*b2*b8*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (128*b5*b8*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1^2*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (b1*b2*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (b1*b5*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (23*b1^2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (3*b1*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (10*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (4*b2^2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (23*b1*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (4*b2*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (b2*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (b5*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (97*b1^2*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]*dot[k2, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (97*b1*b2*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]*
   dot[k2, hat[z]]*P11[magM[k1]])/(105*Pi^2*magM[k1]^2*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (97*b1*b5*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]*dot[k2, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (187*b1^2*f1*IntdqP112*dot[k1, k2]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (2*b1^3*f1*IntdqP112*dot[k1, k2]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (187*b1*b2*f1*IntdqP112*dot[k1, k2]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (2*b1^2*b2*f1*IntdqP112*dot[k1, k2]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (187*b1*b5*f1*IntdqP112*dot[k1, k2]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (2*b1^2*b5*f1*IntdqP112*dot[k1, k2]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (2*b1^2*f1^2*IntdqP112*dot[k1, k2]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (2*b1*b2*f1^2*IntdqP112*dot[k1, k2]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (2*b1*b5*f1^2*IntdqP112*dot[k1, k2]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (36*b1*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(35*Pi^2*magM[k1]^2*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (b1^2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (36*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(35*Pi^2*magM[k1]^2*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (36*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(35*Pi^2*magM[k1]^2*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (b1*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (b2*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (b5*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (11*b1^3*IntdqP112*dot[k1, k2]*magM[k1]^2*P11[magM[k1]])/
  (70*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (3*b1^2*b2*IntdqP112*dot[k1, k2]*magM[k1]^2*P11[magM[k1]])/
  (10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1*b2^2*IntdqP112*dot[k1, k2]*magM[k1]^2*P11[magM[k1]])/
  (7*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (64*b1^2*b3*IntdqP112*dot[k1, k2]*magM[k1]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (64*b1*b2*b3*IntdqP112*dot[k1, k2]*magM[k1]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (103*b1^2*b5*IntdqP112*dot[k1, k2]*magM[k1]^2*P11[magM[k1]])/
  (210*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (10*b1*b2*b5*IntdqP112*dot[k1, k2]*magM[k1]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (64*b1*b3*b5*IntdqP112*dot[k1, k2]*magM[k1]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1*b5^2*IntdqP112*dot[k1, k2]*magM[k1]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (64*b1^2*b8*IntdqP112*dot[k1, k2]*magM[k1]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (64*b1*b2*b8*IntdqP112*dot[k1, k2]*magM[k1]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (64*b1*b5*b8*IntdqP112*dot[k1, k2]*magM[k1]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (37*b1^3*IntdqP112*dot[k1, k2]*magM[k2]^2*P11[magM[k1]])/
  (210*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (29*b1^2*b2*IntdqP112*dot[k1, k2]*magM[k2]^2*P11[magM[k1]])/
  (70*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (5*b1*b2^2*IntdqP112*dot[k1, k2]*magM[k2]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (64*b1^2*b3*IntdqP112*dot[k1, k2]*magM[k2]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (64*b1*b2*b3*IntdqP112*dot[k1, k2]*magM[k2]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (11*b1^2*b5*IntdqP112*dot[k1, k2]*magM[k2]^2*P11[magM[k1]])/
  (70*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (2*b1*b2*b5*IntdqP112*dot[k1, k2]*magM[k2]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (64*b1*b3*b5*IntdqP112*dot[k1, k2]*magM[k2]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1*b5^2*IntdqP112*dot[k1, k2]*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (64*b1^2*b8*IntdqP112*dot[k1, k2]*magM[k2]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (64*b1*b2*b8*IntdqP112*dot[k1, k2]*magM[k2]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (64*b1*b5*b8*IntdqP112*dot[k1, k2]*magM[k2]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1^3*Intdqq2P11P11pp*dot[k1, k2]*magM[k2]^2*P11[magM[k1]])/
  (6*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (b1^2*b2*Intdqq2P11P11pp*dot[k1, k2]*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1*b2^2*Intdqq2P11P11pp*dot[k1, k2]*magM[k2]^2*P11[magM[k1]])/
  (6*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (b1^2*b5*Intdqq2P11P11pp*dot[k1, k2]*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1*b2*b5*Intdqq2P11P11pp*dot[k1, k2]*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1*b5^2*Intdqq2P11P11pp*dot[k1, k2]*magM[k2]^2*P11[magM[k1]])/
  (6*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1^3*IntdqqP11P11p*dot[k1, k2]*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (2*b1^2*b2*IntdqqP11P11p*dot[k1, k2]*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1*b2^2*IntdqqP11P11p*dot[k1, k2]*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (2*b1^2*b5*IntdqqP11P11p*dot[k1, k2]*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (2*b1*b2*b5*IntdqqP11P11p*dot[k1, k2]*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1*b5^2*IntdqqP11P11p*dot[k1, k2]*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (8*b1^2*f1*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(15*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (8*b1*b2*f1*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(15*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (8*b1*b5*f1*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(15*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (4*b1^2*f1*IntdqP112*dot[k2, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (15*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (4*b1*b2*f1*IntdqP112*dot[k2, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (15*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (4*b1*b5*f1*IntdqP112*dot[k2, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (15*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (2*b1^2*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (10*b1*b2*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(7*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (16*b2^2*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(21*Pi^2*magM[k1]^4*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (2*b1*b5*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (16*b2*b5*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(21*Pi^2*magM[k1]^4*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1^2*f1*Intdqq2P11P11pp*dot[k1, k2]^2*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (2*b1*b2*f1*Intdqq2P11P11pp*dot[k1, k2]^2*
   dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b2^2*f1*Intdqq2P11P11pp*dot[k1, k2]^2*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (2*b1*b5*f1*Intdqq2P11P11pp*dot[k1, k2]^2*
   dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (2*b2*b5*f1*Intdqq2P11P11pp*dot[k1, k2]^2*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (b5^2*f1*Intdqq2P11P11pp*dot[k1, k2]^2*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (2*b1^2*f1*IntdqqP11P11p*dot[k1, k2]^2*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (4*b1*b2*f1*IntdqqP11P11p*dot[k1, k2]^2*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (2*b2^2*f1*IntdqqP11P11p*dot[k1, k2]^2*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (4*b1*b5*f1*IntdqqP11P11p*dot[k1, k2]^2*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (4*b2*b5*f1*IntdqqP11P11p*dot[k1, k2]^2*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (2*b5^2*f1*IntdqqP11P11p*dot[k1, k2]^2*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (3*b1*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*
   magM[k2]^2*P11[magM[k1]])/(14*Pi^2*magM[k1]^4*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (23*b1^2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*magM[k2]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (3*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*
   magM[k2]^2*P11[magM[k1]])/(14*Pi^2*magM[k1]^4*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (3*b1*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*magM[k2]^2*
   P11[magM[k1]])/(10*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (4*b2^2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*
   magM[k2]^2*P11[magM[k1]])/(21*Pi^2*magM[k1]^4*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (3*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (14*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (23*b1*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*magM[k2]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (4*b2*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*
   magM[k2]^2*P11[magM[k1]])/(21*Pi^2*magM[k1]^4*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (b2*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (b5*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (3*b1*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
   magM[k2]^2*P11[magM[k1]])/(7*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (3*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^3*
   dot[k2, hat[z]]*magM[k2]^2*P11[magM[k1]])/
  (7*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (3*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
   magM[k2]^2*P11[magM[k1]])/(7*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (3*b1*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (7*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (b1^2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (3*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (7*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (3*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (7*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (b1*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (b2*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (b5*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*
   dot[k2, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (2*b1^3*IntdqP112*dot[k1, k2]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (10*b1^2*b2*IntdqP112*dot[k1, k2]^2*magM[k2]^2*P11[magM[k1]])/
  (7*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (16*b1*b2^2*IntdqP112*dot[k1, k2]^2*magM[k2]^2*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (2*b1^2*b5*IntdqP112*dot[k1, k2]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (16*b1*b2*b5*IntdqP112*dot[k1, k2]^2*magM[k2]^2*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1^3*Intdqq2P11P11pp*dot[k1, k2]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (2*b1^2*b2*Intdqq2P11P11pp*dot[k1, k2]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1*b2^2*Intdqq2P11P11pp*dot[k1, k2]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (2*b1^2*b5*Intdqq2P11P11pp*dot[k1, k2]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (2*b1*b2*b5*Intdqq2P11P11pp*dot[k1, k2]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1*b5^2*Intdqq2P11P11pp*dot[k1, k2]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (2*b1^3*IntdqqP11P11p*dot[k1, k2]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (4*b1^2*b2*IntdqqP11P11p*dot[k1, k2]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (2*b1*b2^2*IntdqqP11P11p*dot[k1, k2]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (4*b1^2*b5*IntdqqP11P11p*dot[k1, k2]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (4*b1*b2*b5*IntdqqP11P11p*dot[k1, k2]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (2*b1*b5^2*IntdqqP11P11p*dot[k1, k2]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (4*b1^2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (23*b1^3*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (b1*b2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(5*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (3*b1^2*b2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(10*Pi^2*magM[k1]^2*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (5*b2^2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (4*b1*b2^2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (64*b1*b3*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(315*Pi^2*magM[k1]^2*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (64*b2*b3*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(315*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (13*b1*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(35*Pi^2*magM[k1]^2*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (23*b1^2*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (2*b2*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(21*Pi^2*magM[k1]^2*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (4*b1*b2*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (64*b3*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(315*Pi^2*magM[k1]^2*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b5^2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (64*b1*b8*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (64*b2*b8*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(21*Pi^2*magM[k1]^2*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (64*b5*b8*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (b1^2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(6*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (b1*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(6*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (b1*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(6*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (b1^2*f1*Intdqq2P11P11pp*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(6*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (b1*b2*f1*Intdqq2P11P11pp*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (b2^2*f1*Intdqq2P11P11pp*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(6*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (b1*b5*f1*Intdqq2P11P11pp*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (b2*b5*f1*Intdqq2P11P11pp*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (b5^2*f1*Intdqq2P11P11pp*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(6*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (b1^2*f1*IntdqqP11P11p*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (2*b1*b2*f1*IntdqqP11P11p*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (b2^2*f1*IntdqqP11P11p*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (2*b1*b5*f1*IntdqqP11P11p*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (2*b2*b5*f1*IntdqqP11P11p*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (b5^2*f1*IntdqqP11P11p*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (3*b1^2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]*
   dot[k2, hat[z]]*magM[k2]^2*P11[magM[k1]])/
  (7*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (3*b1*b2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(7*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (3*b1*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]*
   dot[k2, hat[z]]*magM[k2]^2*P11[magM[k1]])/
  (7*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (8*b1*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(15*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (8*b2*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
   magM[k2]^2*P11[magM[k1]])/(15*Pi^2*magM[k1]^2*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (8*b5*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(15*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (3*b1^2*f1*IntdqP112*dot[k1, k2]*dot[k2, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(7*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (b1^3*f1*IntdqP112*dot[k1, k2]*dot[k2, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (3*b1*b2*f1*IntdqP112*dot[k1, k2]*dot[k2, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(7*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (b1^2*b2*f1*IntdqP112*dot[k1, k2]*dot[k2, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (3*b1*b5*f1*IntdqP112*dot[k1, k2]*dot[k2, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(7*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (b1^2*b5*f1*IntdqP112*dot[k1, k2]*dot[k2, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (b1^2*f1^2*IntdqP112*dot[k1, k2]*dot[k2, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (b1*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k2, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (b1*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k2, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (4*b1*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(15*Pi^2*magM[k1]^2*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (4*b2*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(15*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (4*b5*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
   magM[k2]^2*P11[magM[k1]])/(15*Pi^2*magM[k1]^2*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (b1^2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k2]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (5*b1*b2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k2]^4*
   P11[magM[k1]])/(7*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (8*b2^2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^4*P11[magM[k1]])/(21*Pi^2*magM[k1]^4*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k2]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (8*b2*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k2]^4*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (b1^2*f1*Intdqq2P11P11pp*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^4*P11[magM[k1]])/(6*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (b1*b2*f1*Intdqq2P11P11pp*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^4*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (b2^2*f1*Intdqq2P11P11pp*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^4*P11[magM[k1]])/(6*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (b1*b5*f1*Intdqq2P11P11pp*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^4*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (b2*b5*f1*Intdqq2P11P11pp*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^4*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (b5^2*f1*Intdqq2P11P11pp*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^4*P11[magM[k1]])/(6*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (b1^2*f1*IntdqqP11P11p*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^4*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (2*b1*b2*f1*IntdqqP11P11p*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^4*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (b2^2*f1*IntdqqP11P11p*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^4*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (2*b1*b5*f1*IntdqqP11P11p*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^4*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (2*b2*b5*f1*IntdqqP11P11p*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^4*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) + (b5^2*f1*IntdqqP11P11p*dot[k1, k2]*dot[k1, hat[z]]^2*
   magM[k2]^4*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)) - (b1^3*IntdqP112*dot[k1, k2]*magM[k2]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (5*b1^2*b2*IntdqP112*dot[k1, k2]*magM[k2]^4*P11[magM[k1]])/
  (7*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (8*b1*b2^2*IntdqP112*dot[k1, k2]*magM[k2]^4*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1^2*b5*IntdqP112*dot[k1, k2]*magM[k2]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (8*b1*b2*b5*IntdqP112*dot[k1, k2]*magM[k2]^4*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1^3*Intdqq2P11P11pp*dot[k1, k2]*magM[k2]^4*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (b1^2*b2*Intdqq2P11P11pp*dot[k1, k2]*magM[k2]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1*b2^2*Intdqq2P11P11pp*dot[k1, k2]*magM[k2]^4*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (b1^2*b5*Intdqq2P11P11pp*dot[k1, k2]*magM[k2]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1*b2*b5*Intdqq2P11P11pp*dot[k1, k2]*magM[k2]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1*b5^2*Intdqq2P11P11pp*dot[k1, k2]*magM[k2]^4*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1^3*IntdqqP11P11p*dot[k1, k2]*magM[k2]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (2*b1^2*b2*IntdqqP11P11p*dot[k1, k2]*magM[k2]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1*b2^2*IntdqqP11P11p*dot[k1, k2]*magM[k2]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (2*b1^2*b5*IntdqqP11P11p*dot[k1, k2]*magM[k2]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (2*b1*b2*b5*IntdqqP11P11p*dot[k1, k2]*magM[k2]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
 (b1*b5^2*IntdqqP11P11p*dot[k1, k2]*magM[k2]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) - 
 (43*b1^3*IntdqP112*magM[k3]^2*P11[magM[k1]])/(210*Pi^2) + 
 (b1^2*b10*IntdqP112*magM[k3]^2*P11[magM[k1]])/(2*Pi^2) - 
 (328*b1^2*b2*IntdqP112*magM[k3]^2*P11[magM[k1]])/(735*Pi^2) - 
 (4*b1*b10*b2*IntdqP112*magM[k3]^2*P11[magM[k1]])/(7*Pi^2) + 
 (491*b1*b2^2*IntdqP112*magM[k3]^2*P11[magM[k1]])/(735*Pi^2) + 
 (61*b1^2*b3*IntdqP112*magM[k3]^2*P11[magM[k1]])/(70*Pi^2) - 
 (653*b1*b2*b3*IntdqP112*magM[k3]^2*P11[magM[k1]])/(735*Pi^2) - 
 (62*b1^2*b5*IntdqP112*magM[k3]^2*P11[magM[k1]])/(105*Pi^2) + 
 (16*b1*b2*b5*IntdqP112*magM[k3]^2*P11[magM[k1]])/(15*Pi^2) - 
 (47*b1*b3*b5*IntdqP112*magM[k3]^2*P11[magM[k1]])/(105*Pi^2) + 
 (b1*b5^2*IntdqP112*magM[k3]^2*P11[magM[k1]])/(3*Pi^2) + 
 (47*b1^2*b6*IntdqP112*magM[k3]^2*P11[magM[k1]])/(35*Pi^2) - 
 (1052*b1*b2*b6*IntdqP112*magM[k3]^2*P11[magM[k1]])/(735*Pi^2) - 
 (44*b1*b5*b6*IntdqP112*magM[k3]^2*P11[magM[k1]])/(105*Pi^2) + 
 (319*b1^2*b8*IntdqP112*magM[k3]^2*P11[magM[k1]])/(105*Pi^2) - 
 (2228*b1*b2*b8*IntdqP112*magM[k3]^2*P11[magM[k1]])/(735*Pi^2) - 
 (236*b1*b5*b8*IntdqP112*magM[k3]^2*P11[magM[k1]])/(105*Pi^2) + 
 (19*b1^3*Intdqq2P11P11pp*magM[k3]^2*P11[magM[k1]])/(210*Pi^2) - 
 (b1^2*b10*Intdqq2P11P11pp*magM[k3]^2*P11[magM[k1]])/(2*Pi^2) + 
 (b1^2*b2*Intdqq2P11P11pp*magM[k3]^2*P11[magM[k1]])/(6*Pi^2) + 
 (b1*b10*b2*Intdqq2P11P11pp*magM[k3]^2*P11[magM[k1]])/(2*Pi^2) - 
 (9*b1*b2^2*Intdqq2P11P11pp*magM[k3]^2*P11[magM[k1]])/(35*Pi^2) - 
 (73*b1^2*b3*Intdqq2P11P11pp*magM[k3]^2*P11[magM[k1]])/(210*Pi^2) + 
 (73*b1*b2*b3*Intdqq2P11P11pp*magM[k3]^2*P11[magM[k1]])/(210*Pi^2) + 
 (17*b1^2*b5*Intdqq2P11P11pp*magM[k3]^2*P11[magM[k1]])/(70*Pi^2) + 
 (b1*b10*b5*Intdqq2P11P11pp*magM[k3]^2*P11[magM[k1]])/(2*Pi^2) - 
 (62*b1*b2*b5*Intdqq2P11P11pp*magM[k3]^2*P11[magM[k1]])/(105*Pi^2) + 
 (73*b1*b3*b5*Intdqq2P11P11pp*magM[k3]^2*P11[magM[k1]])/(210*Pi^2) - 
 (b1*b5^2*Intdqq2P11P11pp*magM[k3]^2*P11[magM[k1]])/(3*Pi^2) - 
 (89*b1^2*b6*Intdqq2P11P11pp*magM[k3]^2*P11[magM[k1]])/(105*Pi^2) + 
 (89*b1*b2*b6*Intdqq2P11P11pp*magM[k3]^2*P11[magM[k1]])/(105*Pi^2) + 
 (89*b1*b5*b6*Intdqq2P11P11pp*magM[k3]^2*P11[magM[k1]])/(105*Pi^2) - 
 (61*b1^2*b8*Intdqq2P11P11pp*magM[k3]^2*P11[magM[k1]])/(105*Pi^2) + 
 (61*b1*b2*b8*Intdqq2P11P11pp*magM[k3]^2*P11[magM[k1]])/(105*Pi^2) + 
 (61*b1*b5*b8*Intdqq2P11P11pp*magM[k3]^2*P11[magM[k1]])/(105*Pi^2) + 
 (19*b1^3*IntdqqP11P11p*magM[k3]^2*P11[magM[k1]])/(105*Pi^2) - 
 (b1^2*b10*IntdqqP11P11p*magM[k3]^2*P11[magM[k1]])/Pi^2 + 
 (b1^2*b2*IntdqqP11P11p*magM[k3]^2*P11[magM[k1]])/(3*Pi^2) + 
 (b1*b10*b2*IntdqqP11P11p*magM[k3]^2*P11[magM[k1]])/Pi^2 - 
 (18*b1*b2^2*IntdqqP11P11p*magM[k3]^2*P11[magM[k1]])/(35*Pi^2) - 
 (73*b1^2*b3*IntdqqP11P11p*magM[k3]^2*P11[magM[k1]])/(105*Pi^2) + 
 (73*b1*b2*b3*IntdqqP11P11p*magM[k3]^2*P11[magM[k1]])/(105*Pi^2) + 
 (17*b1^2*b5*IntdqqP11P11p*magM[k3]^2*P11[magM[k1]])/(35*Pi^2) + 
 (b1*b10*b5*IntdqqP11P11p*magM[k3]^2*P11[magM[k1]])/Pi^2 - 
 (124*b1*b2*b5*IntdqqP11P11p*magM[k3]^2*P11[magM[k1]])/(105*Pi^2) + 
 (73*b1*b3*b5*IntdqqP11P11p*magM[k3]^2*P11[magM[k1]])/(105*Pi^2) - 
 (2*b1*b5^2*IntdqqP11P11p*magM[k3]^2*P11[magM[k1]])/(3*Pi^2) - 
 (178*b1^2*b6*IntdqqP11P11p*magM[k3]^2*P11[magM[k1]])/(105*Pi^2) + 
 (178*b1*b2*b6*IntdqqP11P11p*magM[k3]^2*P11[magM[k1]])/(105*Pi^2) + 
 (178*b1*b5*b6*IntdqqP11P11p*magM[k3]^2*P11[magM[k1]])/(105*Pi^2) - 
 (122*b1^2*b8*IntdqqP11P11p*magM[k3]^2*P11[magM[k1]])/(105*Pi^2) + 
 (122*b1*b2*b8*IntdqqP11P11p*magM[k3]^2*P11[magM[k1]])/(105*Pi^2) + 
 (122*b1*b5*b8*IntdqqP11P11p*magM[k3]^2*P11[magM[k1]])/(105*Pi^2) - 
 (b1^2*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4) + (5*b1*b2*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k3]^2*
   P11[magM[k1]])/(7*Pi^2*magM[k1]^4) - 
 (8*b2^2*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k3]^2*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^4) + (b1*b5*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) - 
 (8*b2*b5*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k3]^2*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^4) + (b1^2*f1^2*Intdqq2P11P11pp*dot[k1, hat[z]]^4*
   magM[k3]^2*P11[magM[k1]])/(6*Pi^2*magM[k1]^4) - 
 (b1*b2*f1^2*Intdqq2P11P11pp*dot[k1, hat[z]]^4*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4) + (b2^2*f1^2*Intdqq2P11P11pp*dot[k1, hat[z]]^4*
   magM[k3]^2*P11[magM[k1]])/(6*Pi^2*magM[k1]^4) - 
 (b1*b5*f1^2*Intdqq2P11P11pp*dot[k1, hat[z]]^4*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4) + (b2*b5*f1^2*Intdqq2P11P11pp*dot[k1, hat[z]]^4*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4) + 
 (b5^2*f1^2*Intdqq2P11P11pp*dot[k1, hat[z]]^4*magM[k3]^2*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^4) + (b1^2*f1^2*IntdqqP11P11p*dot[k1, hat[z]]^4*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) - 
 (2*b1*b2*f1^2*IntdqqP11P11p*dot[k1, hat[z]]^4*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4) + (b2^2*f1^2*IntdqqP11P11p*dot[k1, hat[z]]^4*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) - 
 (2*b1*b5*f1^2*IntdqqP11P11p*dot[k1, hat[z]]^4*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4) + (2*b2*b5*f1^2*IntdqqP11P11p*dot[k1, hat[z]]^4*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4) + 
 (b5^2*f1^2*IntdqqP11P11p*dot[k1, hat[z]]^4*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4) - (b1^2*f1^2*IntdqP112*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4) + 
 (5*b1*b2*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(7*Pi^2*magM[k1]^4) - 
 (8*b2^2*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^4) + 
 (b1*b5*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) - 
 (8*b2*b5*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^4) + 
 (b1^2*f1^2*Intdqq2P11P11pp*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(6*Pi^2*magM[k1]^4) - 
 (b1*b2*f1^2*Intdqq2P11P11pp*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) + 
 (b2^2*f1^2*Intdqq2P11P11pp*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(6*Pi^2*magM[k1]^4) - 
 (b1*b5*f1^2*Intdqq2P11P11pp*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) + 
 (b2*b5*f1^2*Intdqq2P11P11pp*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) + 
 (b5^2*f1^2*Intdqq2P11P11pp*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(6*Pi^2*magM[k1]^4) + 
 (b1^2*f1^2*IntdqqP11P11p*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) - 
 (2*b1*b2*f1^2*IntdqqP11P11p*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) + 
 (b2^2*f1^2*IntdqqP11P11p*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) - 
 (2*b1*b5*f1^2*IntdqqP11P11p*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) + 
 (2*b2*b5*f1^2*IntdqqP11P11p*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) + 
 (b5^2*f1^2*IntdqqP11P11p*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4) - 
 (43*b1^2*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^2) - (b1^3*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (b1*b10*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (2*Pi^2*magM[k1]^2) - (328*b1*b2*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(735*Pi^2*magM[k1]^2) + 
 (5*b1^2*b2*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (7*Pi^2*magM[k1]^2) - (4*b10*b2*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(7*Pi^2*magM[k1]^2) + 
 (491*b2^2*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (735*Pi^2*magM[k1]^2) - (8*b1*b2^2*f1*IntdqP112*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(21*Pi^2*magM[k1]^2) + 
 (61*b1*b3*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (70*Pi^2*magM[k1]^2) - (653*b2*b3*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(735*Pi^2*magM[k1]^2) - 
 (62*b1*b5*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (b1^2*b5*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (16*b2*b5*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (15*Pi^2*magM[k1]^2) - (8*b1*b2*b5*f1*IntdqP112*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(21*Pi^2*magM[k1]^2) - 
 (47*b3*b5*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (b5^2*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (47*b1*b6*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2) - (1052*b2*b6*f1*IntdqP112*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(735*Pi^2*magM[k1]^2) - 
 (44*b5*b6*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (319*b1*b8*f1*IntdqP112*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) - 
 (2228*b2*b8*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (735*Pi^2*magM[k1]^2) - (236*b5*b8*f1*IntdqP112*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (19*b1^2*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^2) + (b1^3*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(6*Pi^2*magM[k1]^2) - 
 (b1*b10*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (2*Pi^2*magM[k1]^2) + (b1*b2*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(6*Pi^2*magM[k1]^2) - 
 (b1^2*b2*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) + (b10*b2*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(2*Pi^2*magM[k1]^2) - 
 (9*b2^2*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2) + (b1*b2^2*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(6*Pi^2*magM[k1]^2) - 
 (73*b1*b3*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^2) + (73*b2*b3*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(210*Pi^2*magM[k1]^2) + 
 (17*b1*b5*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (70*Pi^2*magM[k1]^2) - (b1^2*b5*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (b10*b5*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (2*Pi^2*magM[k1]^2) - (62*b2*b5*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (b1*b2*b5*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) + (73*b3*b5*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(210*Pi^2*magM[k1]^2) - 
 (b5^2*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) + (b1*b5^2*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(6*Pi^2*magM[k1]^2) - 
 (89*b1*b6*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (89*b2*b6*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (89*b5*b6*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) - (61*b1*b8*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (61*b2*b8*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (61*b5*b8*f1*Intdqq2P11P11pp*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (19*b1^2*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (b1^3*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) - 
 (b1*b10*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (Pi^2*magM[k1]^2) + (b1*b2*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) - 
 (2*b1^2*b2*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) + (b10*b2*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(Pi^2*magM[k1]^2) - 
 (18*b2^2*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2) + (b1*b2^2*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2) - 
 (73*b1*b3*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (73*b2*b3*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (17*b1*b5*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2) - (2*b1^2*b5*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (b10*b5*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (Pi^2*magM[k1]^2) - (124*b2*b5*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (2*b1*b2*b5*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) + (73*b3*b5*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) - 
 (2*b5^2*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) + (b1*b5^2*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2) - 
 (178*b1*b6*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (178*b2*b6*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (178*b5*b6*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) - (122*b1*b8*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) + 
 (122*b2*b8*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2) + (122*b5*b8*f1*IntdqqP11P11p*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2) - 
 (b1^3*f1*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2) + (5*b1^2*b2*f1*IntdqP112*dot[k1, hat[z]]*
   dot[k3, hat[z]]*magM[k3]^2*P11[magM[k1]])/(7*Pi^2*magM[k1]^2) - 
 (8*b1*b2^2*f1*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^2) + 
 (b1^2*b5*f1*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) - 
 (8*b1*b2*b5*f1*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^2) + 
 (b1^3*f1*Intdqq2P11P11pp*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(6*Pi^2*magM[k1]^2) - 
 (b1^2*b2*f1*Intdqq2P11P11pp*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (b1*b2^2*f1*Intdqq2P11P11pp*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(6*Pi^2*magM[k1]^2) - 
 (b1^2*b5*f1*Intdqq2P11P11pp*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (b1*b2*b5*f1*Intdqq2P11P11pp*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (b1*b5^2*f1*Intdqq2P11P11pp*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(6*Pi^2*magM[k1]^2) + 
 (b1^3*f1*IntdqqP11P11p*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) - 
 (2*b1^2*b2*f1*IntdqqP11P11p*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (b1*b2^2*f1*IntdqqP11P11p*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) - 
 (2*b1^2*b5*f1*IntdqqP11P11p*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (2*b1*b2*b5*f1*IntdqqP11P11p*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) + 
 (b1*b5^2*f1*IntdqqP11P11p*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2) - 
 (b1^3*IntdqP112*dot[k1, k3]^2*P11[magM[k1]])/
  (210*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (563*b1^2*b2*IntdqP112*dot[k1, k3]^2*P11[magM[k1]])/
  (1470*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (66*b1*b2^2*IntdqP112*dot[k1, k3]^2*P11[magM[k1]])/
  (245*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (61*b1^2*b3*IntdqP112*dot[k1, k3]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (187*b1*b2*b3*IntdqP112*dot[k1, k3]^2*P11[magM[k1]])/
  (2205*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (17*b1^2*b5*IntdqP112*dot[k1, k3]^2*P11[magM[k1]])/
  (210*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (26*b1*b2*b5*IntdqP112*dot[k1, k3]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (13*b1*b3*b5*IntdqP112*dot[k1, k3]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1^2*b6*IntdqP112*dot[k1, k3]^2*P11[magM[k1]])/
  (15*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (116*b1*b2*b6*IntdqP112*dot[k1, k3]^2*P11[magM[k1]])/
  (735*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b1*b5*b6*IntdqP112*dot[k1, k3]^2*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (32*b1^2*b8*IntdqP112*dot[k1, k3]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b1*b2*b8*IntdqP112*dot[k1, k3]^2*P11[magM[k1]])/
  (735*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1*b5*b8*IntdqP112*dot[k1, k3]^2*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^3*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (19*b1^2*b2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1*b2^2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b1^2*b3*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (29*b1^2*b5*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1*b2*b5*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b1^2*b6*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (44*b1^2*b8*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*
   P11[magM[k1]])/(3*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*
   P11[magM[k1]])/(3*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*
   P11[magM[k1]])/(3*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (36*b1^2*f1*IntdqP112*dot[k1, k3]*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^3*f1*IntdqP112*dot[k1, k3]*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (36*b1*b2*f1*IntdqP112*dot[k1, k3]*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^2*b2*f1*IntdqP112*dot[k1, k3]*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (36*b1*b5*f1*IntdqP112*dot[k1, k3]*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^2*b5*f1*IntdqP112*dot[k1, k3]*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^2*f1^2*IntdqP112*dot[k1, k3]*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^2*f1*IntdqP112*dot[k1, k3]^3*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (563*b1*b2*f1*IntdqP112*dot[k1, k3]^3*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (735*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (132*b2^2*f1*IntdqP112*dot[k1, k3]^3*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (245*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (122*b1*b3*f1*IntdqP112*dot[k1, k3]^3*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (315*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (374*b2*b3*f1*IntdqP112*dot[k1, k3]^3*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (2205*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (17*b1*b5*f1*IntdqP112*dot[k1, k3]^3*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (52*b2*b5*f1*IntdqP112*dot[k1, k3]^3*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (26*b3*b5*f1*IntdqP112*dot[k1, k3]^3*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (315*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (8*b1*b6*f1*IntdqP112*dot[k1, k3]^3*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (15*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (232*b2*b6*f1*IntdqP112*dot[k1, k3]^3*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (735*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (8*b5*b6*f1*IntdqP112*dot[k1, k3]^3*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b1*b8*f1*IntdqP112*dot[k1, k3]^3*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (8*b2*b8*f1*IntdqP112*dot[k1, k3]^3*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (735*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (8*b5*b8*f1*IntdqP112*dot[k1, k3]^3*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (97*b1*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (2*b1^2*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*P11[magM[k1]])/(5*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b2*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (38*b1*b2*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*P11[magM[k1]])/(35*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (8*b2^2*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (32*b1*b3*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*P11[magM[k1]])/(105*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b5*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (58*b1*b5*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*P11[magM[k1]])/(105*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (8*b2*b5*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (32*b1*b6*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*P11[magM[k1]])/(105*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (88*b1*b8*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (2*b1*f1^3*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b2*f1^3*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (2*b5*f1^3*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (1357*b1*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(1470*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (2*b1^2*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (1261*b2*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(1470*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (2*b1*b2*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b3*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(245*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (187*b5*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(210*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1*b5*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (16*b6*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(245*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (44*b8*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(245*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (2*b1*f1^3*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b2*f1^3*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (2*b5*f1^3*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^3*IntdqP112*dot[k1, k3]^3*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (563*b1^2*b2*IntdqP112*dot[k1, k3]^3*P11[magM[k1]])/
  (735*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (132*b1*b2^2*IntdqP112*dot[k1, k3]^3*P11[magM[k1]])/
  (245*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (122*b1^2*b3*IntdqP112*dot[k1, k3]^3*P11[magM[k1]])/
  (315*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (374*b1*b2*b3*IntdqP112*dot[k1, k3]^3*P11[magM[k1]])/
  (2205*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (17*b1^2*b5*IntdqP112*dot[k1, k3]^3*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (52*b1*b2*b5*IntdqP112*dot[k1, k3]^3*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (26*b1*b3*b5*IntdqP112*dot[k1, k3]^3*P11[magM[k1]])/
  (315*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (8*b1^2*b6*IntdqP112*dot[k1, k3]^3*P11[magM[k1]])/
  (15*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (232*b1*b2*b6*IntdqP112*dot[k1, k3]^3*P11[magM[k1]])/
  (735*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (8*b1*b5*b6*IntdqP112*dot[k1, k3]^3*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b1^2*b8*IntdqP112*dot[k1, k3]^3*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (8*b1*b2*b8*IntdqP112*dot[k1, k3]^3*P11[magM[k1]])/
  (735*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (8*b1*b5*b8*IntdqP112*dot[k1, k3]^3*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^2*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (563*b1*b2*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (1470*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (66*b2^2*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (245*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (61*b1*b3*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (315*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (187*b2*b3*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (2205*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (17*b1*b5*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (26*b2*b5*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (13*b3*b5*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (315*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1*b6*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (15*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (116*b2*b6*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (735*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b5*b6*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (32*b1*b8*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b2*b8*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (735*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b5*b8*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (97*b1^2*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]*dot[k3, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (2*b1^3*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]*
   dot[k3, hat[z]]*P11[magM[k1]])/(5*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b1*b2*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]*dot[k3, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (38*b1^2*b2*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]*
   dot[k3, hat[z]]*P11[magM[k1]])/(35*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (8*b1*b2^2*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]*dot[k3, hat[z]]*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (32*b1^2*b3*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]*
   dot[k3, hat[z]]*P11[magM[k1]])/(105*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b1*b5*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]*dot[k3, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (58*b1^2*b5*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]*
   dot[k3, hat[z]]*P11[magM[k1]])/(105*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (8*b1*b2*b5*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]*dot[k3, hat[z]]*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (32*b1^2*b6*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]*
   dot[k3, hat[z]]*P11[magM[k1]])/(105*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (88*b1^2*b8*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]*dot[k3, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (2*b1^2*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]*
   dot[k3, hat[z]]*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1*b2*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]*dot[k3, hat[z]]*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (2*b1*b5*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]*
   dot[k3, hat[z]]*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   P11[magM[k1]])/(5*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (19*b1*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*P11[magM[k1]])/(35*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b2^2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (16*b1*b3*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*P11[magM[k1]])/(105*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (29*b1*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (4*b2*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*P11[magM[k1]])/(21*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b1*b6*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (44*b1*b8*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*P11[magM[k1]])/(105*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (b2*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b5*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (1357*b1^2*f1*IntdqP112*dot[k1, k3]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(1470*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (2*b1^3*f1*IntdqP112*dot[k1, k3]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (1261*b1*b2*f1*IntdqP112*dot[k1, k3]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(1470*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (2*b1^2*b2*f1*IntdqP112*dot[k1, k3]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (16*b1*b3*f1*IntdqP112*dot[k1, k3]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(245*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (187*b1*b5*f1*IntdqP112*dot[k1, k3]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (2*b1^2*b5*f1*IntdqP112*dot[k1, k3]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (16*b1*b6*f1*IntdqP112*dot[k1, k3]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(245*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (44*b1*b8*f1*IntdqP112*dot[k1, k3]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(245*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (2*b1^2*f1^2*IntdqP112*dot[k1, k3]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (2*b1*b2*f1^2*IntdqP112*dot[k1, k3]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (2*b1*b5*f1^2*IntdqP112*dot[k1, k3]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (36*b1*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(35*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (36*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(35*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (36*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(35*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (b1*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b2*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (b5*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (97*b1^2*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (210*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b1*b2*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (210*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b1*b5*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (210*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (338*b1^2*f1*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (8*b1^3*f1*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (338*b1*b2*f1*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (8*b1^2*b2*f1*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (256*b1*b3*f1*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (256*b2*b3*f1*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (338*b1*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (8*b1^2*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (256*b3*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (256*b1*b8*f1*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (256*b2*b8*f1*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (256*b5*b8*f1*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (64*b1^2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b1^3*f1^2*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b1*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1^2*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b1*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1^2*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (97*b1^2*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (210*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b1*b2*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (210*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b1*b5*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*P11[magM[k1]])/
  (210*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (99*b1*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (70*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (88*b1^2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (99*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (70*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (88*b1*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (99*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (70*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (88*b1*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (32*b1*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b1^2*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (32*b2*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1*b2*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (32*b5*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1*b5*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (99*b1*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (70*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (88*b1^2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (99*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (70*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (88*b1*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (99*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (70*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (88*b1*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (32*b1*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b1^2*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (32*b2*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1*b2*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (32*b5*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1*b5*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (46*b1*f1^3*IntdqP112*dot[k1, hat[z]]^6*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (46*b2*f1^3*IntdqP112*dot[k1, hat[z]]^6*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (46*b5*f1^3*IntdqP112*dot[k1, hat[z]]^6*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1*f1^4*IntdqP112*dot[k1, hat[z]]^6*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b2*f1^4*IntdqP112*dot[k1, hat[z]]^6*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b5*f1^4*IntdqP112*dot[k1, hat[z]]^6*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (114*b1^2*f1*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]*
   dot[k2, hat[z]]*P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (114*b1*b2*f1*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]*
   dot[k2, hat[z]]*P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (114*b1*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]*
   dot[k2, hat[z]]*P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (57*b1*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (57*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (57*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (6*b1*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (6*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (6*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (3*b1*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (114*b1^2*f1*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]*
   dot[k3, hat[z]]*P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (114*b1*b2*f1*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]*
   dot[k3, hat[z]]*P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (114*b1*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]*
   dot[k3, hat[z]]*P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (6*b1*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (6*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (6*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (57*b1*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (57*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (57*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (3*b1*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (97*b1*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, k3]*dot[k1, hat[z]]^4*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b2*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, k3]*dot[k1, hat[z]]^4*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b5*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, k3]*dot[k1, hat[z]]^4*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (97*b1*f1^2*IntdqP112*dot[k1, k2]*dot[k1, k3]^2*dot[k1, hat[z]]^4*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, k3]^2*dot[k1, hat[z]]^4*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, k3]^2*dot[k1, hat[z]]^4*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (184*b1*f1^3*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^6*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (184*b2*f1^3*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^6*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (184*b5*f1^3*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^6*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b1*f1^4*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^6*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b2*f1^4*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^6*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b5*f1^4*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^6*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (97*b1^2*f1*IntdqP112*dot[k1, k2]^2*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b1*b2*f1*IntdqP112*dot[k1, k2]^2*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b1*b5*f1*IntdqP112*dot[k1, k2]^2*dot[k1, k3]*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (97*b1^2*f1*IntdqP112*dot[k1, k2]*dot[k1, k3]^2*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b1*b2*f1*IntdqP112*dot[k1, k2]*dot[k1, k3]^2*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b1*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, k3]^2*dot[k1, hat[z]]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (97*b1*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b2*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b5*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (114*b1*f1^2*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^4*
   P11[magM[k1]])/(35*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (176*b1^2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^4*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (114*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^4*
   P11[magM[k1]])/(35*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (176*b1*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^4*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (114*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^4*
   P11[magM[k1]])/(35*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (176*b1*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^4*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (64*b1*f1^3*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^4*
   P11[magM[k1]])/(35*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (8*b1^2*f1^3*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^4*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b2*f1^3*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^4*
   P11[magM[k1]])/(35*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (8*b1*b2*f1^3*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^4*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b5*f1^3*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^4*
   P11[magM[k1]])/(35*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (8*b1*b5*f1^3*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^4*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (97*b1*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b2*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b5*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^4*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (92*b1*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^6*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (92*b2*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^6*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (92*b5*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^6*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1*f1^4*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^6*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b2*f1^4*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^6*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b5*f1^4*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^6*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (92*b1*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^6*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (92*b2*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^6*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (92*b5*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^6*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1*f1^4*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^6*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b2*f1^4*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^6*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b5*f1^4*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^6*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (114*b1*f1^2*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^3*
   dot[k2, hat[z]]*P11[magM[k1]])/(35*Pi^2*magM[k1]^2*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (114*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, k3]*
   dot[k1, hat[z]]^3*dot[k2, hat[z]]*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (114*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^3*
   dot[k2, hat[z]]*P11[magM[k1]])/(35*Pi^2*magM[k1]^2*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (114*b1*f1^2*IntdqP112*dot[k1, k2]*dot[k1, k3]*
   dot[k1, hat[z]]^3*dot[k3, hat[z]]*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (114*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, k3]*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*P11[magM[k1]])/(35*Pi^2*magM[k1]^2*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (114*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, k3]*
   dot[k1, hat[z]]^3*dot[k3, hat[z]]*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1^3*IntdqP112*dot[k1, k2]*dot[k1, k3]*magM[k1]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b1^2*b2*IntdqP112*dot[k1, k2]*dot[k1, k3]*magM[k1]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (256*b1^2*b3*IntdqP112*dot[k1, k2]*dot[k1, k3]*magM[k1]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (256*b1*b2*b3*IntdqP112*dot[k1, k2]*dot[k1, k3]*magM[k1]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b1^2*b5*IntdqP112*dot[k1, k2]*dot[k1, k3]*magM[k1]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (256*b1*b3*b5*IntdqP112*dot[k1, k2]*dot[k1, k3]*magM[k1]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (256*b1^2*b8*IntdqP112*dot[k1, k2]*dot[k1, k3]*magM[k1]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (256*b1*b2*b8*IntdqP112*dot[k1, k2]*dot[k1, k3]*magM[k1]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (256*b1*b5*b8*IntdqP112*dot[k1, k2]*dot[k1, k3]*magM[k1]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (293*b1^2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(210*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1^3*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (293*b1*b2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(210*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b1^2*b2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (128*b1*b3*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b2*b3*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (293*b1*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(210*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b1^2*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b3*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (128*b1*b8*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b2*b8*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b5*b8*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (32*b1^2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^3*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (32*b1*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1^2*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (32*b1*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1^2*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (293*b1^2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(210*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1^3*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k1]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (293*b1*b2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(210*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b1^2*b2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (128*b1*b3*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b2*b3*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (293*b1*b5*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(210*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b1^2*b5*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b3*b5*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (128*b1*b8*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b2*b8*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b5*b8*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (32*b1^2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^3*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (32*b1*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1^2*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (32*b1*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1^2*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (3*b1*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k1]^2*P11[magM[k1]])/
  (5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (44*b1^2*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k1]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b2*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k1]^2*P11[magM[k1]])/
  (5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (44*b1*b2*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k1]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b5*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k1]^2*P11[magM[k1]])/
  (5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (44*b1*b5*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k1]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (16*b1*f1^3*IntdqP112*dot[k1, hat[z]]^4*magM[k1]^2*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^2*f1^3*IntdqP112*dot[k1, hat[z]]^4*magM[k1]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b2*f1^3*IntdqP112*dot[k1, hat[z]]^4*magM[k1]^2*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1*b2*f1^3*IntdqP112*dot[k1, hat[z]]^4*magM[k1]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b5*f1^3*IntdqP112*dot[k1, hat[z]]^4*magM[k1]^2*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1*b5*f1^3*IntdqP112*dot[k1, hat[z]]^4*magM[k1]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (57*b1^2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (57*b1*b2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*
   magM[k1]^2*P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (57*b1*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*
   magM[k1]^2*P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (6*b1^2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (6*b1*b2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (6*b1*b5*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (3*b1*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k1]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b2*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k1]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b5*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k1]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (3*b1^2*f1*IntdqP112*dot[k1, k3]*dot[k2, hat[z]]^2*magM[k1]^2*P11[magM[k1]])/
  (5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b1*b2*f1*IntdqP112*dot[k1, k3]*dot[k2, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b1*b5*f1*IntdqP112*dot[k1, k3]*dot[k2, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (3*b1*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b2*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b5*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (6*b1^2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k1]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (6*b1*b2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k1]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (6*b1*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k1]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (57*b1^2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k1]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (57*b1*b2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*
   magM[k1]^2*P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (57*b1*b5*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*
   magM[k1]^2*P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (3*b1*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k1]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b2*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k1]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b5*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k1]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (3*b1^2*f1*IntdqP112*dot[k1, k2]*dot[k3, hat[z]]^2*magM[k1]^2*P11[magM[k1]])/
  (5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b1*b2*f1*IntdqP112*dot[k1, k2]*dot[k3, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b1*b5*f1*IntdqP112*dot[k1, k2]*dot[k3, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (3*b1*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b2*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b5*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*magM[k1]^2*
   P11[magM[k1]])/(10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1^3*IntdqP112*dot[k1, k2]*magM[k1]^4*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^2*b2*IntdqP112*dot[k1, k2]*magM[k1]^4*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (128*b1^2*b3*IntdqP112*dot[k1, k2]*magM[k1]^4*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b1*b2*b3*IntdqP112*dot[k1, k2]*magM[k1]^4*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^2*b5*IntdqP112*dot[k1, k2]*magM[k1]^4*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b1*b3*b5*IntdqP112*dot[k1, k2]*magM[k1]^4*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (128*b1^2*b8*IntdqP112*dot[k1, k2]*magM[k1]^4*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b1*b2*b8*IntdqP112*dot[k1, k2]*magM[k1]^4*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b1*b5*b8*IntdqP112*dot[k1, k2]*magM[k1]^4*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1^3*IntdqP112*dot[k1, k3]*magM[k1]^4*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^2*b2*IntdqP112*dot[k1, k3]*magM[k1]^4*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (128*b1^2*b3*IntdqP112*dot[k1, k3]*magM[k1]^4*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b1*b2*b3*IntdqP112*dot[k1, k3]*magM[k1]^4*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^2*b5*IntdqP112*dot[k1, k3]*magM[k1]^4*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b1*b3*b5*IntdqP112*dot[k1, k3]*magM[k1]^4*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (128*b1^2*b8*IntdqP112*dot[k1, k3]*magM[k1]^4*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b1*b2*b8*IntdqP112*dot[k1, k3]*magM[k1]^4*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b1*b5*b8*IntdqP112*dot[k1, k3]*magM[k1]^4*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (62*b1^2*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^4*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1^3*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^4*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (62*b1*b2*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^4*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^2*b2*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^4*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (64*b1*b3*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^4*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b2*b3*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^4*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (62*b1*b5*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^4*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^2*b5*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^4*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b3*b5*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^4*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (64*b1*b8*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^4*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b2*b8*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^4*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b5*b8*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^4*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (16*b1^2*f1^2*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^4*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^3*f1^2*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^4*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b1*b2*f1^2*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^4*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^2*b2*f1^2*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^4*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b1*b5*f1^2*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^4*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^2*b5*f1^2*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^4*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (3*b1^2*f1*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^4*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b1*b2*f1*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^4*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b1*b5*f1*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^4*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (3*b1^2*f1*IntdqP112*dot[k2, hat[z]]^2*magM[k1]^4*P11[magM[k1]])/
  (10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b1*b2*f1*IntdqP112*dot[k2, hat[z]]^2*magM[k1]^4*P11[magM[k1]])/
  (10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b1*b5*f1*IntdqP112*dot[k2, hat[z]]^2*magM[k1]^4*P11[magM[k1]])/
  (10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (3*b1^2*f1*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k1]^4*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b1*b2*f1*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k1]^4*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b1*b5*f1*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k1]^4*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (3*b1^2*f1*IntdqP112*dot[k3, hat[z]]^2*magM[k1]^4*P11[magM[k1]])/
  (10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b1*b2*f1*IntdqP112*dot[k3, hat[z]]^2*magM[k1]^4*P11[magM[k1]])/
  (10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b1*b5*f1*IntdqP112*dot[k3, hat[z]]^2*magM[k1]^4*P11[magM[k1]])/
  (10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^3*IntdqP112*magM[k1]^6*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^2*b2*IntdqP112*magM[k1]^6*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (64*b1^2*b3*IntdqP112*magM[k1]^6*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b1*b2*b3*IntdqP112*magM[k1]^6*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^2*b5*IntdqP112*magM[k1]^6*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b1*b3*b5*IntdqP112*magM[k1]^6*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (64*b1^2*b8*IntdqP112*magM[k1]^6*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b1*b2*b8*IntdqP112*magM[k1]^6*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b1*b5*b8*IntdqP112*magM[k1]^6*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (93*b1^2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(70*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1^3*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (93*b1*b2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(70*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b1^2*b2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (128*b1*b3*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b2*b3*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (93*b1*b5*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(70*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b1^2*b5*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b3*b5*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (128*b1*b8*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b2*b8*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b5*b8*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (32*b1^2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^3*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (32*b1*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1^2*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (32*b1*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1^2*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (17*b1*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (30*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (44*b1^2*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (17*b2*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (30*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (44*b1*b2*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (17*b5*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (30*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (44*b1*b5*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (16*b1*f1^3*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^2*f1^3*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b2*f1^3*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1*b2*f1^3*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b5*f1^3*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1*b5*f1^3*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (57*b1^2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (57*b1*b2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*
   magM[k2]^2*P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (57*b1*b5*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*
   magM[k2]^2*P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (3*b1*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b2*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b5*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k2]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (3*b1*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b2*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b5*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (97*b1*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^4*magM[k2]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b2*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^4*magM[k2]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b5*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^4*magM[k2]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (92*b1*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^6*magM[k2]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (92*b2*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^6*magM[k2]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (92*b5*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^6*magM[k2]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1*f1^4*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^6*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b2*f1^4*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^6*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b5*f1^4*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^6*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (97*b1^2*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b1*b2*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b1*b5*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*magM[k2]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (283*b1*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*magM[k2]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (88*b1^2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*magM[k2]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (283*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*magM[k2]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (88*b1*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*magM[k2]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (283*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*magM[k2]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (88*b1*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*magM[k2]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (32*b1*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*magM[k2]^2*
   P11[magM[k1]])/(35*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b1^2*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (32*b2*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*magM[k2]^2*
   P11[magM[k1]])/(35*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1*b2*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (32*b5*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*magM[k2]^2*
   P11[magM[k1]])/(35*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1*b5*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (46*b1*f1^3*IntdqP112*dot[k1, hat[z]]^6*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (46*b2*f1^3*IntdqP112*dot[k1, hat[z]]^6*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (46*b5*f1^3*IntdqP112*dot[k1, hat[z]]^6*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1*f1^4*IntdqP112*dot[k1, hat[z]]^6*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b2*f1^4*IntdqP112*dot[k1, hat[z]]^6*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b5*f1^4*IntdqP112*dot[k1, hat[z]]^6*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (57*b1*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   magM[k2]^2*P11[magM[k1]])/(35*Pi^2*magM[k1]^2*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (57*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*magM[k2]^2*P11[magM[k1]])/(35*Pi^2*magM[k1]^2*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (57*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*magM[k2]^2*P11[magM[k1]])/(35*Pi^2*magM[k1]^2*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (2*b1^3*IntdqP112*dot[k1, k3]*magM[k1]^2*magM[k2]^2*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^2*b2*IntdqP112*dot[k1, k3]*magM[k1]^2*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (128*b1^2*b3*IntdqP112*dot[k1, k3]*magM[k1]^2*magM[k2]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b1*b2*b3*IntdqP112*dot[k1, k3]*magM[k1]^2*magM[k2]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^2*b5*IntdqP112*dot[k1, k3]*magM[k1]^2*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b1*b3*b5*IntdqP112*dot[k1, k3]*magM[k1]^2*magM[k2]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (128*b1^2*b8*IntdqP112*dot[k1, k3]*magM[k1]^2*magM[k2]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b1*b2*b8*IntdqP112*dot[k1, k3]*magM[k1]^2*magM[k2]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b1*b5*b8*IntdqP112*dot[k1, k3]*magM[k1]^2*magM[k2]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (39*b1^2*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2*P11[magM[k1]])/
  (70*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1^3*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (39*b1*b2*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2*
   P11[magM[k1]])/(70*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^2*b2*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (64*b1*b3*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2*
   P11[magM[k1]])/(315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b2*b3*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2*
   P11[magM[k1]])/(315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (39*b1*b5*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2*
   P11[magM[k1]])/(70*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^2*b5*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b3*b5*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2*
   P11[magM[k1]])/(315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (64*b1*b8*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b2*b8*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b5*b8*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (16*b1^2*f1^2*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^3*f1^2*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b1*b2*f1^2*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^2*b2*f1^2*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b1*b5*f1^2*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^2*b5*f1^2*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2*
   P11[magM[k1]])/(3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (3*b1^2*f1*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k1]^2*magM[k2]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b1*b2*f1*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k1]^2*magM[k2]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b1*b5*f1*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k1]^2*magM[k2]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (3*b1^2*f1*IntdqP112*dot[k3, hat[z]]^2*magM[k1]^2*magM[k2]^2*P11[magM[k1]])/
  (10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b1*b2*f1*IntdqP112*dot[k3, hat[z]]^2*magM[k1]^2*magM[k2]^2*P11[magM[k1]])/
  (10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b1*b5*f1*IntdqP112*dot[k3, hat[z]]^2*magM[k1]^2*magM[k2]^2*P11[magM[k1]])/
  (10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^3*IntdqP112*magM[k1]^4*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^2*b2*IntdqP112*magM[k1]^4*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (64*b1^2*b3*IntdqP112*magM[k1]^4*magM[k2]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b1*b2*b3*IntdqP112*magM[k1]^4*magM[k2]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^2*b5*IntdqP112*magM[k1]^4*magM[k2]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b1*b3*b5*IntdqP112*magM[k1]^4*magM[k2]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (64*b1^2*b8*IntdqP112*magM[k1]^4*magM[k2]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b1*b2*b8*IntdqP112*magM[k1]^4*magM[k2]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b1*b5*b8*IntdqP112*magM[k1]^4*magM[k2]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (8*b1^2*f1*IntdqP112*dot[k1, k3]^2*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (245*Pi^2*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (8*b1*b2*f1*IntdqP112*dot[k1, k3]^2*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (245*Pi^2*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b1*b3*f1*IntdqP112*dot[k1, k3]^2*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (245*Pi^2*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b1*b6*f1*IntdqP112*dot[k1, k3]^2*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (245*Pi^2*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (44*b1*b8*f1*IntdqP112*dot[k1, k3]^2*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (245*Pi^2*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (16*b1*f1^2*IntdqP112*dot[k1, k3]^3*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(245*Pi^2*magM[k1]^4*magM[k3]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (16*b2*f1^2*IntdqP112*dot[k1, k3]^3*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(245*Pi^2*magM[k1]^4*magM[k3]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (32*b3*f1^2*IntdqP112*dot[k1, k3]^3*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(245*Pi^2*magM[k1]^4*magM[k3]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (32*b6*f1^2*IntdqP112*dot[k1, k3]^3*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(245*Pi^2*magM[k1]^4*magM[k3]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (88*b8*f1^2*IntdqP112*dot[k1, k3]^3*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(245*Pi^2*magM[k1]^4*magM[k3]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (16*b1^2*f1*IntdqP112*dot[k1, k3]^3*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (245*Pi^2*magM[k1]^2*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (16*b1*b2*f1*IntdqP112*dot[k1, k3]^3*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(245*Pi^2*magM[k1]^2*magM[k3]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (32*b1*b3*f1*IntdqP112*dot[k1, k3]^3*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (245*Pi^2*magM[k1]^2*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (32*b1*b6*f1*IntdqP112*dot[k1, k3]^3*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(245*Pi^2*magM[k1]^2*magM[k3]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (88*b1*b8*f1*IntdqP112*dot[k1, k3]^3*dot[k3, hat[z]]^2*P11[magM[k1]])/
  (245*Pi^2*magM[k1]^2*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (8*b1*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*P11[magM[k1]])/(245*Pi^2*magM[k1]^2*magM[k3]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (8*b2*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(245*Pi^2*magM[k1]^2*magM[k3]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b3*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(245*Pi^2*magM[k1]^2*magM[k3]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b6*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(245*Pi^2*magM[k1]^2*magM[k3]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (44*b8*f1^2*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   P11[magM[k1]])/(245*Pi^2*magM[k1]^2*magM[k3]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^3*IntdqP112*dot[k1, k3]*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (5*b1^2*b2*IntdqP112*dot[k1, k3]*magM[k3]^2*P11[magM[k1]])/
  (7*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (8*b1*b2^2*IntdqP112*dot[k1, k3]*magM[k3]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^2*b5*IntdqP112*dot[k1, k3]*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (8*b1*b2*b5*IntdqP112*dot[k1, k3]*magM[k3]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^3*Intdqq2P11P11pp*dot[k1, k3]*magM[k3]^2*P11[magM[k1]])/
  (6*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^2*b2*Intdqq2P11P11pp*dot[k1, k3]*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1*b2^2*Intdqq2P11P11pp*dot[k1, k3]*magM[k3]^2*P11[magM[k1]])/
  (6*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^2*b5*Intdqq2P11P11pp*dot[k1, k3]*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1*b2*b5*Intdqq2P11P11pp*dot[k1, k3]*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1*b5^2*Intdqq2P11P11pp*dot[k1, k3]*magM[k3]^2*P11[magM[k1]])/
  (6*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^3*IntdqqP11P11p*dot[k1, k3]*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1^2*b2*IntdqqP11P11p*dot[k1, k3]*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1*b2^2*IntdqqP11P11p*dot[k1, k3]*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1^2*b5*IntdqqP11P11p*dot[k1, k3]*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1*b2*b5*IntdqqP11P11p*dot[k1, k3]*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1*b5^2*IntdqqP11P11p*dot[k1, k3]*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (8*b1^2*f1*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(15*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (8*b1*b2*f1*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(15*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (8*b1*b5*f1*IntdqP112*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(15*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b1^2*f1*IntdqP112*dot[k3, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (15*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1*b2*f1*IntdqP112*dot[k3, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (15*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1*b5*f1*IntdqP112*dot[k3, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (15*Pi^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (47*b1^2*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(70*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (2663*b1*b2*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(1470*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (758*b2^2*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(735*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (61*b1*b3*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(315*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (187*b2*b3*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(2205*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (157*b1*b5*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(210*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (106*b2*b5*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (13*b3*b5*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(315*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1*b6*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(15*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (116*b2*b6*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(735*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b5*b6*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(35*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (32*b1*b8*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b2*b8*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(735*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (4*b5*b8*f1*IntdqP112*dot[k1, k3]^2*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(35*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^2*f1*Intdqq2P11P11pp*dot[k1, k3]^2*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (2*b1*b2*f1*Intdqq2P11P11pp*dot[k1, k3]^2*
   dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b2^2*f1*Intdqq2P11P11pp*dot[k1, k3]^2*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (2*b1*b5*f1*Intdqq2P11P11pp*dot[k1, k3]^2*
   dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b2*b5*f1*Intdqq2P11P11pp*dot[k1, k3]^2*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (b5^2*f1*Intdqq2P11P11pp*dot[k1, k3]^2*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (2*b1^2*f1*IntdqqP11P11p*dot[k1, k3]^2*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (4*b1*b2*f1*IntdqqP11P11p*dot[k1, k3]^2*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (2*b2^2*f1*IntdqqP11P11p*dot[k1, k3]^2*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (4*b1*b5*f1*IntdqqP11P11p*dot[k1, k3]^2*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (4*b2*b5*f1*IntdqqP11P11p*dot[k1, k3]^2*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (2*b5^2*f1*IntdqqP11P11p*dot[k1, k3]^2*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (3*b1*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*
   magM[k3]^2*P11[magM[k1]])/(14*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*magM[k3]^2*P11[magM[k1]])/
  (14*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^4*magM[k3]^2*P11[magM[k1]])/
  (14*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (3*b1*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   magM[k3]^2*P11[magM[k1]])/(7*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (b1^2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*magM[k3]^2*P11[magM[k1]])/
  (5*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   magM[k3]^2*P11[magM[k1]])/(7*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (19*b1*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*magM[k3]^2*P11[magM[k1]])/(35*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b2^2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   magM[k3]^2*P11[magM[k1]])/(21*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b1*b3*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   magM[k3]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   magM[k3]^2*P11[magM[k1]])/(7*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (29*b1*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*magM[k3]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b2*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   magM[k3]^2*P11[magM[k1]])/(21*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b1*b6*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   magM[k3]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (44*b1*b8*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   magM[k3]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (b2*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*
   dot[k3, hat[z]]*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b5*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (3*b1*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (7*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (3*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (7*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (3*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (7*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (b1*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b2*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (b5*f1^3*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*
   dot[k3, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (47*b1^3*IntdqP112*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (70*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2663*b1^2*b2*IntdqP112*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (1470*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (758*b1*b2^2*IntdqP112*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (735*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (61*b1^2*b3*IntdqP112*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (315*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (187*b1*b2*b3*IntdqP112*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (2205*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (157*b1^2*b5*IntdqP112*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (210*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (106*b1*b2*b5*IntdqP112*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (13*b1*b3*b5*IntdqP112*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (315*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1^2*b6*IntdqP112*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (15*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (116*b1*b2*b6*IntdqP112*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (735*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b1*b5*b6*IntdqP112*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (32*b1^2*b8*IntdqP112*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b1*b2*b8*IntdqP112*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (735*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1*b5*b8*IntdqP112*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^3*Intdqq2P11P11pp*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1^2*b2*Intdqq2P11P11pp*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1*b2^2*Intdqq2P11P11pp*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1^2*b5*Intdqq2P11P11pp*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1*b2*b5*Intdqq2P11P11pp*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1*b5^2*Intdqq2P11P11pp*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^3*IntdqqP11P11p*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1^2*b2*IntdqqP11P11p*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1*b2^2*IntdqqP11P11p*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1^2*b5*IntdqqP11P11p*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b1*b2*b5*IntdqqP11P11p*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1*b5^2*IntdqqP11P11p*dot[k1, k3]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (5*b1^2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (42*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1*b2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (2*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (8*b2^2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (5*b1*b5*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(42*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (8*b2*b5*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(21*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^2*f1*Intdqq2P11P11pp*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(6*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (b1*b2*f1*Intdqq2P11P11pp*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (b2^2*f1*Intdqq2P11P11pp*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(6*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (b1*b5*f1*Intdqq2P11P11pp*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (b2*b5*f1*Intdqq2P11P11pp*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (b5^2*f1*Intdqq2P11P11pp*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(6*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (b1^2*f1*IntdqqP11P11p*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (2*b1*b2*f1*IntdqqP11P11p*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (b2^2*f1*IntdqqP11P11p*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (2*b1*b5*f1*IntdqqP11P11p*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (2*b2*b5*f1*IntdqqP11P11p*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (b5^2*f1*IntdqqP11P11p*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (3*b1^2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*
   dot[k3, hat[z]]*magM[k3]^2*P11[magM[k1]])/
  (7*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^3*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(5*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (3*b1*b2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*
   dot[k3, hat[z]]*magM[k3]^2*P11[magM[k1]])/
  (7*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (19*b1^2*b2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*
   magM[k3]^2*P11[magM[k1]])/(35*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1*b2^2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*
   magM[k3]^2*P11[magM[k1]])/(21*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b1^2*b3*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*
   magM[k3]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b1*b5*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(7*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (29*b1^2*b5*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*
   dot[k3, hat[z]]*magM[k3]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1*b2*b5*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*
   magM[k3]^2*P11[magM[k1]])/(21*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b1^2*b6*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*
   magM[k3]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (44*b1^2*b8*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*
   magM[k3]^2*P11[magM[k1]])/(105*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (b1*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*
   dot[k3, hat[z]]*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (8*b1*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   magM[k3]^2*P11[magM[k1]])/(15*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (8*b2*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(15*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (8*b5*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k3, hat[z]]*
   magM[k3]^2*P11[magM[k1]])/(15*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (3*b1^2*f1*IntdqP112*dot[k1, k3]*dot[k3, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (7*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^3*f1*IntdqP112*dot[k1, k3]*dot[k3, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b1*b2*f1*IntdqP112*dot[k1, k3]*dot[k3, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(7*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (b1^2*b2*f1*IntdqP112*dot[k1, k3]*dot[k3, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (3*b1*b5*f1*IntdqP112*dot[k1, k3]*dot[k3, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(7*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (b1^2*b5*f1*IntdqP112*dot[k1, k3]*dot[k3, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (b1^2*f1^2*IntdqP112*dot[k1, k3]*dot[k3, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (b1*b2*f1^2*IntdqP112*dot[k1, k3]*dot[k3, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (b1*b5*f1^2*IntdqP112*dot[k1, k3]*dot[k3, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (4*b1*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(15*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b2*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(15*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (4*b5*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k3, hat[z]]^2*
   magM[k3]^2*P11[magM[k1]])/(15*Pi^2*magM[k1]^2*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (93*b1^2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(70*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1^3*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (93*b1*b2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(70*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b1^2*b2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (128*b1*b3*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b2*b3*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (93*b1*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(70*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b1^2*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b3*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (128*b1*b8*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b2*b8*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b5*b8*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (32*b1^2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^3*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (32*b1*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1^2*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (32*b1*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1^2*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (17*b1*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k3]^2*P11[magM[k1]])/
  (30*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (44*b1^2*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (17*b2*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k3]^2*P11[magM[k1]])/
  (30*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (44*b1*b2*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (17*b5*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k3]^2*P11[magM[k1]])/
  (30*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (44*b1*b5*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (16*b1*f1^3*IntdqP112*dot[k1, hat[z]]^4*magM[k3]^2*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^2*f1^3*IntdqP112*dot[k1, hat[z]]^4*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b2*f1^3*IntdqP112*dot[k1, hat[z]]^4*magM[k3]^2*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1*b2*f1^3*IntdqP112*dot[k1, hat[z]]^4*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b5*f1^3*IntdqP112*dot[k1, hat[z]]^4*magM[k3]^2*P11[magM[k1]])/
  (35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1*b5*f1^3*IntdqP112*dot[k1, hat[z]]^4*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (57*b1^2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (57*b1*b2*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*
   magM[k3]^2*P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (57*b1*b5*f1*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*
   magM[k3]^2*P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (3*b1*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b2*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b5*f1^2*IntdqP112*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k3]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (3*b1*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b2*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b5*f1^2*IntdqP112*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (97*b1*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^4*magM[k3]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b2*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^4*magM[k3]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b5*f1^2*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^4*magM[k3]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (92*b1*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^6*magM[k3]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (92*b2*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^6*magM[k3]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (92*b5*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^6*magM[k3]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1*f1^4*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^6*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b2*f1^4*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^6*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b5*f1^4*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^6*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (97*b1^2*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b1*b2*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (97*b1*b5*f1*IntdqP112*dot[k1, k2]^2*dot[k1, hat[z]]^2*magM[k3]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (283*b1*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*magM[k3]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (88*b1^2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*magM[k3]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (283*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*magM[k3]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (88*b1*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*magM[k3]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (283*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*magM[k3]^2*
   P11[magM[k1]])/(210*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (88*b1*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*magM[k3]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (32*b1*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*magM[k3]^2*
   P11[magM[k1]])/(35*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (4*b1^2*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (32*b2*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*magM[k3]^2*
   P11[magM[k1]])/(35*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1*b2*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (32*b5*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*magM[k3]^2*
   P11[magM[k1]])/(35*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (4*b1*b5*f1^3*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^4*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (46*b1*f1^3*IntdqP112*dot[k1, hat[z]]^6*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (46*b2*f1^3*IntdqP112*dot[k1, hat[z]]^6*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (46*b5*f1^3*IntdqP112*dot[k1, hat[z]]^6*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1*f1^4*IntdqP112*dot[k1, hat[z]]^6*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b2*f1^4*IntdqP112*dot[k1, hat[z]]^6*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b5*f1^4*IntdqP112*dot[k1, hat[z]]^6*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (57*b1*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
   magM[k3]^2*P11[magM[k1]])/(35*Pi^2*magM[k1]^2*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (57*b2*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^3*
   dot[k2, hat[z]]*magM[k3]^2*P11[magM[k1]])/(35*Pi^2*magM[k1]^2*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (57*b5*f1^2*IntdqP112*dot[k1, k2]*dot[k1, hat[z]]^3*
   dot[k2, hat[z]]*magM[k3]^2*P11[magM[k1]])/(35*Pi^2*magM[k1]^2*
   (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (2*b1^3*IntdqP112*dot[k1, k2]*magM[k1]^2*magM[k3]^2*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^2*b2*IntdqP112*dot[k1, k2]*magM[k1]^2*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (128*b1^2*b3*IntdqP112*dot[k1, k2]*magM[k1]^2*magM[k3]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b1*b2*b3*IntdqP112*dot[k1, k2]*magM[k1]^2*magM[k3]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^2*b5*IntdqP112*dot[k1, k2]*magM[k1]^2*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b1*b3*b5*IntdqP112*dot[k1, k2]*magM[k1]^2*magM[k3]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (128*b1^2*b8*IntdqP112*dot[k1, k2]*magM[k1]^2*magM[k3]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b1*b2*b8*IntdqP112*dot[k1, k2]*magM[k1]^2*magM[k3]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (128*b1*b5*b8*IntdqP112*dot[k1, k2]*magM[k1]^2*magM[k3]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (39*b1^2*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k3]^2*P11[magM[k1]])/
  (70*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1^3*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (39*b1*b2*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k3]^2*
   P11[magM[k1]])/(70*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^2*b2*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k3]^2*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (64*b1*b3*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k3]^2*
   P11[magM[k1]])/(315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b2*b3*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k3]^2*
   P11[magM[k1]])/(315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (39*b1*b5*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k3]^2*
   P11[magM[k1]])/(70*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^2*b5*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k3]^2*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b3*b5*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k3]^2*
   P11[magM[k1]])/(315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (64*b1*b8*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k3]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b2*b8*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k3]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b5*b8*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k3]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (16*b1^2*f1^2*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k3]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^3*f1^2*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b1*b2*f1^2*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k3]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^2*b2*f1^2*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b1*b5*f1^2*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k3]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^2*b5*f1^2*IntdqP112*dot[k1, hat[z]]^2*magM[k1]^2*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (3*b1^2*f1*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*magM[k3]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b1*b2*f1*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*magM[k3]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b1*b5*f1*IntdqP112*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*magM[k3]^2*
   P11[magM[k1]])/(5*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (3*b1^2*f1*IntdqP112*dot[k2, hat[z]]^2*magM[k1]^2*magM[k3]^2*P11[magM[k1]])/
  (10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b1*b2*f1*IntdqP112*dot[k2, hat[z]]^2*magM[k1]^2*magM[k3]^2*P11[magM[k1]])/
  (10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (3*b1*b5*f1*IntdqP112*dot[k2, hat[z]]^2*magM[k1]^2*magM[k3]^2*P11[magM[k1]])/
  (10*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^3*IntdqP112*magM[k1]^4*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^2*b2*IntdqP112*magM[k1]^4*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (64*b1^2*b3*IntdqP112*magM[k1]^4*magM[k3]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b1*b2*b3*IntdqP112*magM[k1]^4*magM[k3]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^2*b5*IntdqP112*magM[k1]^4*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b1*b3*b5*IntdqP112*magM[k1]^4*magM[k3]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (64*b1^2*b8*IntdqP112*magM[k1]^4*magM[k3]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b1*b2*b8*IntdqP112*magM[k1]^4*magM[k3]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b1*b5*b8*IntdqP112*magM[k1]^4*magM[k3]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (11*b1^2*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*magM[k3]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1^3*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (11*b1*b2*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*magM[k3]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^2*b2*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*magM[k3]^2*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (64*b1*b3*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*magM[k3]^2*
   P11[magM[k1]])/(315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b2*b3*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*magM[k3]^2*
   P11[magM[k1]])/(315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (11*b1*b5*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*magM[k3]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^2*b5*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*magM[k3]^2*
   P11[magM[k1]])/(105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b3*b5*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*magM[k3]^2*
   P11[magM[k1]])/(315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (64*b1*b8*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*magM[k3]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b2*b8*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*magM[k3]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b5*b8*f1*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*magM[k3]^2*
   P11[magM[k1]])/(21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (16*b1^2*f1^2*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*magM[k3]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^3*f1^2*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b1*b2*f1^2*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*magM[k3]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^2*b2*f1^2*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b1*b5*f1^2*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*magM[k3]^2*
   P11[magM[k1]])/(35*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^2*b5*f1^2*IntdqP112*dot[k1, hat[z]]^2*magM[k2]^2*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (46*b1*f1^3*IntdqP112*dot[k1, hat[z]]^6*magM[k2]^2*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (46*b2*f1^3*IntdqP112*dot[k1, hat[z]]^6*magM[k2]^2*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (46*b5*f1^3*IntdqP112*dot[k1, hat[z]]^6*magM[k2]^2*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1*f1^4*IntdqP112*dot[k1, hat[z]]^6*magM[k2]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b2*f1^4*IntdqP112*dot[k1, hat[z]]^6*magM[k2]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b5*f1^4*IntdqP112*dot[k1, hat[z]]^6*magM[k2]^2*magM[k3]^2*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (8*b1*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*magM[k3]^2*P11[magM[k1]])/
  (15*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (44*b1^2*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*magM[k3]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (8*b2*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*magM[k3]^2*P11[magM[k1]])/
  (15*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (44*b1*b2*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*magM[k3]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (8*b5*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*magM[k3]^2*P11[magM[k1]])/
  (15*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (44*b1*b5*f1^2*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*magM[k3]^2*
   P11[magM[k1]])/(105*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (16*b1*f1^3*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*magM[k3]^2*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1^2*f1^3*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b2*f1^3*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*magM[k3]^2*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1*b2*f1^3*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (16*b5*f1^3*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*magM[k3]^2*P11[magM[k1]])/
  (35*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1*b5*f1^3*IntdqP112*dot[k1, hat[z]]^4*magM[k2]^2*magM[k3]^2*
   P11[magM[k1]])/(3*Pi^2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
    magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^3*IntdqP112*magM[k1]^2*magM[k2]^2*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^2*b2*IntdqP112*magM[k1]^2*magM[k2]^2*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (64*b1^2*b3*IntdqP112*magM[k1]^2*magM[k2]^2*magM[k3]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b1*b2*b3*IntdqP112*magM[k1]^2*magM[k2]^2*magM[k3]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^2*b5*IntdqP112*magM[k1]^2*magM[k2]^2*magM[k3]^2*P11[magM[k1]])/
  (105*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b1*b3*b5*IntdqP112*magM[k1]^2*magM[k2]^2*magM[k3]^2*P11[magM[k1]])/
  (315*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (64*b1^2*b8*IntdqP112*magM[k1]^2*magM[k2]^2*magM[k3]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b1*b2*b8*IntdqP112*magM[k1]^2*magM[k2]^2*magM[k3]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (64*b1*b5*b8*IntdqP112*magM[k1]^2*magM[k2]^2*magM[k3]^2*P11[magM[k1]])/
  (21*Pi^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k3]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (5*b1*b2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k3]^4*
   P11[magM[k1]])/(7*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (8*b2^2*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^4*P11[magM[k1]])/(21*Pi^2*magM[k1]^4*
   (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1*b5*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k3]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (8*b2*b5*f1*IntdqP112*dot[k1, k3]*dot[k1, hat[z]]^2*magM[k3]^4*
   P11[magM[k1]])/(21*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (b1^2*f1*Intdqq2P11P11pp*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^4*P11[magM[k1]])/(6*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (b1*b2*f1*Intdqq2P11P11pp*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^4*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (b2^2*f1*Intdqq2P11P11pp*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^4*P11[magM[k1]])/(6*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (b1*b5*f1*Intdqq2P11P11pp*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^4*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (b2*b5*f1*Intdqq2P11P11pp*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^4*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (b5^2*f1*Intdqq2P11P11pp*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^4*P11[magM[k1]])/(6*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (b1^2*f1*IntdqqP11P11p*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^4*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (2*b1*b2*f1*IntdqqP11P11p*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^4*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (b2^2*f1*IntdqqP11P11p*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^4*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (2*b1*b5*f1*IntdqqP11P11p*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^4*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (2*b2*b5*f1*IntdqqP11P11p*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^4*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) + (b5^2*f1*IntdqqP11P11p*dot[k1, k3]*dot[k1, hat[z]]^2*
   magM[k3]^4*P11[magM[k1]])/(3*Pi^2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
    magM[k3]^2)) - (b1^3*IntdqP112*dot[k1, k3]*magM[k3]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (5*b1^2*b2*IntdqP112*dot[k1, k3]*magM[k3]^4*P11[magM[k1]])/
  (7*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (8*b1*b2^2*IntdqP112*dot[k1, k3]*magM[k3]^4*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^2*b5*IntdqP112*dot[k1, k3]*magM[k3]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (8*b1*b2*b5*IntdqP112*dot[k1, k3]*magM[k3]^4*P11[magM[k1]])/
  (21*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^3*Intdqq2P11P11pp*dot[k1, k3]*magM[k3]^4*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^2*b2*Intdqq2P11P11pp*dot[k1, k3]*magM[k3]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1*b2^2*Intdqq2P11P11pp*dot[k1, k3]*magM[k3]^4*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (b1^2*b5*Intdqq2P11P11pp*dot[k1, k3]*magM[k3]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1*b2*b5*Intdqq2P11P11pp*dot[k1, k3]*magM[k3]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1*b5^2*Intdqq2P11P11pp*dot[k1, k3]*magM[k3]^4*P11[magM[k1]])/
  (6*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1^3*IntdqqP11P11p*dot[k1, k3]*magM[k3]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1^2*b2*IntdqqP11P11p*dot[k1, k3]*magM[k3]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1*b2^2*IntdqqP11P11p*dot[k1, k3]*magM[k3]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) - 
 (2*b1^2*b5*IntdqqP11P11p*dot[k1, k3]*magM[k3]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (2*b1*b2*b5*IntdqqP11P11p*dot[k1, k3]*magM[k3]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
 (b1*b5^2*IntdqqP11P11p*dot[k1, k3]*magM[k3]^4*P11[magM[k1]])/
  (3*Pi^2*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2))
