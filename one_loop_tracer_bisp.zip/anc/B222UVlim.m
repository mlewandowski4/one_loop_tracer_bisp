(* Created with the Wolfram Language : www.wolfram.com *)
-1/24010*(IntdqP113oq4*(2*f1*dot[hat[k1], hat[z]]^2*
     (9 + 18*f1*dot[hat[k1], hat[z]]^2 + 7*f1^2*dot[hat[k1], hat[z]]^2)*
     (5 + 3*f1*dot[hat[k2], hat[z]]^2)*magM[k1]^8 - 
    4*f1*dot[hat[k1], hat[z]]*dot[hat[k2], hat[z]]*
     (-45 + 2*f1^2*dot[hat[k1], hat[z]]^2*(7 + 133*dot[hat[k1], hat[z]]^2 - 
        27*dot[hat[k2], hat[z]]^2) - 27*f1*(dot[hat[k1], hat[z]]^2 + 
        dot[hat[k2], hat[z]]^2) + 21*f1^3*
       (-(dot[hat[k1], hat[z]]^2*dot[hat[k2], hat[z]]^2) + 
        dot[hat[k1], hat[z]]^4*(7 + 4*dot[hat[k2], hat[z]]^2)))*magM[k1]^7*
     magM[k2] - 2*magM[k1]^6*
     (f1*(-9*dot[hat[k2], hat[z]]^2*(5 + 3*f1*dot[hat[k2], hat[z]]^2) - 
        14*f1^2*dot[hat[k1], hat[z]]^6*(-11 + 24*f1*dot[hat[k2], hat[z]]^2 + 
          42*f1^2*dot[hat[k2], hat[z]]^2) - 3*dot[hat[k1], hat[z]]^2*
         (-15 - 84*f1*dot[hat[k2], hat[z]]^2 + 7*f1^3*dot[hat[k2], hat[z]]^
            4 + 6*f1^2*dot[hat[k2], hat[z]]^2*
           (-7 + 3*dot[hat[k2], hat[z]]^2)) + f1*dot[hat[k1], hat[z]]^4*
         (27 + 21*f1^2*dot[hat[k2], hat[z]]^2*
           (29 + 24*dot[hat[k2], hat[z]]^2) + 
          2*f1*(35 + 832*dot[hat[k2], hat[z]]^2)))*magM[k2]^2 + 
      (-15 - 42*f1*dot[hat[k1], hat[z]]^2 + 7*f1^3*dot[hat[k1], hat[z]]^4 + 
        2*f1^2*dot[hat[k1], hat[z]]^2*(-28 + 9*dot[hat[k1], hat[z]]^2))*
       (5 + 3*f1*dot[hat[k2], hat[z]]^2)*magM[k3]^2) + 
    2*f1*dot[hat[k1], hat[z]]*dot[hat[k2], hat[z]]*magM[k1]^5*magM[k2]*
     (2*(-45 + 1176*f1^4*dot[hat[k1], hat[z]]^4*dot[hat[k2], hat[z]]^2 + 
        9*f1*(11*dot[hat[k1], hat[z]]^2 - 17*dot[hat[k2], hat[z]]^2) - 
        2*f1^2*(119*dot[hat[k1], hat[z]]^4 + 7*dot[hat[k2], hat[z]]^2 + 
          dot[hat[k1], hat[z]]^2*(-14 + 475*dot[hat[k2], hat[z]]^2)) + 
        21*f1^3*(dot[hat[k1], hat[z]]^4*(7 + 32*dot[hat[k2], hat[z]]^2) - 
          dot[hat[k1], hat[z]]^2*(dot[hat[k2], hat[z]]^2 + 
            12*dot[hat[k2], hat[z]]^4)))*magM[k2]^2 - 
      (300 + 14*f1^3*dot[hat[k1], hat[z]]^2*
         (49 + 45*dot[hat[k2], hat[z]]^2) + 
        f1*(-133 + 2014*dot[hat[k1], hat[z]]^2 + 54*dot[hat[k2], hat[z]]^2) + 
        4*f1^2*(-42*dot[hat[k2], hat[z]]^2 + dot[hat[k1], hat[z]]^2*
           (581 + 195*dot[hat[k2], hat[z]]^2)))*magM[k3]^2) + 
    2*(5 + 3*f1*dot[hat[k1], hat[z]]^2)*(magM[k2]^2 - magM[k3]^2)^2*
     (f1*dot[hat[k2], hat[z]]^2*(9 + 18*f1*dot[hat[k2], hat[z]]^2 + 
        7*f1^2*dot[hat[k2], hat[z]]^2)*magM[k2]^4 + 
      (15 + 60*f1*dot[hat[k2], hat[z]]^2 + 7*f1^3*dot[hat[k2], hat[z]]^4 + 
        2*f1^2*dot[hat[k2], hat[z]]^2*(28 + 9*dot[hat[k2], hat[z]]^2))*
       magM[k2]^2*magM[k3]^2 + 3*(5 + 3*f1*dot[hat[k2], hat[z]]^2)*
       magM[k3]^4) + magM[k1]^4*
     (2*f1*(-168*f1^3*dot[hat[k1], hat[z]]^6*dot[hat[k2], hat[z]]^2 + 
        5*dot[hat[k2], hat[z]]^2*(-9 - 18*f1*dot[hat[k2], hat[z]]^2 + 
          7*f1^2*dot[hat[k2], hat[z]]^2) + f1*dot[hat[k1], hat[z]]^4*
         (-90 + 3528*f1^3*dot[hat[k2], hat[z]]^4 + 
          63*f1^2*dot[hat[k2], hat[z]]^2*(9 + 32*dot[hat[k2], hat[z]]^2) - 
          5*f1*(-7 + 218*dot[hat[k2], hat[z]]^2)) + dot[hat[k1], hat[z]]^2*
         (-45 + 450*f1*dot[hat[k2], hat[z]]^2 - 21*f1^3*dot[hat[k2], hat[z]]^
            4*(-27 + 8*dot[hat[k2], hat[z]]^2) + 
          f1^2*(252*dot[hat[k2], hat[z]]^2 - 1090*dot[hat[k2], hat[z]]^4)))*
       magM[k2]^4 + (-150 + 1715*f1^6*dot[hat[k1], hat[z]]^4*
         dot[hat[k2], hat[z]]^2 + 294*f1^5*dot[hat[k1], hat[z]]^4*
         dot[hat[k2], hat[z]]^2*(17 + 4*dot[hat[k1], hat[z]]^2 + 
          4*dot[hat[k2], hat[z]]^2) - 100*f1*(5*dot[hat[k1], hat[z]]^2 + 
          6*dot[hat[k2], hat[z]]^2) - 2*f1^3*(154*dot[hat[k1], hat[z]]^6 - 
          35*dot[hat[k2], hat[z]]^4 + dot[hat[k1], hat[z]]^4*
           (602 - 2120*dot[hat[k2], hat[z]]^2) + 2*dot[hat[k1], hat[z]]^2*
           dot[hat[k2], hat[z]]^2*(1463 + 510*dot[hat[k2], hat[z]]^2)) - 
        f1^2*(1380*dot[hat[k1], hat[z]]^4 + 2*dot[hat[k2], hat[z]]^2*
           (-133 + 90*dot[hat[k2], hat[z]]^2) + dot[hat[k1], hat[z]]^2*
           (371 + 5408*dot[hat[k2], hat[z]]^2)) + 
        7*f1^4*dot[hat[k1], hat[z]]^2*(96*dot[hat[k1], hat[z]]^4*
           dot[hat[k2], hat[z]]^2 - 3*dot[hat[k2], hat[z]]^2*
           (91 + 86*dot[hat[k2], hat[z]]^2) + dot[hat[k1], hat[z]]^2*
           (-77 + 1248*dot[hat[k2], hat[z]]^2 + 96*dot[hat[k2], hat[z]]^4)))*
       magM[k2]^2*magM[k3]^2 - 2*(15 + 102*f1*dot[hat[k1], hat[z]]^2 + 
        7*f1^3*dot[hat[k1], hat[z]]^4 + 2*f1^2*dot[hat[k1], hat[z]]^2*
         (56 + 9*dot[hat[k1], hat[z]]^2))*(5 + 3*f1*dot[hat[k2], hat[z]]^2)*
       magM[k3]^4) - 2*f1*dot[hat[k1], hat[z]]*dot[hat[k2], hat[z]]*magM[k1]*
     magM[k2]*(magM[k2]^2 - magM[k3]^2)*
     (2*(-45 - 27*f1*(dot[hat[k1], hat[z]]^2 + dot[hat[k2], hat[z]]^2) + 
        2*f1^2*dot[hat[k2], hat[z]]^2*(7 - 27*dot[hat[k1], hat[z]]^2 + 
          133*dot[hat[k2], hat[z]]^2) + 21*f1^3*(7*dot[hat[k2], hat[z]]^4 + 
          dot[hat[k1], hat[z]]^2*dot[hat[k2], hat[z]]^2*
           (-1 + 4*dot[hat[k2], hat[z]]^2)))*magM[k2]^4 + 
      7*(30 + f1*(-19 + 280*dot[hat[k2], hat[z]]^2) + 
        2*f1^3*dot[hat[k2], hat[z]]^2*(6*dot[hat[k1], hat[z]]^2*
           (7 + 2*dot[hat[k2], hat[z]]^2) + 
          7*(7 + 3*dot[hat[k2], hat[z]]^2)) + 
        4*f1^2*(6*dot[hat[k1], hat[z]]^2*(-1 + 4*dot[hat[k2], hat[z]]^2) + 
          dot[hat[k2], hat[z]]^2*(84 + 19*dot[hat[k2], hat[z]]^2)))*
       magM[k2]^2*magM[k3]^2 + (720 + 42*f1^3*dot[hat[k1], hat[z]]^2*
         dot[hat[k2], hat[z]]^2 + f1*(427 + 306*dot[hat[k1], hat[z]]^2 + 
          306*dot[hat[k2], hat[z]]^2) + 12*f1^2*(14*dot[hat[k2], hat[z]]^2 + 
          dot[hat[k1], hat[z]]^2*(14 + 9*dot[hat[k2], hat[z]]^2)))*
       magM[k3]^4) + 2*f1*dot[hat[k1], hat[z]]*dot[hat[k2], hat[z]]*
     magM[k1]^3*magM[k2]*(2*(-45 + 1176*f1^4*dot[hat[k1], hat[z]]^2*
         dot[hat[k2], hat[z]]^4 + f1*(-153*dot[hat[k1], hat[z]]^2 + 
          99*dot[hat[k2], hat[z]]^2) - 21*f1^3*dot[hat[k2], hat[z]]^2*
         (12*dot[hat[k1], hat[z]]^4 - 7*dot[hat[k2], hat[z]]^2 + 
          dot[hat[k1], hat[z]]^2*(1 - 32*dot[hat[k2], hat[z]]^2)) - 
        2*f1^2*(7*dot[hat[k2], hat[z]]^2*(-2 + 17*dot[hat[k2], hat[z]]^2) + 
          dot[hat[k1], hat[z]]^2*(7 + 475*dot[hat[k2], hat[z]]^2)))*
       magM[k2]^4 + (10 + 1715*f1^5*dot[hat[k1], hat[z]]^2*
         dot[hat[k2], hat[z]]^2 + 294*f1^4*dot[hat[k1], hat[z]]^2*
         dot[hat[k2], hat[z]]^2*(17 + 4*dot[hat[k1], hat[z]]^2 + 
          4*dot[hat[k2], hat[z]]^2) - 
        3*f1*(-63 + 460*dot[hat[k1], hat[z]]^2 + 460*dot[hat[k2], hat[z]]^
            2) - 4*f1^2*(112*dot[hat[k1], hat[z]]^4 + dot[hat[k1], hat[z]]^2*
           (301 - 1060*dot[hat[k2], hat[z]]^2) + 7*dot[hat[k2], hat[z]]^2*
           (43 + 16*dot[hat[k2], hat[z]]^2)) + 
        7*f1^3*(-7*dot[hat[k2], hat[z]]^2*(11 + 6*dot[hat[k2], hat[z]]^2) + 
          6*dot[hat[k1], hat[z]]^4*(-7 + 16*dot[hat[k2], hat[z]]^2) + 
          dot[hat[k1], hat[z]]^2*(-77 + 1248*dot[hat[k2], hat[z]]^2 + 
            96*dot[hat[k2], hat[z]]^4)))*magM[k2]^2*magM[k3]^2 + 
      2*(-255 + f1*(-280 + 827*dot[hat[k1], hat[z]]^2 - 
          153*dot[hat[k2], hat[z]]^2) + 7*f1^3*dot[hat[k1], hat[z]]^2*
         (49 + 39*dot[hat[k2], hat[z]]^2 + 3*dot[hat[k1], hat[z]]^2*
           (7 + 4*dot[hat[k2], hat[z]]^2)) + 
        2*f1^2*(133*dot[hat[k1], hat[z]]^4 - 84*dot[hat[k2], hat[z]]^2 + 
          3*dot[hat[k1], hat[z]]^2*(182 + 47*dot[hat[k2], hat[z]]^2)))*
       magM[k3]^4) + magM[k1]^2*
     (2*f1*(-(dot[hat[k2], hat[z]]^2*(45 + 27*f1*dot[hat[k2], hat[z]]^2 + 
           14*f1^2*dot[hat[k2], hat[z]]^2*(5 + 11*dot[hat[k2], hat[z]]^2))) + 
        dot[hat[k1], hat[z]]^2*(45 - 252*f1*dot[hat[k2], hat[z]]^2 + 
          588*f1^4*dot[hat[k2], hat[z]]^6 + 21*f1^3*dot[hat[k2], hat[z]]^4*
           (-29 + 16*dot[hat[k2], hat[z]]^2) - 2*f1^2*dot[hat[k2], hat[z]]^2*
           (63 + 832*dot[hat[k2], hat[z]]^2)) + 3*f1*dot[hat[k1], hat[z]]^4*
         (9 + 18*f1*dot[hat[k2], hat[z]]^2 + f1^2*(7*dot[hat[k2], hat[z]]^2 - 
            168*dot[hat[k2], hat[z]]^4)))*magM[k2]^6 + 
      (-150 + 1715*f1^6*dot[hat[k1], hat[z]]^2*dot[hat[k2], hat[z]]^4 + 
        294*f1^5*dot[hat[k1], hat[z]]^2*dot[hat[k2], hat[z]]^4*
         (17 + 4*dot[hat[k1], hat[z]]^2 + 4*dot[hat[k2], hat[z]]^2) - 
        100*f1*(6*dot[hat[k1], hat[z]]^2 + 5*dot[hat[k2], hat[z]]^2) - 
        f1^2*(180*dot[hat[k1], hat[z]]^4 + dot[hat[k2], hat[z]]^2*
           (371 + 1380*dot[hat[k2], hat[z]]^2) + dot[hat[k1], hat[z]]^2*
           (-266 + 5408*dot[hat[k2], hat[z]]^2)) - 
        2*f1^3*(14*dot[hat[k2], hat[z]]^4*(43 + 11*dot[hat[k2], hat[z]]^2) + 
          5*dot[hat[k1], hat[z]]^4*(-7 + 204*dot[hat[k2], hat[z]]^2) + 
          dot[hat[k1], hat[z]]^2*(2926*dot[hat[k2], hat[z]]^2 - 
            2120*dot[hat[k2], hat[z]]^4)) + 7*f1^4*dot[hat[k2], hat[z]]^2*
         (-77*dot[hat[k2], hat[z]]^2 + 6*dot[hat[k1], hat[z]]^4*
           (-43 + 16*dot[hat[k2], hat[z]]^2) + 3*dot[hat[k1], hat[z]]^2*
           (-91 + 416*dot[hat[k2], hat[z]]^2 + 32*dot[hat[k2], hat[z]]^4)))*
       magM[k2]^4*magM[k3]^2 + 
      (5 - 500*f1*(dot[hat[k1], hat[z]]^2 + dot[hat[k2], hat[z]]^2) + 
        21*f1^4*dot[hat[k1], hat[z]]^2*dot[hat[k2], hat[z]]^2*
         (105 + 82*dot[hat[k2], hat[z]]^2 + dot[hat[k1], hat[z]]^2*
           (82 + 32*dot[hat[k2], hat[z]]^2)) - 
        f1^2*(54*dot[hat[k1], hat[z]]^4 + dot[hat[k1], hat[z]]^2*
           (371 - 5596*dot[hat[k2], hat[z]]^2) + dot[hat[k2], hat[z]]^2*
           (371 + 54*dot[hat[k2], hat[z]]^2)) + 
        4*f1^3*(-35*dot[hat[k2], hat[z]]^4 + 2*dot[hat[k1], hat[z]]^2*
           dot[hat[k2], hat[z]]^2*(959 + 249*dot[hat[k2], hat[z]]^2) + 
          dot[hat[k1], hat[z]]^4*(-35 + 498*dot[hat[k2], hat[z]]^2)))*
       magM[k2]^2*magM[k3]^4 + 2*(-15 + 42*f1*dot[hat[k1], hat[z]]^2 + 
        7*f1^3*dot[hat[k1], hat[z]]^4 + 2*f1^2*dot[hat[k1], hat[z]]^2*
         (28 + 9*dot[hat[k1], hat[z]]^2))*(5 + 3*f1*dot[hat[k2], hat[z]]^2)*
       magM[k3]^6)))/(Pi^2*magM[k3]^2)
