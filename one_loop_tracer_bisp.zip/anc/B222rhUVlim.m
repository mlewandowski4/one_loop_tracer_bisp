(* Created with the Wolfram Language : www.wolfram.com *)
(-4*(b1 - b2 - b5)^3*Intdqq2P113)/Pi^2 + (8*b1^3*IntdqP113*magM[k1]^2)/
  (9*Pi^2) - (176*b1^2*b2*IntdqP113*magM[k1]^2)/(63*Pi^2) + 
 (184*b1*b2^2*IntdqP113*magM[k1]^2)/(63*Pi^2) - 
 (64*b2^3*IntdqP113*magM[k1]^2)/(63*Pi^2) - (16*b1^2*b5*IntdqP113*magM[k1]^2)/
  (9*Pi^2) + (80*b1*b2*b5*IntdqP113*magM[k1]^2)/(21*Pi^2) - 
 (128*b2^2*b5*IntdqP113*magM[k1]^2)/(63*Pi^2) + 
 (8*b1*b5^2*IntdqP113*magM[k1]^2)/(9*Pi^2) - 
 (64*b2*b5^2*IntdqP113*magM[k1]^2)/(63*Pi^2) - 
 (4*b1^3*Intdqq2P112P11pp*magM[k1]^2)/(9*Pi^2) + 
 (4*b1^2*b2*Intdqq2P112P11pp*magM[k1]^2)/(3*Pi^2) - 
 (4*b1*b2^2*Intdqq2P112P11pp*magM[k1]^2)/(3*Pi^2) + 
 (4*b2^3*Intdqq2P112P11pp*magM[k1]^2)/(9*Pi^2) + 
 (4*b1^2*b5*Intdqq2P112P11pp*magM[k1]^2)/(3*Pi^2) - 
 (8*b1*b2*b5*Intdqq2P112P11pp*magM[k1]^2)/(3*Pi^2) + 
 (4*b2^2*b5*Intdqq2P112P11pp*magM[k1]^2)/(3*Pi^2) - 
 (4*b1*b5^2*Intdqq2P112P11pp*magM[k1]^2)/(3*Pi^2) + 
 (4*b2*b5^2*Intdqq2P112P11pp*magM[k1]^2)/(3*Pi^2) + 
 (4*b5^3*Intdqq2P112P11pp*magM[k1]^2)/(9*Pi^2) - 
 (8*b1^3*IntdqqP112P11p*magM[k1]^2)/(9*Pi^2) + 
 (8*b1^2*b2*IntdqqP112P11p*magM[k1]^2)/(3*Pi^2) - 
 (8*b1*b2^2*IntdqqP112P11p*magM[k1]^2)/(3*Pi^2) + 
 (8*b2^3*IntdqqP112P11p*magM[k1]^2)/(9*Pi^2) + 
 (8*b1^2*b5*IntdqqP112P11p*magM[k1]^2)/(3*Pi^2) - 
 (16*b1*b2*b5*IntdqqP112P11p*magM[k1]^2)/(3*Pi^2) + 
 (8*b2^2*b5*IntdqqP112P11p*magM[k1]^2)/(3*Pi^2) - 
 (8*b1*b5^2*IntdqqP112P11p*magM[k1]^2)/(3*Pi^2) + 
 (8*b2*b5^2*IntdqqP112P11p*magM[k1]^2)/(3*Pi^2) + 
 (8*b5^3*IntdqqP112P11p*magM[k1]^2)/(9*Pi^2) - 
 (8*b1^2*f1*IntdqP113*dot[hat[k1], hat[z]]^2*magM[k1]^2)/(7*Pi^2) + 
 (8*b1^3*f1*IntdqP113*dot[hat[k1], hat[z]]^2*magM[k1]^2)/(9*Pi^2) + 
 (16*b1*b2*f1*IntdqP113*dot[hat[k1], hat[z]]^2*magM[k1]^2)/(7*Pi^2) - 
 (16*b1^2*b2*f1*IntdqP113*dot[hat[k1], hat[z]]^2*magM[k1]^2)/(9*Pi^2) - 
 (8*b2^2*f1*IntdqP113*dot[hat[k1], hat[z]]^2*magM[k1]^2)/(7*Pi^2) + 
 (8*b1*b2^2*f1*IntdqP113*dot[hat[k1], hat[z]]^2*magM[k1]^2)/(9*Pi^2) + 
 (16*b1*b5*f1*IntdqP113*dot[hat[k1], hat[z]]^2*magM[k1]^2)/(7*Pi^2) - 
 (16*b1^2*b5*f1*IntdqP113*dot[hat[k1], hat[z]]^2*magM[k1]^2)/(9*Pi^2) - 
 (16*b2*b5*f1*IntdqP113*dot[hat[k1], hat[z]]^2*magM[k1]^2)/(7*Pi^2) + 
 (16*b1*b2*b5*f1*IntdqP113*dot[hat[k1], hat[z]]^2*magM[k1]^2)/(9*Pi^2) - 
 (8*b5^2*f1*IntdqP113*dot[hat[k1], hat[z]]^2*magM[k1]^2)/(7*Pi^2) + 
 (8*b1*b5^2*f1*IntdqP113*dot[hat[k1], hat[z]]^2*magM[k1]^2)/(9*Pi^2) - 
 (8*b1^2*f1^2*IntdqP113*dot[hat[k1], hat[z]]^2*magM[k1]^2)/(9*Pi^2) + 
 (16*b1*b2*f1^2*IntdqP113*dot[hat[k1], hat[z]]^2*magM[k1]^2)/(9*Pi^2) - 
 (8*b2^2*f1^2*IntdqP113*dot[hat[k1], hat[z]]^2*magM[k1]^2)/(9*Pi^2) + 
 (16*b1*b5*f1^2*IntdqP113*dot[hat[k1], hat[z]]^2*magM[k1]^2)/(9*Pi^2) - 
 (16*b2*b5*f1^2*IntdqP113*dot[hat[k1], hat[z]]^2*magM[k1]^2)/(9*Pi^2) - 
 (8*b5^2*f1^2*IntdqP113*dot[hat[k1], hat[z]]^2*magM[k1]^2)/(9*Pi^2) - 
 (4*b1^2*f1*IntdqP113*dot[hat[k1], hat[z]]*dot[hat[k2], hat[z]]*magM[k1]*
   magM[k2])/(7*Pi^2) + (4*b1^3*f1*IntdqP113*dot[hat[k1], hat[z]]*
   dot[hat[k2], hat[z]]*magM[k1]*magM[k2])/(9*Pi^2) + 
 (8*b1*b2*f1*IntdqP113*dot[hat[k1], hat[z]]*dot[hat[k2], hat[z]]*magM[k1]*
   magM[k2])/(7*Pi^2) - (8*b1^2*b2*f1*IntdqP113*dot[hat[k1], hat[z]]*
   dot[hat[k2], hat[z]]*magM[k1]*magM[k2])/(9*Pi^2) - 
 (4*b2^2*f1*IntdqP113*dot[hat[k1], hat[z]]*dot[hat[k2], hat[z]]*magM[k1]*
   magM[k2])/(7*Pi^2) + (4*b1*b2^2*f1*IntdqP113*dot[hat[k1], hat[z]]*
   dot[hat[k2], hat[z]]*magM[k1]*magM[k2])/(9*Pi^2) + 
 (8*b1*b5*f1*IntdqP113*dot[hat[k1], hat[z]]*dot[hat[k2], hat[z]]*magM[k1]*
   magM[k2])/(7*Pi^2) - (8*b1^2*b5*f1*IntdqP113*dot[hat[k1], hat[z]]*
   dot[hat[k2], hat[z]]*magM[k1]*magM[k2])/(9*Pi^2) - 
 (8*b2*b5*f1*IntdqP113*dot[hat[k1], hat[z]]*dot[hat[k2], hat[z]]*magM[k1]*
   magM[k2])/(7*Pi^2) + (8*b1*b2*b5*f1*IntdqP113*dot[hat[k1], hat[z]]*
   dot[hat[k2], hat[z]]*magM[k1]*magM[k2])/(9*Pi^2) - 
 (4*b5^2*f1*IntdqP113*dot[hat[k1], hat[z]]*dot[hat[k2], hat[z]]*magM[k1]*
   magM[k2])/(7*Pi^2) + (4*b1*b5^2*f1*IntdqP113*dot[hat[k1], hat[z]]*
   dot[hat[k2], hat[z]]*magM[k1]*magM[k2])/(9*Pi^2) - 
 (4*b1^2*f1^2*IntdqP113*dot[hat[k1], hat[z]]*dot[hat[k2], hat[z]]*magM[k1]*
   magM[k2])/(9*Pi^2) + (8*b1*b2*f1^2*IntdqP113*dot[hat[k1], hat[z]]*
   dot[hat[k2], hat[z]]*magM[k1]*magM[k2])/(9*Pi^2) - 
 (4*b2^2*f1^2*IntdqP113*dot[hat[k1], hat[z]]*dot[hat[k2], hat[z]]*magM[k1]*
   magM[k2])/(9*Pi^2) + (8*b1*b5*f1^2*IntdqP113*dot[hat[k1], hat[z]]*
   dot[hat[k2], hat[z]]*magM[k1]*magM[k2])/(9*Pi^2) - 
 (8*b2*b5*f1^2*IntdqP113*dot[hat[k1], hat[z]]*dot[hat[k2], hat[z]]*magM[k1]*
   magM[k2])/(9*Pi^2) - (4*b5^2*f1^2*IntdqP113*dot[hat[k1], hat[z]]*
   dot[hat[k2], hat[z]]*magM[k1]*magM[k2])/(9*Pi^2) + 
 (8*b1^3*IntdqP113*magM[k2]^2)/(9*Pi^2) - (176*b1^2*b2*IntdqP113*magM[k2]^2)/
  (63*Pi^2) + (184*b1*b2^2*IntdqP113*magM[k2]^2)/(63*Pi^2) - 
 (64*b2^3*IntdqP113*magM[k2]^2)/(63*Pi^2) - (16*b1^2*b5*IntdqP113*magM[k2]^2)/
  (9*Pi^2) + (80*b1*b2*b5*IntdqP113*magM[k2]^2)/(21*Pi^2) - 
 (128*b2^2*b5*IntdqP113*magM[k2]^2)/(63*Pi^2) + 
 (8*b1*b5^2*IntdqP113*magM[k2]^2)/(9*Pi^2) - 
 (64*b2*b5^2*IntdqP113*magM[k2]^2)/(63*Pi^2) - 
 (4*b1^3*Intdqq2P112P11pp*magM[k2]^2)/(9*Pi^2) + 
 (4*b1^2*b2*Intdqq2P112P11pp*magM[k2]^2)/(3*Pi^2) - 
 (4*b1*b2^2*Intdqq2P112P11pp*magM[k2]^2)/(3*Pi^2) + 
 (4*b2^3*Intdqq2P112P11pp*magM[k2]^2)/(9*Pi^2) + 
 (4*b1^2*b5*Intdqq2P112P11pp*magM[k2]^2)/(3*Pi^2) - 
 (8*b1*b2*b5*Intdqq2P112P11pp*magM[k2]^2)/(3*Pi^2) + 
 (4*b2^2*b5*Intdqq2P112P11pp*magM[k2]^2)/(3*Pi^2) - 
 (4*b1*b5^2*Intdqq2P112P11pp*magM[k2]^2)/(3*Pi^2) + 
 (4*b2*b5^2*Intdqq2P112P11pp*magM[k2]^2)/(3*Pi^2) + 
 (4*b5^3*Intdqq2P112P11pp*magM[k2]^2)/(9*Pi^2) - 
 (8*b1^3*IntdqqP112P11p*magM[k2]^2)/(9*Pi^2) + 
 (8*b1^2*b2*IntdqqP112P11p*magM[k2]^2)/(3*Pi^2) - 
 (8*b1*b2^2*IntdqqP112P11p*magM[k2]^2)/(3*Pi^2) + 
 (8*b2^3*IntdqqP112P11p*magM[k2]^2)/(9*Pi^2) + 
 (8*b1^2*b5*IntdqqP112P11p*magM[k2]^2)/(3*Pi^2) - 
 (16*b1*b2*b5*IntdqqP112P11p*magM[k2]^2)/(3*Pi^2) + 
 (8*b2^2*b5*IntdqqP112P11p*magM[k2]^2)/(3*Pi^2) - 
 (8*b1*b5^2*IntdqqP112P11p*magM[k2]^2)/(3*Pi^2) + 
 (8*b2*b5^2*IntdqqP112P11p*magM[k2]^2)/(3*Pi^2) + 
 (8*b5^3*IntdqqP112P11p*magM[k2]^2)/(9*Pi^2) - 
 (8*b1^2*f1*IntdqP113*dot[hat[k2], hat[z]]^2*magM[k2]^2)/(7*Pi^2) + 
 (8*b1^3*f1*IntdqP113*dot[hat[k2], hat[z]]^2*magM[k2]^2)/(9*Pi^2) + 
 (16*b1*b2*f1*IntdqP113*dot[hat[k2], hat[z]]^2*magM[k2]^2)/(7*Pi^2) - 
 (16*b1^2*b2*f1*IntdqP113*dot[hat[k2], hat[z]]^2*magM[k2]^2)/(9*Pi^2) - 
 (8*b2^2*f1*IntdqP113*dot[hat[k2], hat[z]]^2*magM[k2]^2)/(7*Pi^2) + 
 (8*b1*b2^2*f1*IntdqP113*dot[hat[k2], hat[z]]^2*magM[k2]^2)/(9*Pi^2) + 
 (16*b1*b5*f1*IntdqP113*dot[hat[k2], hat[z]]^2*magM[k2]^2)/(7*Pi^2) - 
 (16*b1^2*b5*f1*IntdqP113*dot[hat[k2], hat[z]]^2*magM[k2]^2)/(9*Pi^2) - 
 (16*b2*b5*f1*IntdqP113*dot[hat[k2], hat[z]]^2*magM[k2]^2)/(7*Pi^2) + 
 (16*b1*b2*b5*f1*IntdqP113*dot[hat[k2], hat[z]]^2*magM[k2]^2)/(9*Pi^2) - 
 (8*b5^2*f1*IntdqP113*dot[hat[k2], hat[z]]^2*magM[k2]^2)/(7*Pi^2) + 
 (8*b1*b5^2*f1*IntdqP113*dot[hat[k2], hat[z]]^2*magM[k2]^2)/(9*Pi^2) - 
 (8*b1^2*f1^2*IntdqP113*dot[hat[k2], hat[z]]^2*magM[k2]^2)/(9*Pi^2) + 
 (16*b1*b2*f1^2*IntdqP113*dot[hat[k2], hat[z]]^2*magM[k2]^2)/(9*Pi^2) - 
 (8*b2^2*f1^2*IntdqP113*dot[hat[k2], hat[z]]^2*magM[k2]^2)/(9*Pi^2) + 
 (16*b1*b5*f1^2*IntdqP113*dot[hat[k2], hat[z]]^2*magM[k2]^2)/(9*Pi^2) - 
 (16*b2*b5*f1^2*IntdqP113*dot[hat[k2], hat[z]]^2*magM[k2]^2)/(9*Pi^2) - 
 (8*b5^2*f1^2*IntdqP113*dot[hat[k2], hat[z]]^2*magM[k2]^2)/(9*Pi^2) + 
 (4*b1^2*f1*IntdqP113*dot[hat[k1], hat[z]]*magM[k1]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (7*Pi^2) - (4*b1^3*f1*IntdqP113*dot[hat[k1], hat[z]]*magM[k1]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (9*Pi^2) - (8*b1*b2*f1*IntdqP113*dot[hat[k1], hat[z]]*magM[k1]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (7*Pi^2) + (8*b1^2*b2*f1*IntdqP113*dot[hat[k1], hat[z]]*magM[k1]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (9*Pi^2) + (4*b2^2*f1*IntdqP113*dot[hat[k1], hat[z]]*magM[k1]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (7*Pi^2) - (4*b1*b2^2*f1*IntdqP113*dot[hat[k1], hat[z]]*magM[k1]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (9*Pi^2) - (8*b1*b5*f1*IntdqP113*dot[hat[k1], hat[z]]*magM[k1]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (7*Pi^2) + (8*b1^2*b5*f1*IntdqP113*dot[hat[k1], hat[z]]*magM[k1]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (9*Pi^2) + (8*b2*b5*f1*IntdqP113*dot[hat[k1], hat[z]]*magM[k1]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (7*Pi^2) - (8*b1*b2*b5*f1*IntdqP113*dot[hat[k1], hat[z]]*magM[k1]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (9*Pi^2) + (4*b5^2*f1*IntdqP113*dot[hat[k1], hat[z]]*magM[k1]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (7*Pi^2) - (4*b1*b5^2*f1*IntdqP113*dot[hat[k1], hat[z]]*magM[k1]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (9*Pi^2) + (4*b1^2*f1^2*IntdqP113*dot[hat[k1], hat[z]]*magM[k1]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (9*Pi^2) - (8*b1*b2*f1^2*IntdqP113*dot[hat[k1], hat[z]]*magM[k1]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (9*Pi^2) + (4*b2^2*f1^2*IntdqP113*dot[hat[k1], hat[z]]*magM[k1]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (9*Pi^2) - (8*b1*b5*f1^2*IntdqP113*dot[hat[k1], hat[z]]*magM[k1]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (9*Pi^2) + (8*b2*b5*f1^2*IntdqP113*dot[hat[k1], hat[z]]*magM[k1]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (9*Pi^2) + (4*b5^2*f1^2*IntdqP113*dot[hat[k1], hat[z]]*magM[k1]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (9*Pi^2) + (4*b1^2*f1*IntdqP113*dot[hat[k2], hat[z]]*magM[k2]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (7*Pi^2) - (4*b1^3*f1*IntdqP113*dot[hat[k2], hat[z]]*magM[k2]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (9*Pi^2) - (8*b1*b2*f1*IntdqP113*dot[hat[k2], hat[z]]*magM[k2]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (7*Pi^2) + (8*b1^2*b2*f1*IntdqP113*dot[hat[k2], hat[z]]*magM[k2]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (9*Pi^2) + (4*b2^2*f1*IntdqP113*dot[hat[k2], hat[z]]*magM[k2]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (7*Pi^2) - (4*b1*b2^2*f1*IntdqP113*dot[hat[k2], hat[z]]*magM[k2]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (9*Pi^2) - (8*b1*b5*f1*IntdqP113*dot[hat[k2], hat[z]]*magM[k2]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (7*Pi^2) + (8*b1^2*b5*f1*IntdqP113*dot[hat[k2], hat[z]]*magM[k2]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (9*Pi^2) + (8*b2*b5*f1*IntdqP113*dot[hat[k2], hat[z]]*magM[k2]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (7*Pi^2) - (8*b1*b2*b5*f1*IntdqP113*dot[hat[k2], hat[z]]*magM[k2]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (9*Pi^2) + (4*b5^2*f1*IntdqP113*dot[hat[k2], hat[z]]*magM[k2]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (7*Pi^2) - (4*b1*b5^2*f1*IntdqP113*dot[hat[k2], hat[z]]*magM[k2]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (9*Pi^2) + (4*b1^2*f1^2*IntdqP113*dot[hat[k2], hat[z]]*magM[k2]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (9*Pi^2) - (8*b1*b2*f1^2*IntdqP113*dot[hat[k2], hat[z]]*magM[k2]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (9*Pi^2) + (4*b2^2*f1^2*IntdqP113*dot[hat[k2], hat[z]]*magM[k2]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (9*Pi^2) - (8*b1*b5*f1^2*IntdqP113*dot[hat[k2], hat[z]]*magM[k2]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (9*Pi^2) + (8*b2*b5*f1^2*IntdqP113*dot[hat[k2], hat[z]]*magM[k2]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (9*Pi^2) + (4*b5^2*f1^2*IntdqP113*dot[hat[k2], hat[z]]*magM[k2]*
   (dot[hat[k1], hat[z]]*magM[k1] + dot[hat[k2], hat[z]]*magM[k2]))/
  (9*Pi^2) - (8*b1^2*f1*IntdqP113*(dot[hat[k1], hat[z]]*magM[k1] + 
     dot[hat[k2], hat[z]]*magM[k2])^2)/(7*Pi^2) + 
 (8*b1^3*f1*IntdqP113*(dot[hat[k1], hat[z]]*magM[k1] + 
     dot[hat[k2], hat[z]]*magM[k2])^2)/(9*Pi^2) + 
 (16*b1*b2*f1*IntdqP113*(dot[hat[k1], hat[z]]*magM[k1] + 
     dot[hat[k2], hat[z]]*magM[k2])^2)/(7*Pi^2) - 
 (16*b1^2*b2*f1*IntdqP113*(dot[hat[k1], hat[z]]*magM[k1] + 
     dot[hat[k2], hat[z]]*magM[k2])^2)/(9*Pi^2) - 
 (8*b2^2*f1*IntdqP113*(dot[hat[k1], hat[z]]*magM[k1] + 
     dot[hat[k2], hat[z]]*magM[k2])^2)/(7*Pi^2) + 
 (8*b1*b2^2*f1*IntdqP113*(dot[hat[k1], hat[z]]*magM[k1] + 
     dot[hat[k2], hat[z]]*magM[k2])^2)/(9*Pi^2) + 
 (16*b1*b5*f1*IntdqP113*(dot[hat[k1], hat[z]]*magM[k1] + 
     dot[hat[k2], hat[z]]*magM[k2])^2)/(7*Pi^2) - 
 (16*b1^2*b5*f1*IntdqP113*(dot[hat[k1], hat[z]]*magM[k1] + 
     dot[hat[k2], hat[z]]*magM[k2])^2)/(9*Pi^2) - 
 (16*b2*b5*f1*IntdqP113*(dot[hat[k1], hat[z]]*magM[k1] + 
     dot[hat[k2], hat[z]]*magM[k2])^2)/(7*Pi^2) + 
 (16*b1*b2*b5*f1*IntdqP113*(dot[hat[k1], hat[z]]*magM[k1] + 
     dot[hat[k2], hat[z]]*magM[k2])^2)/(9*Pi^2) - 
 (8*b5^2*f1*IntdqP113*(dot[hat[k1], hat[z]]*magM[k1] + 
     dot[hat[k2], hat[z]]*magM[k2])^2)/(7*Pi^2) + 
 (8*b1*b5^2*f1*IntdqP113*(dot[hat[k1], hat[z]]*magM[k1] + 
     dot[hat[k2], hat[z]]*magM[k2])^2)/(9*Pi^2) - 
 (8*b1^2*f1^2*IntdqP113*(dot[hat[k1], hat[z]]*magM[k1] + 
     dot[hat[k2], hat[z]]*magM[k2])^2)/(9*Pi^2) + 
 (16*b1*b2*f1^2*IntdqP113*(dot[hat[k1], hat[z]]*magM[k1] + 
     dot[hat[k2], hat[z]]*magM[k2])^2)/(9*Pi^2) - 
 (8*b2^2*f1^2*IntdqP113*(dot[hat[k1], hat[z]]*magM[k1] + 
     dot[hat[k2], hat[z]]*magM[k2])^2)/(9*Pi^2) + 
 (16*b1*b5*f1^2*IntdqP113*(dot[hat[k1], hat[z]]*magM[k1] + 
     dot[hat[k2], hat[z]]*magM[k2])^2)/(9*Pi^2) - 
 (16*b2*b5*f1^2*IntdqP113*(dot[hat[k1], hat[z]]*magM[k1] + 
     dot[hat[k2], hat[z]]*magM[k2])^2)/(9*Pi^2) - 
 (8*b5^2*f1^2*IntdqP113*(dot[hat[k1], hat[z]]*magM[k1] + 
     dot[hat[k2], hat[z]]*magM[k2])^2)/(9*Pi^2) + 
 (8*b1^3*IntdqP113*magM[k3]^2)/(9*Pi^2) - (176*b1^2*b2*IntdqP113*magM[k3]^2)/
  (63*Pi^2) + (184*b1*b2^2*IntdqP113*magM[k3]^2)/(63*Pi^2) - 
 (64*b2^3*IntdqP113*magM[k3]^2)/(63*Pi^2) - (16*b1^2*b5*IntdqP113*magM[k3]^2)/
  (9*Pi^2) + (80*b1*b2*b5*IntdqP113*magM[k3]^2)/(21*Pi^2) - 
 (128*b2^2*b5*IntdqP113*magM[k3]^2)/(63*Pi^2) + 
 (8*b1*b5^2*IntdqP113*magM[k3]^2)/(9*Pi^2) - 
 (64*b2*b5^2*IntdqP113*magM[k3]^2)/(63*Pi^2) - 
 (4*b1^3*Intdqq2P112P11pp*magM[k3]^2)/(9*Pi^2) + 
 (4*b1^2*b2*Intdqq2P112P11pp*magM[k3]^2)/(3*Pi^2) - 
 (4*b1*b2^2*Intdqq2P112P11pp*magM[k3]^2)/(3*Pi^2) + 
 (4*b2^3*Intdqq2P112P11pp*magM[k3]^2)/(9*Pi^2) + 
 (4*b1^2*b5*Intdqq2P112P11pp*magM[k3]^2)/(3*Pi^2) - 
 (8*b1*b2*b5*Intdqq2P112P11pp*magM[k3]^2)/(3*Pi^2) + 
 (4*b2^2*b5*Intdqq2P112P11pp*magM[k3]^2)/(3*Pi^2) - 
 (4*b1*b5^2*Intdqq2P112P11pp*magM[k3]^2)/(3*Pi^2) + 
 (4*b2*b5^2*Intdqq2P112P11pp*magM[k3]^2)/(3*Pi^2) + 
 (4*b5^3*Intdqq2P112P11pp*magM[k3]^2)/(9*Pi^2) - 
 (8*b1^3*IntdqqP112P11p*magM[k3]^2)/(9*Pi^2) + 
 (8*b1^2*b2*IntdqqP112P11p*magM[k3]^2)/(3*Pi^2) - 
 (8*b1*b2^2*IntdqqP112P11p*magM[k3]^2)/(3*Pi^2) + 
 (8*b2^3*IntdqqP112P11p*magM[k3]^2)/(9*Pi^2) + 
 (8*b1^2*b5*IntdqqP112P11p*magM[k3]^2)/(3*Pi^2) - 
 (16*b1*b2*b5*IntdqqP112P11p*magM[k3]^2)/(3*Pi^2) + 
 (8*b2^2*b5*IntdqqP112P11p*magM[k3]^2)/(3*Pi^2) - 
 (8*b1*b5^2*IntdqqP112P11p*magM[k3]^2)/(3*Pi^2) + 
 (8*b2*b5^2*IntdqqP112P11p*magM[k3]^2)/(3*Pi^2) + 
 (8*b5^3*IntdqqP112P11p*magM[k3]^2)/(9*Pi^2) + 
 (2*b1^3*IntdqP113*(magM[k1]^2 - magM[k2]^2 - magM[k3]^2))/(9*Pi^2) - 
 (44*b1^2*b2*IntdqP113*(magM[k1]^2 - magM[k2]^2 - magM[k3]^2))/(63*Pi^2) + 
 (46*b1*b2^2*IntdqP113*(magM[k1]^2 - magM[k2]^2 - magM[k3]^2))/(63*Pi^2) - 
 (16*b2^3*IntdqP113*(magM[k1]^2 - magM[k2]^2 - magM[k3]^2))/(63*Pi^2) - 
 (4*b1^2*b5*IntdqP113*(magM[k1]^2 - magM[k2]^2 - magM[k3]^2))/(9*Pi^2) + 
 (20*b1*b2*b5*IntdqP113*(magM[k1]^2 - magM[k2]^2 - magM[k3]^2))/(21*Pi^2) - 
 (32*b2^2*b5*IntdqP113*(magM[k1]^2 - magM[k2]^2 - magM[k3]^2))/(63*Pi^2) + 
 (2*b1*b5^2*IntdqP113*(magM[k1]^2 - magM[k2]^2 - magM[k3]^2))/(9*Pi^2) - 
 (16*b2*b5^2*IntdqP113*(magM[k1]^2 - magM[k2]^2 - magM[k3]^2))/(63*Pi^2) + 
 (2*b1^3*Intdqq2P11P11p2*(magM[k1]^2 - magM[k2]^2 - magM[k3]^2))/(9*Pi^2) - 
 (2*b1^2*b2*Intdqq2P11P11p2*(magM[k1]^2 - magM[k2]^2 - magM[k3]^2))/
  (3*Pi^2) + (2*b1*b2^2*Intdqq2P11P11p2*(magM[k1]^2 - magM[k2]^2 - 
    magM[k3]^2))/(3*Pi^2) - 
 (2*b2^3*Intdqq2P11P11p2*(magM[k1]^2 - magM[k2]^2 - magM[k3]^2))/(9*Pi^2) - 
 (2*b1^2*b5*Intdqq2P11P11p2*(magM[k1]^2 - magM[k2]^2 - magM[k3]^2))/
  (3*Pi^2) + (4*b1*b2*b5*Intdqq2P11P11p2*(magM[k1]^2 - magM[k2]^2 - 
    magM[k3]^2))/(3*Pi^2) - (2*b2^2*b5*Intdqq2P11P11p2*
   (magM[k1]^2 - magM[k2]^2 - magM[k3]^2))/(3*Pi^2) + 
 (2*b1*b5^2*Intdqq2P11P11p2*(magM[k1]^2 - magM[k2]^2 - magM[k3]^2))/
  (3*Pi^2) - (2*b2*b5^2*Intdqq2P11P11p2*(magM[k1]^2 - magM[k2]^2 - 
    magM[k3]^2))/(3*Pi^2) - 
 (2*b5^3*Intdqq2P11P11p2*(magM[k1]^2 - magM[k2]^2 - magM[k3]^2))/(9*Pi^2) + 
 (2*b1^3*IntdqP113*(-magM[k1]^2 + magM[k2]^2 - magM[k3]^2))/(9*Pi^2) - 
 (44*b1^2*b2*IntdqP113*(-magM[k1]^2 + magM[k2]^2 - magM[k3]^2))/(63*Pi^2) + 
 (46*b1*b2^2*IntdqP113*(-magM[k1]^2 + magM[k2]^2 - magM[k3]^2))/(63*Pi^2) - 
 (16*b2^3*IntdqP113*(-magM[k1]^2 + magM[k2]^2 - magM[k3]^2))/(63*Pi^2) - 
 (4*b1^2*b5*IntdqP113*(-magM[k1]^2 + magM[k2]^2 - magM[k3]^2))/(9*Pi^2) + 
 (20*b1*b2*b5*IntdqP113*(-magM[k1]^2 + magM[k2]^2 - magM[k3]^2))/(21*Pi^2) - 
 (32*b2^2*b5*IntdqP113*(-magM[k1]^2 + magM[k2]^2 - magM[k3]^2))/(63*Pi^2) + 
 (2*b1*b5^2*IntdqP113*(-magM[k1]^2 + magM[k2]^2 - magM[k3]^2))/(9*Pi^2) - 
 (16*b2*b5^2*IntdqP113*(-magM[k1]^2 + magM[k2]^2 - magM[k3]^2))/(63*Pi^2) + 
 (2*b1^3*Intdqq2P11P11p2*(-magM[k1]^2 + magM[k2]^2 - magM[k3]^2))/(9*Pi^2) - 
 (2*b1^2*b2*Intdqq2P11P11p2*(-magM[k1]^2 + magM[k2]^2 - magM[k3]^2))/
  (3*Pi^2) + (2*b1*b2^2*Intdqq2P11P11p2*(-magM[k1]^2 + magM[k2]^2 - 
    magM[k3]^2))/(3*Pi^2) - 
 (2*b2^3*Intdqq2P11P11p2*(-magM[k1]^2 + magM[k2]^2 - magM[k3]^2))/(9*Pi^2) - 
 (2*b1^2*b5*Intdqq2P11P11p2*(-magM[k1]^2 + magM[k2]^2 - magM[k3]^2))/
  (3*Pi^2) + (4*b1*b2*b5*Intdqq2P11P11p2*(-magM[k1]^2 + magM[k2]^2 - 
    magM[k3]^2))/(3*Pi^2) - (2*b2^2*b5*Intdqq2P11P11p2*
   (-magM[k1]^2 + magM[k2]^2 - magM[k3]^2))/(3*Pi^2) + 
 (2*b1*b5^2*Intdqq2P11P11p2*(-magM[k1]^2 + magM[k2]^2 - magM[k3]^2))/
  (3*Pi^2) - (2*b2*b5^2*Intdqq2P11P11p2*(-magM[k1]^2 + magM[k2]^2 - 
    magM[k3]^2))/(3*Pi^2) - 
 (2*b5^3*Intdqq2P11P11p2*(-magM[k1]^2 + magM[k2]^2 - magM[k3]^2))/(9*Pi^2) + 
 (2*b1^3*IntdqP113*(-magM[k1]^2 - magM[k2]^2 + magM[k3]^2))/(9*Pi^2) - 
 (44*b1^2*b2*IntdqP113*(-magM[k1]^2 - magM[k2]^2 + magM[k3]^2))/(63*Pi^2) + 
 (46*b1*b2^2*IntdqP113*(-magM[k1]^2 - magM[k2]^2 + magM[k3]^2))/(63*Pi^2) - 
 (16*b2^3*IntdqP113*(-magM[k1]^2 - magM[k2]^2 + magM[k3]^2))/(63*Pi^2) - 
 (4*b1^2*b5*IntdqP113*(-magM[k1]^2 - magM[k2]^2 + magM[k3]^2))/(9*Pi^2) + 
 (20*b1*b2*b5*IntdqP113*(-magM[k1]^2 - magM[k2]^2 + magM[k3]^2))/(21*Pi^2) - 
 (32*b2^2*b5*IntdqP113*(-magM[k1]^2 - magM[k2]^2 + magM[k3]^2))/(63*Pi^2) + 
 (2*b1*b5^2*IntdqP113*(-magM[k1]^2 - magM[k2]^2 + magM[k3]^2))/(9*Pi^2) - 
 (16*b2*b5^2*IntdqP113*(-magM[k1]^2 - magM[k2]^2 + magM[k3]^2))/(63*Pi^2) + 
 (2*b1^3*Intdqq2P11P11p2*(-magM[k1]^2 - magM[k2]^2 + magM[k3]^2))/(9*Pi^2) - 
 (2*b1^2*b2*Intdqq2P11P11p2*(-magM[k1]^2 - magM[k2]^2 + magM[k3]^2))/
  (3*Pi^2) + (2*b1*b2^2*Intdqq2P11P11p2*(-magM[k1]^2 - magM[k2]^2 + 
    magM[k3]^2))/(3*Pi^2) - 
 (2*b2^3*Intdqq2P11P11p2*(-magM[k1]^2 - magM[k2]^2 + magM[k3]^2))/(9*Pi^2) - 
 (2*b1^2*b5*Intdqq2P11P11p2*(-magM[k1]^2 - magM[k2]^2 + magM[k3]^2))/
  (3*Pi^2) + (4*b1*b2*b5*Intdqq2P11P11p2*(-magM[k1]^2 - magM[k2]^2 + 
    magM[k3]^2))/(3*Pi^2) - (2*b2^2*b5*Intdqq2P11P11p2*
   (-magM[k1]^2 - magM[k2]^2 + magM[k3]^2))/(3*Pi^2) + 
 (2*b1*b5^2*Intdqq2P11P11p2*(-magM[k1]^2 - magM[k2]^2 + magM[k3]^2))/
  (3*Pi^2) - (2*b2*b5^2*Intdqq2P11P11p2*(-magM[k1]^2 - magM[k2]^2 + 
    magM[k3]^2))/(3*Pi^2) - 
 (2*b5^3*Intdqq2P11P11p2*(-magM[k1]^2 - magM[k2]^2 + magM[k3]^2))/(9*Pi^2)
