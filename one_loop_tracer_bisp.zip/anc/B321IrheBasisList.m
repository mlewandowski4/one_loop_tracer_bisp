(* Created with the Wolfram Language : www.wolfram.com *)
{-1 + (f1*dot[k1, hat[z]]^2)/magM[k1]^2, 
 -1/2*(-2*f1*dot[k1, hat[z]]^2*magM[k2]^2 + (magM[k2]^2 - magM[k3]^2)^2 + 
    2*f1*dot[k1, hat[z]]*dot[k2, hat[z]]*(-magM[k2]^2 + magM[k3]^2) + 
    magM[k1]^2*(magM[k2]^2 + magM[k3]^2))/(knl^2*magM[k1]^2), 
 (f1^2*dot[k1, hat[z]]*(-2*f1*dot[k1, hat[z]]^3 - 4*f1*dot[k1, hat[z]]^2*
     dot[k2, hat[z]] + 2*dot[k2, hat[z]]*(magM[k2]^2 - magM[k3]^2) + 
    dot[k1, hat[z]]*(-4*f1*dot[k2, hat[z]]^2 + magM[k1]^2 + magM[k2]^2 - 
      magM[k3]^2)))/(4*knl^2*magM[k1]^2), 
 (f1^2*dot[k1, hat[z]]*(4*f1*dot[k1, hat[z]]^2*dot[k2, hat[z]] + 
    2*dot[k2, hat[z]]*(-magM[k2]^2 + magM[k3]^2) + 
    dot[k1, hat[z]]*(4*f1*dot[k2, hat[z]]^2 + magM[k1]^2 - magM[k2]^2 + 
      magM[k3]^2)))/(4*knl^2*magM[k1]^2), 2, 
 -((magM[k2]^2 + magM[k3]^2)/knl^2), 
 -1/2*(magM[k1]^4 + (magM[k2]^2 - magM[k3]^2)^2)/(knl^2*magM[k1]^2), 
 -(magM[k1]^2/knl^2), 
 -1/4*(f1*(4*dot[k2, hat[z]]^2*magM[k1]^2 + dot[k1, hat[z]]^2*
      (magM[k1]^2 - magM[k2]^2 + magM[k3]^2) + 2*dot[k1, hat[z]]*
      dot[k2, hat[z]]*(2*magM[k1]^2 - magM[k2]^2 + magM[k3]^2)))/
   (knl^2*magM[k1]^2), 
 (f1*dot[k1, hat[z]]*(2*dot[k2, hat[z]]*(magM[k2]^2 - magM[k3]^2) + 
    dot[k1, hat[z]]*(magM[k1]^2 + magM[k2]^2 - magM[k3]^2)))/
  (2*knl^2*magM[k1]^2), (-2*f1*dot[k2, hat[z]]*
   (dot[k1, hat[z]] + dot[k2, hat[z]]))/knl^2, 
 (f1*(dot[k1, hat[z]]^2*magM[k2]^2*(magM[k1]^2 - magM[k2]^2 + magM[k3]^2)^2 + 
    2*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2*
     (magM[k1]^2 - magM[k2]^2 + magM[k3]^2)^2 + dot[k2, hat[z]]^2*
     (-2*magM[k1]^2*(magM[k2]^2 - magM[k3]^2)^2 + 
      magM[k1]^4*(magM[k2]^2 + magM[k3]^2) + (magM[k2]^2 - magM[k3]^2)^2*
       (magM[k2]^2 + magM[k3]^2))))/(4*knl^2*magM[k1]^2*magM[k2]^2*
   magM[k3]^2)}
