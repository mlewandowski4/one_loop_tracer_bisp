(* Created with the Wolfram Language : www.wolfram.com *)
((f1^2*dot[k1, hat[z]]*dot[k3, hat[z]]*(dot[k1, hat[z]] + dot[k2, hat[z]] + 
       dot[k3, hat[z]])^2)/(2*magM[k1]^2*magM[k3]^2) + 
   (f1^3*dot[k1, hat[z]]*dot[k2, hat[z]]*dot[k3, hat[z]]*
     (dot[k1, hat[z]] + dot[k2, hat[z]] + dot[k3, hat[z]])^3)/
    (6*magM[k1]^2*magM[k2]^2*magM[k3]^2) - 
   ((-2*dot[k1, k2] - 2*dot[k2, k3])*(9*magM[k1]^4 - 5*magM[k3]^4 + 
      3*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
      2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 + 
      magM[k1]^2*(24*magM[k3]^2 - 11*(2*dot[k1, k3] + magM[k1]^2 + 
          magM[k3]^2))))/(56*magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
   (f1*dot[k1, hat[z]]*(dot[k1, hat[z]] + dot[k2, hat[z]] + dot[k3, hat[z]])*
     (dot[k2, k3]/magM[k3]^2 + (9*magM[k2]^4 - 5*magM[k3]^4 - 
        11*magM[k2]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
        2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
        3*magM[k3]^2*(2*dot[k2, k3] + 9*magM[k2]^2 + magM[k3]^2))/
       (28*magM[k2]^2*magM[k3]^2)))/magM[k1]^2 + 
   (f1*(dot[k1, hat[z]] + dot[k3, hat[z]])*(dot[k1, hat[z]] + 
      dot[k2, hat[z]] + dot[k3, hat[z]])*(-1 + dot[k1, k3]/magM[k1]^2 + 
      (-5*magM[k1]^4 + 9*magM[k3]^4 - 11*magM[k3]^2*(2*dot[k1, k3] + 
          magM[k1]^2 + magM[k3]^2) + 2*(2*dot[k1, k3] + magM[k1]^2 + 
           magM[k3]^2)^2 + 3*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
          9*magM[k3]^2))/(14*magM[k1]^2*magM[k3]^2)))/
    (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
   (f1^2*dot[k2, hat[z]]*(dot[k1, hat[z]] + dot[k3, hat[z]])*
     (dot[k1, hat[z]] + dot[k2, hat[z]] + dot[k3, hat[z]])^2*
     (-1 + dot[k1, k3]/magM[k1]^2 + (-5*magM[k1]^4 + 9*magM[k3]^4 - 
        11*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
        2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 + 
        3*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 9*magM[k3]^2))/
       (14*magM[k1]^2*magM[k3]^2)))/(magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + 
      magM[k3]^2)) + (3*magM[k2]^6 - 3*magM[k2]^4*(2*dot[k1, k2] + 
       magM[k1]^2 + magM[k2]^2) + 3*magM[k3]^6 - 
     3*magM[k2]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
     14*magM[k1]^4*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
     magM[k2]^4*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
     magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
     29*magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
      (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
     14*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
       magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
     4*magM[k2]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
     4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
     18*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
      (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 - 
     3*magM[k3]^4*(2*dot[k1, k2] + 2*dot[k1, k3] + 2*magM[k1]^2 + 
       2*magM[k2]^2 + magM[k3]^2 - 5*(2*dot[k2, k3] + magM[k2]^2 + 
         magM[k3]^2)) + 3*magM[k3]^2*(-magM[k2]^4 - 
       5*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2) - 6*(2*dot[k2, k3] + magM[k2]^2 + 
          magM[k3]^2)^2 + (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (2*magM[k2]^2 - 5*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
       2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2 + 
         5*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2))) + 
     2*magM[k1]^2*(3*magM[k2]^4 + 3*magM[k3]^4 + 15*magM[k2]^2*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
       (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
        (7*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
         7*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
         11*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
       magM[k3]^2*(-6*magM[k2]^2 + 15*(2*dot[k2, k3] + magM[k2]^2 + 
           magM[k3]^2))))/(112*magM[k2]^2*magM[k3]^2*
     (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
   (magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
      (141*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2) + (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2)*(176*magM[k2]^2 - 
         139*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2)) - magM[k2]^4*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2)*(49*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2) + 15*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
           magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
       (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2)*(42*(2*dot[k1, k2] + magM[k1]^2 + 
            magM[k2]^2)^2 - 21*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
         20*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) + 23*(2*dot[k2, k3] + magM[k2]^2 + 
           magM[k3]^2)*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
           magM[k1]^2 + magM[k2]^2 + magM[k3]^2) - 
         4*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + 2*magM[k2]^2*
        (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (7*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
           magM[k2]^2 + magM[k3]^2) - 35*(2*dot[k2, k3] + magM[k2]^2 + 
            magM[k3]^2)^2 + 24*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) + 6*(2*(dot[k1, k2] + dot[k1, k3]) + 
            2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2)) + 
     (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
      (94*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^3*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2) + 6*(2*dot[k1, k2] + magM[k1]^2 + 
         magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(25*magM[k2]^2 - 
         17*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2)) + magM[k2]^2*(2*dot[k1, k2] + 
         magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
        (-21*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 - 
         21*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
         23*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) + 23*(2*dot[k2, k3] + magM[k2]^2 + 
           magM[k3]^2)*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
           magM[k1]^2 + magM[k2]^2 + magM[k3]^2) - 
         4*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + 4*(2*dot[k1, k2] + magM[k1]^2 + 
         magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(-7*magM[k2]^4 + 
         5*magM[k2]^2*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
           magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
         2*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + 2*(2*dot[k1, k2] + magM[k1]^2 + 
         magM[k2]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
        (-7*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^3 - 
         7*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^3 + 
         3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
          (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) + 3*(2*dot[k2, k3] + magM[k2]^2 + 
            magM[k3]^2)^2*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
           magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
         4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2 + 4*(2*dot[k2, k3] + magM[k2]^2 + 
           magM[k3]^2)*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
            magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
       magM[k2]^4*(35*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
          (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
         6*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2 + (2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)*(35*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 - 
           58*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
            (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2) - 6*(2*(dot[k1, k2] + dot[k1, k3]) + 
              2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2))) - 
     magM[k3]^4*(235*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2) + 3*(2*dot[k1, k2] + magM[k1]^2 + 
         magM[k2]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
        (-7*magM[k2]^4 + 5*magM[k2]^2*(2*(dot[k1, k2] + dot[k1, k3]) + 
           2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
         2*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + (2*dot[k1, k3] + magM[k1]^2 + 
         magM[k3]^2)*(-21*magM[k2]^4*(2*dot[k2, k3] + magM[k2]^2 + 
           magM[k3]^2) + 319*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
         (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (28*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
             magM[k2]^2 + magM[k3]^2) - 35*(2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2)^2 - 212*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
            (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2) + 6*(2*(dot[k1, k2] + dot[k1, k3]) + 
              2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2))) + 
     magM[k1]^4*(143*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2) + 3*magM[k3]^4*(2*dot[k1, k3] + 
         magM[k1]^2 + magM[k3]^2)*(-20*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2) + 7*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
       3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2)*(7*magM[k2]^4 - 5*magM[k2]^2*
          (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) - 2*(2*(dot[k1, k2] + dot[k1, k3]) + 
            2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
       magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (120*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
         (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          (76*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
           15*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2))) + (2*dot[k1, k3] + magM[k1]^2 + 
         magM[k3]^2)*(-60*magM[k2]^4*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2) + 32*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
         (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          (35*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 - 
           6*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)^2 + 2*(2*dot[k1, k2] + magM[k1]^2 + 
             magM[k2]^2)*(40*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
             83*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^
                2 + magM[k2]^2 + magM[k3]^2))))) + 
     magM[k1]^2*(-2*magM[k3]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (21*magM[k2]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
         (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (65*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
           33*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2))) - (2*dot[k1, k3] + magM[k1]^2 + 
         magM[k3]^2)*(237*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*(2*dot[k2, k3] + 
           magM[k2]^2 + magM[k3]^2) + (2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(202*magM[k2]^2 - 
           239*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2)) + 2*magM[k2]^4*(2*dot[k1, k2] + 
           magM[k1]^2 + magM[k2]^2)*(65*(2*dot[k2, k3] + magM[k2]^2 + 
             magM[k3]^2) - 33*(2*(dot[k1, k2] + dot[k1, k3]) + 
             2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
         (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
           magM[k2]^2 + magM[k3]^2)*(21*(2*dot[k1, k2] + magM[k1]^2 + 
              magM[k2]^2)^2 - 150*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^
             2 - 23*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
            (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2) + 88*(2*dot[k2, k3] + magM[k2]^2 + 
             magM[k3]^2)*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
             magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
           4*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)^2) + magM[k2]^2*(2*dot[k2, k3] + 
           magM[k2]^2 + magM[k3]^2)*(70*(2*dot[k1, k2] + magM[k1]^2 + 
              magM[k2]^2)^2 - 12*(2*(dot[k1, k2] + dot[k1, k3]) + 
              2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2 + 
           (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
            (13*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
             75*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^
                2 + magM[k2]^2 + magM[k3]^2)))) + 
       magM[k3]^2*(848*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*(2*dot[k2, k3] + 
           magM[k2]^2 + magM[k3]^2) + 6*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          (-7*magM[k2]^4 + 5*magM[k2]^2*(2*(dot[k1, k2] + dot[k1, k3]) + 
             2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
           2*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)^2) + (2*dot[k1, k3] + magM[k1]^2 + 
           magM[k3]^2)*((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
            (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
            (14*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
             13*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
             843*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^
                2 + magM[k2]^2 + magM[k3]^2)) + 6*magM[k2]^2*
            (5*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
              (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2) + (2*dot[k1, k2] + magM[k1]^2 + 
               magM[k2]^2)*(236*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
               22*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
                 magM[k1]^2 + magM[k2]^2 + magM[k3]^2)))))))/
    (3024*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
     magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
     (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
   (f1*(dot[k1, hat[z]] + dot[k2, hat[z]] + dot[k3, hat[z]])^2*
     (1 - (2*dot[k2, k3])/magM[k2]^2 - ((-2*dot[k1, k2] - 2*dot[k2, k3])*
        (9*magM[k1]^4 - 5*magM[k3]^4 + 3*magM[k3]^2*(2*dot[k1, k3] + 
           magM[k1]^2 + magM[k3]^2) + 2*(2*dot[k1, k3] + magM[k1]^2 + 
            magM[k3]^2)^2 + magM[k1]^2*(24*magM[k3]^2 - 
           11*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2))))/
       (28*magM[k1]^2*magM[k2]^2*magM[k3]^2) - 
      (3*(24 - (5*magM[k1]^2)/magM[k3]^2 + (14*magM[k3]^2)/magM[k2]^2 + 
         (3*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2))/magM[k3]^2 - 
         (14*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2))/magM[k2]^2 + 
         (-5*magM[k3]^2 + 3*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
           (2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2)/magM[k3]^2)/
          magM[k1]^2))/28 + (3*magM[k2]^6 - 3*magM[k2]^4*
         (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 3*magM[k3]^6 - 
        3*magM[k2]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
        14*magM[k1]^4*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
        magM[k2]^4*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
        magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
         (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
        29*magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
         (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
        14*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
          magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
          magM[k3]^2) - 4*magM[k2]^2*(2*dot[k2, k3] + magM[k2]^2 + 
           magM[k3]^2)^2 + 4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
         (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
        18*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
         (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 - 
        3*magM[k3]^4*(2*dot[k1, k2] + 2*dot[k1, k3] + 2*magM[k1]^2 + 
          2*magM[k2]^2 + magM[k3]^2 - 5*(2*dot[k2, k3] + magM[k2]^2 + 
            magM[k3]^2)) + 3*magM[k3]^2*(-magM[k2]^4 - 
          5*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2) - 6*(2*dot[k2, k3] + magM[k2]^2 + 
             magM[k3]^2)^2 + (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
           (2*magM[k2]^2 - 5*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
          2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2 + 
            5*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2))) + 
        2*magM[k1]^2*(3*magM[k2]^4 + 3*magM[k3]^4 + 15*magM[k2]^2*
           (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
          (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
           (7*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
            7*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
            11*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
          magM[k3]^2*(-6*magM[k2]^2 + 15*(2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2))))/(112*magM[k2]^2*magM[k3]^2*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
      (magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
         (141*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2) + (2*dot[k1, k2] + magM[k1]^2 + 
            magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
           (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(176*magM[k2]^2 - 
            139*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)) - magM[k2]^4*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2)*(49*(2*dot[k1, k2] + magM[k1]^2 + 
              magM[k2]^2) + 15*(2*(dot[k1, k2] + dot[k1, k3]) + 
              2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
          (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2)*(42*(2*dot[k1, k2] + magM[k1]^2 + 
               magM[k2]^2)^2 - 21*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^
              2 + 20*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) + 23*(2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2)*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
              magM[k1]^2 + magM[k2]^2 + magM[k3]^2) - 
            4*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2) + 2*magM[k2]^2*(2*dot[k1, k2] + 
            magM[k1]^2 + magM[k2]^2)*(7*(2*dot[k1, k2] + magM[k1]^2 + 
              magM[k2]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
            35*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
            24*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
             (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) + 6*(2*(dot[k1, k2] + dot[k1, k3]) + 2*
                dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2)) + 
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
         (94*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^3*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2) + 6*(2*dot[k1, k2] + magM[k1]^2 + 
            magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*
           (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(25*magM[k2]^2 - 
            17*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)) + magM[k2]^2*(2*dot[k1, k2] + 
            magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
            magM[k3]^2)*(-21*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 - 
            21*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
            23*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) + 23*(2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2)*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
              magM[k1]^2 + magM[k2]^2 + magM[k3]^2) - 
            4*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2) + 4*(2*dot[k1, k2] + magM[k1]^2 + 
            magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
           (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(-7*magM[k2]^4 + 
            5*magM[k2]^2*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
              magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
            2*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2) + 2*(2*dot[k1, k2] + magM[k1]^2 + 
            magM[k2]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
           (-7*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^3 - 
            7*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^3 + 
            3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
             (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) + 3*(2*dot[k2, k3] + magM[k2]^2 + 
               magM[k3]^2)^2*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
              magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
            4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2 + 4*(2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2)*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
               magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
          magM[k2]^4*(35*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
             (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
            6*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
             (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2 + (2*dot[k1, k2] + magM[k1]^2 + 
              magM[k2]^2)*(35*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 - 
              58*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(
                2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
                magM[k2]^2 + magM[k3]^2) - 6*(2*(dot[k1, k2] + dot[k1, k3]) + 
                 2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2))) - 
        magM[k3]^4*(235*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2) + 3*(2*dot[k1, k2] + magM[k1]^2 + 
            magM[k2]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
           (-7*magM[k2]^4 + 5*magM[k2]^2*(2*(dot[k1, k2] + dot[k1, k3]) + 
              2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
            2*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2) + (2*dot[k1, k3] + magM[k1]^2 + 
            magM[k3]^2)*(-21*magM[k2]^4*(2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2) + 319*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + 
              magM[k2]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
            (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (28*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
                magM[k2]^2 + magM[k3]^2) - 35*(2*dot[k2, k3] + magM[k2]^2 + 
                 magM[k3]^2)^2 - 212*(2*dot[k2, k3] + magM[k2]^2 + 
                magM[k3]^2)*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
              6*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
                 magM[k2]^2 + magM[k3]^2)^2))) + magM[k1]^4*
         (143*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2) + 3*magM[k3]^4*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(-20*(2*dot[k1, k2] + magM[k1]^2 + 
              magM[k2]^2) + 7*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
          3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2)*(7*magM[k2]^4 - 5*magM[k2]^2*
             (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) - 2*(2*(dot[k1, k2] + dot[k1, k3]) + 2*
                dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
          magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
           (120*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
            (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
             (76*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
              15*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2))) + 
          (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
           (-60*magM[k2]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
            32*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
            (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
             (35*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 - 
              6*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
                 magM[k2]^2 + magM[k3]^2)^2 + 2*(2*dot[k1, k2] + magM[k1]^2 + 
                magM[k2]^2)*(40*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
                83*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
                  magM[k1]^2 + magM[k2]^2 + magM[k3]^2))))) + 
        magM[k1]^2*(-2*magM[k3]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
           (21*magM[k2]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
            (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (65*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
              33*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2))) - 
          (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
           (237*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*(2*dot[k2, k3] + 
              magM[k2]^2 + magM[k3]^2) + (2*dot[k1, k2] + magM[k1]^2 + 
              magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(202*magM[k2]^2 - 
              239*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 2*magM[k2]^4*
             (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (65*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
              33*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
            (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
              magM[k2]^2 + magM[k3]^2)*(21*(2*dot[k1, k2] + magM[k1]^2 + 
                 magM[k2]^2)^2 - 150*(2*dot[k2, k3] + magM[k2]^2 + 
                 magM[k3]^2)^2 - 23*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
               (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
                magM[k2]^2 + magM[k3]^2) + 88*(2*dot[k2, k3] + magM[k2]^2 + 
                magM[k3]^2)*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
              4*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
                 magM[k2]^2 + magM[k3]^2)^2) + magM[k2]^2*(2*dot[k2, k3] + 
              magM[k2]^2 + magM[k3]^2)*(70*(2*dot[k1, k2] + magM[k1]^2 + 
                 magM[k2]^2)^2 - 12*(2*(dot[k1, k2] + dot[k1, k3]) + 
                 2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2 + 
              (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(13*(2*dot[k2, k3] + 
                  magM[k2]^2 + magM[k3]^2) - 75*(2*(dot[k1, k2] + dot[k1, 
                     k3]) + 2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + 
                  magM[k3]^2)))) + magM[k3]^2*
           (848*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*(2*dot[k2, k3] + 
              magM[k2]^2 + magM[k3]^2) + 6*(2*dot[k1, k2] + magM[k1]^2 + 
              magM[k2]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
             (-7*magM[k2]^4 + 5*magM[k2]^2*(2*(dot[k1, k2] + dot[k1, k3]) + 
                2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
              2*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
                 magM[k2]^2 + magM[k3]^2)^2) + (2*dot[k1, k3] + magM[k1]^2 + 
              magM[k3]^2)*((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(
                2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(14*(2*dot[k1, k2] + 
                  magM[k1]^2 + magM[k2]^2) - 13*(2*dot[k2, k3] + magM[k2]^2 + 
                  magM[k3]^2) - 843*(2*(dot[k1, k2] + dot[k1, k3]) + 
                  2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
              6*magM[k2]^2*(5*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
                 (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
                  magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + (2*dot[k1, k2] + 
                  magM[k1]^2 + magM[k2]^2)*(236*(2*dot[k2, k3] + magM[k2]^2 + 
                    magM[k3]^2) - 22*(2*(dot[k1, k2] + dot[k1, k3]) + 
                    2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^
                     2)))))))/(1008*magM[k1]^2*magM[k2]^2*
        (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*magM[k3]^2*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2))))/(2*(dot[k1, k2] + dot[k1, k3]) + 
     2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2))/6 + 
 ((f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]*(dot[k1, hat[z]] + dot[k2, hat[z]] + 
       dot[k3, hat[z]])^2)/(2*magM[k1]^2*magM[k2]^2) + 
   (f1*(dot[k1, hat[z]] + dot[k2, hat[z]])*(dot[k1, hat[z]] + 
      dot[k2, hat[z]] + dot[k3, hat[z]])*(-1 + dot[k1, k2]/magM[k1]^2 + 
      (-5*magM[k1]^4 + 9*magM[k2]^4 - 11*magM[k2]^2*(2*dot[k1, k2] + 
          magM[k1]^2 + magM[k2]^2) + 2*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)^2 + 3*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
          9*magM[k2]^2))/(14*magM[k1]^2*magM[k2]^2)))/
    (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
   (f1^3*dot[k1, hat[z]]*dot[k2, hat[z]]*dot[k3, hat[z]]*
     (dot[k1, hat[z]] + dot[k2, hat[z]] + dot[k3, hat[z]])^3)/
    (6*magM[k1]^2*magM[k2]^2*magM[k3]^2) - 
   ((-2*dot[k1, k3] - 2*dot[k2, k3])*(9*magM[k1]^4 - 5*magM[k2]^4 + 
      3*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
      2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 + 
      magM[k1]^2*(24*magM[k2]^2 - 11*(2*dot[k1, k2] + magM[k1]^2 + 
          magM[k2]^2))))/(56*magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
   (f1^2*(dot[k1, hat[z]] + dot[k2, hat[z]])*dot[k3, hat[z]]*
     (dot[k1, hat[z]] + dot[k2, hat[z]] + dot[k3, hat[z]])^2*
     (-1 + dot[k1, k2]/magM[k1]^2 + (-5*magM[k1]^4 + 9*magM[k2]^4 - 
        11*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
        2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 + 
        3*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 9*magM[k2]^2))/
       (14*magM[k1]^2*magM[k2]^2)))/((2*dot[k1, k2] + magM[k1]^2 + 
      magM[k2]^2)*magM[k3]^2) + 
   (f1*dot[k1, hat[z]]*(dot[k1, hat[z]] + dot[k2, hat[z]] + dot[k3, hat[z]])*
     (dot[k2, k3]/magM[k2]^2 + (-5*magM[k2]^4 + 9*magM[k3]^4 - 
        11*magM[k3]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
        2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
        3*magM[k2]^2*(2*dot[k2, k3] + magM[k2]^2 + 9*magM[k3]^2))/
       (28*magM[k2]^2*magM[k3]^2)))/magM[k1]^2 + 
   (3*magM[k2]^6 - 3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*magM[k3]^4 + 
     3*magM[k3]^6 - 3*magM[k3]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
     14*magM[k1]^4*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
     29*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*magM[k3]^2*
      (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
     magM[k3]^4*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
     14*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
       magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
     magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
      (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
     18*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 - 
     4*magM[k3]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
     4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
      (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 - 
     3*magM[k2]^4*(2*dot[k1, k2] + 2*dot[k1, k3] + 2*magM[k1]^2 + 
       magM[k2]^2 + 2*magM[k3]^2 - 5*(2*dot[k2, k3] + magM[k2]^2 + 
         magM[k3]^2)) + 3*magM[k2]^2*(-magM[k3]^4 - 
       5*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2) - 6*(2*dot[k2, k3] + magM[k2]^2 + 
          magM[k3]^2)^2 + (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (2*magM[k3]^2 - 5*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
       2*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2 + 
         5*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2))) + 
     2*magM[k1]^2*(3*magM[k2]^4 + 3*magM[k3]^4 + 15*magM[k3]^2*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
       (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
        (7*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
         7*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
         11*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
       magM[k2]^2*(-6*magM[k3]^2 + 15*(2*dot[k2, k3] + magM[k2]^2 + 
           magM[k3]^2))))/(112*magM[k2]^2*magM[k3]^2*
     (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
   (magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      (141*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2) + (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2)*(176*magM[k3]^2 - 
         139*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2)) - magM[k3]^4*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2)*(49*(2*dot[k1, k3] + magM[k1]^2 + 
           magM[k3]^2) + 15*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
           magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
       (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2)*(42*(2*dot[k1, k3] + magM[k1]^2 + 
            magM[k3]^2)^2 - 21*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
         20*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) + 23*(2*dot[k2, k3] + magM[k2]^2 + 
           magM[k3]^2)*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
           magM[k1]^2 + magM[k2]^2 + magM[k3]^2) - 
         4*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + 2*magM[k3]^2*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (7*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
           magM[k2]^2 + magM[k3]^2) - 35*(2*dot[k2, k3] + magM[k2]^2 + 
            magM[k3]^2)^2 + 24*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) + 6*(2*(dot[k1, k2] + dot[k1, k3]) + 
            2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2)) + 
     (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      (94*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^3*(2*dot[k1, k3] + 
         magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
       6*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*(2*dot[k1, k3] + 
         magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
        (25*magM[k3]^2 - 17*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
           magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
       magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
        (-21*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 - 
         21*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
         23*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) + 23*(2*dot[k2, k3] + magM[k2]^2 + 
           magM[k3]^2)*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
           magM[k1]^2 + magM[k2]^2 + magM[k3]^2) - 
         4*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + 4*(2*dot[k1, k2] + magM[k1]^2 + 
         magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(-7*magM[k3]^4 + 
         5*magM[k3]^2*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
           magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
         2*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + 2*(2*dot[k1, k3] + magM[k1]^2 + 
         magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
        (-7*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^3 - 
         7*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^3 + 
         3*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*
          (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) + 3*(2*dot[k2, k3] + magM[k2]^2 + 
            magM[k3]^2)^2*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
           magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
         4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2 + 4*(2*dot[k2, k3] + magM[k2]^2 + 
           magM[k3]^2)*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
            magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
       magM[k3]^4*(35*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*
          (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
         6*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2 + (2*dot[k1, k3] + magM[k1]^2 + 
           magM[k3]^2)*(35*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 - 
           58*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
            (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2) - 6*(2*(dot[k1, k2] + dot[k1, k3]) + 
              2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2))) - 
     magM[k2]^4*(235*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2) + 3*(2*dot[k1, k3] + magM[k1]^2 + 
         magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
        (-7*magM[k3]^4 + 5*magM[k3]^2*(2*(dot[k1, k2] + dot[k1, k3]) + 
           2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
         2*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + (2*dot[k1, k2] + magM[k1]^2 + 
         magM[k2]^2)*(-21*magM[k3]^4*(2*dot[k2, k3] + magM[k2]^2 + 
           magM[k3]^2) + 319*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + 
           magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
         (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (28*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
             magM[k2]^2 + magM[k3]^2) - 35*(2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2)^2 - 212*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
            (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2) + 6*(2*(dot[k1, k2] + dot[k1, k3]) + 
              2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2))) + 
     magM[k1]^4*(143*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2) + 3*magM[k2]^4*(2*dot[k1, k2] + 
         magM[k1]^2 + magM[k2]^2)*(-20*(2*dot[k1, k3] + magM[k1]^2 + 
           magM[k3]^2) + 7*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
       3*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2)*(7*magM[k3]^4 - 5*magM[k3]^2*
          (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) - 2*(2*(dot[k1, k2] + dot[k1, k3]) + 
            2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
       magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (120*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
         (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          (76*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
           15*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2))) + (2*dot[k1, k2] + magM[k1]^2 + 
         magM[k2]^2)*(-60*magM[k3]^4*(2*dot[k1, k3] + magM[k1]^2 + 
           magM[k3]^2) + 32*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + 
           magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
         (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          (35*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 - 
           6*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)^2 + 2*(2*dot[k1, k3] + magM[k1]^2 + 
             magM[k3]^2)*(40*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
             83*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^
                2 + magM[k2]^2 + magM[k3]^2))))) + 
     magM[k1]^2*(-2*magM[k2]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (21*magM[k3]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
         (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (65*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
           33*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2))) - (2*dot[k1, k2] + magM[k1]^2 + 
         magM[k2]^2)*(237*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
          (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
           magM[k2]^2 + magM[k3]^2) + (2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(202*magM[k3]^2 - 
           239*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2)) + 2*magM[k3]^4*(2*dot[k1, k3] + 
           magM[k1]^2 + magM[k3]^2)*(65*(2*dot[k2, k3] + magM[k2]^2 + 
             magM[k3]^2) - 33*(2*(dot[k1, k2] + dot[k1, k3]) + 
             2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
         (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
           magM[k2]^2 + magM[k3]^2)*(21*(2*dot[k1, k3] + magM[k1]^2 + 
              magM[k3]^2)^2 - 150*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^
             2 - 23*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
            (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2) + 88*(2*dot[k2, k3] + magM[k2]^2 + 
             magM[k3]^2)*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
             magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
           4*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)^2) + magM[k3]^2*(2*dot[k2, k3] + 
           magM[k2]^2 + magM[k3]^2)*(70*(2*dot[k1, k3] + magM[k1]^2 + 
              magM[k3]^2)^2 - 12*(2*(dot[k1, k2] + dot[k1, k3]) + 
              2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2 + 
           (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
            (13*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
             75*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^
                2 + magM[k2]^2 + magM[k3]^2)))) + 
       magM[k2]^2*(848*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
          (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
           magM[k2]^2 + magM[k3]^2) + 6*(2*dot[k1, k3] + magM[k1]^2 + 
           magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          (-7*magM[k3]^4 + 5*magM[k3]^2*(2*(dot[k1, k2] + dot[k1, k3]) + 
             2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
           2*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)^2) + (2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)*((2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
            (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
            (14*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
             13*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
             843*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^
                2 + magM[k2]^2 + magM[k3]^2)) + 6*magM[k3]^2*
            (5*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
              (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2) + (2*dot[k1, k3] + magM[k1]^2 + 
               magM[k3]^2)*(236*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
               22*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
                 magM[k1]^2 + magM[k2]^2 + magM[k3]^2)))))))/
    (3024*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
     magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
     (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
   (f1*(dot[k1, hat[z]] + dot[k2, hat[z]] + dot[k3, hat[z]])^2*
     (1 - (2*dot[k2, k3])/magM[k3]^2 - ((-2*dot[k1, k3] - 2*dot[k2, k3])*
        (9*magM[k1]^4 - 5*magM[k2]^4 + 3*magM[k2]^2*(2*dot[k1, k2] + 
           magM[k1]^2 + magM[k2]^2) + 2*(2*dot[k1, k2] + magM[k1]^2 + 
            magM[k2]^2)^2 + magM[k1]^2*(24*magM[k2]^2 - 
           11*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2))))/
       (28*magM[k1]^2*magM[k2]^2*magM[k3]^2) - 
      (3*(24 - (5*magM[k1]^2)/magM[k2]^2 + 
         (3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2))/magM[k2]^2 + 
         (-5*magM[k2]^2 + 3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
           (2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2)/magM[k2]^2)/
          magM[k1]^2 + (14*magM[k2]^2)/magM[k3]^2 - 
         (14*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2))/magM[k3]^2))/28 + 
      (3*magM[k2]^6 - 3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
         magM[k3]^4 + 3*magM[k3]^6 - 3*magM[k3]^4*(2*dot[k1, k3] + 
          magM[k1]^2 + magM[k3]^2) + 14*magM[k1]^4*(2*dot[k2, k3] + 
          magM[k2]^2 + magM[k3]^2) - 29*(2*dot[k1, k2] + magM[k1]^2 + 
          magM[k2]^2)*magM[k3]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
        magM[k3]^4*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
        14*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
          magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
          magM[k3]^2) - magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
         (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
        18*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
         (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 - 
        4*magM[k3]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
        4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
         (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 - 
        3*magM[k2]^4*(2*dot[k1, k2] + 2*dot[k1, k3] + 2*magM[k1]^2 + 
          magM[k2]^2 + 2*magM[k3]^2 - 5*(2*dot[k2, k3] + magM[k2]^2 + 
            magM[k3]^2)) + 3*magM[k2]^2*(-magM[k3]^4 - 
          5*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2) - 6*(2*dot[k2, k3] + magM[k2]^2 + 
             magM[k3]^2)^2 + (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (2*magM[k3]^2 - 5*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
          2*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2 + 
            5*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2))) + 
        2*magM[k1]^2*(3*magM[k2]^4 + 3*magM[k3]^4 + 15*magM[k3]^2*
           (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
          (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
           (7*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
            7*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
            11*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
          magM[k2]^2*(-6*magM[k3]^2 + 15*(2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2))))/(112*magM[k2]^2*magM[k3]^2*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
      (magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
         (141*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
            magM[k3]^2) + (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2)*(176*magM[k3]^2 - 
            139*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)) - magM[k3]^4*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2)*(49*(2*dot[k1, k3] + magM[k1]^2 + 
              magM[k3]^2) + 15*(2*(dot[k1, k2] + dot[k1, k3]) + 
              2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
          (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2)*(42*(2*dot[k1, k3] + magM[k1]^2 + 
               magM[k3]^2)^2 - 21*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^
              2 + 20*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) + 23*(2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2)*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
              magM[k1]^2 + magM[k2]^2 + magM[k3]^2) - 
            4*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2) + 2*magM[k3]^2*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(7*(2*dot[k1, k3] + magM[k1]^2 + 
              magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
            35*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
            24*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
             (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) + 6*(2*(dot[k1, k2] + dot[k1, k3]) + 2*
                dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2)) + 
        (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
         (94*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^3*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
            magM[k3]^2) + 6*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
           (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2)*(25*magM[k3]^2 - 
            17*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)) + magM[k3]^2*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
            magM[k3]^2)*(-21*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 - 
            21*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
            23*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) + 23*(2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2)*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
              magM[k1]^2 + magM[k2]^2 + magM[k3]^2) - 
            4*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2) + 4*(2*dot[k1, k2] + magM[k1]^2 + 
            magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
           (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(-7*magM[k3]^4 + 
            5*magM[k3]^2*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
              magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
            2*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2) + 2*(2*dot[k1, k3] + magM[k1]^2 + 
            magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
           (-7*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^3 - 
            7*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^3 + 
            3*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*
             (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) + 3*(2*dot[k2, k3] + magM[k2]^2 + 
               magM[k3]^2)^2*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
              magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
            4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2 + 4*(2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2)*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
               magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
          magM[k3]^4*(35*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*
             (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
            6*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
             (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2 + (2*dot[k1, k3] + magM[k1]^2 + 
              magM[k3]^2)*(35*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 - 
              58*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(
                2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
                magM[k2]^2 + magM[k3]^2) - 6*(2*(dot[k1, k2] + dot[k1, k3]) + 
                 2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2))) - 
        magM[k2]^4*(235*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
           (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2) + 3*(2*dot[k1, k3] + magM[k1]^2 + 
            magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
           (-7*magM[k3]^4 + 5*magM[k3]^2*(2*(dot[k1, k2] + dot[k1, k3]) + 
              2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
            2*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2) + (2*dot[k1, k2] + magM[k1]^2 + 
            magM[k2]^2)*(-21*magM[k3]^4*(2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2) + 319*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + 
              magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
            (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (28*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
                magM[k2]^2 + magM[k3]^2) - 35*(2*dot[k2, k3] + magM[k2]^2 + 
                 magM[k3]^2)^2 - 212*(2*dot[k2, k3] + magM[k2]^2 + 
                magM[k3]^2)*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
              6*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
                 magM[k2]^2 + magM[k3]^2)^2))) + magM[k1]^4*
         (143*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
            magM[k3]^2) + 3*magM[k2]^4*(2*dot[k1, k2] + magM[k1]^2 + 
            magM[k2]^2)*(-20*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
            7*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
          3*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2)*(7*magM[k3]^4 - 5*magM[k3]^2*
             (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) - 2*(2*(dot[k1, k2] + dot[k1, k3]) + 2*
                dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
          magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (120*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
            (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
             (76*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
              15*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2))) + 
          (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (-60*magM[k3]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
            32*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
            (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
             (35*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 - 
              6*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
                 magM[k2]^2 + magM[k3]^2)^2 + 2*(2*dot[k1, k3] + magM[k1]^2 + 
                magM[k3]^2)*(40*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
                83*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
                  magM[k1]^2 + magM[k2]^2 + magM[k3]^2))))) + 
        magM[k1]^2*(-2*magM[k2]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (21*magM[k3]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
            (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (65*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
              33*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2))) - 
          (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (237*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*(2*dot[k1, k3] + 
              magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2) + (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
              magM[k2]^2 + magM[k3]^2)*(202*magM[k3]^2 - 
              239*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 2*magM[k3]^4*
             (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (65*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
              33*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
            (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
              magM[k2]^2 + magM[k3]^2)*(21*(2*dot[k1, k3] + magM[k1]^2 + 
                 magM[k3]^2)^2 - 150*(2*dot[k2, k3] + magM[k2]^2 + 
                 magM[k3]^2)^2 - 23*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
               (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
                magM[k2]^2 + magM[k3]^2) + 88*(2*dot[k2, k3] + magM[k2]^2 + 
                magM[k3]^2)*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
              4*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
                 magM[k2]^2 + magM[k3]^2)^2) + magM[k3]^2*(2*dot[k2, k3] + 
              magM[k2]^2 + magM[k3]^2)*(70*(2*dot[k1, k3] + magM[k1]^2 + 
                 magM[k3]^2)^2 - 12*(2*(dot[k1, k2] + dot[k1, k3]) + 
                 2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2 + 
              (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(13*(2*dot[k2, k3] + 
                  magM[k2]^2 + magM[k3]^2) - 75*(2*(dot[k1, k2] + dot[k1, 
                     k3]) + 2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + 
                  magM[k3]^2)))) + magM[k2]^2*
           (848*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*(2*dot[k1, k3] + 
              magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2) + 6*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(-7*magM[k3]^4 + 
              5*magM[k3]^2*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
              2*(2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + magM[k1]^2 + 
                 magM[k2]^2 + magM[k3]^2)^2) + (2*dot[k1, k2] + magM[k1]^2 + 
              magM[k2]^2)*((2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(
                2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(14*(2*dot[k1, k3] + 
                  magM[k1]^2 + magM[k3]^2) - 13*(2*dot[k2, k3] + magM[k2]^2 + 
                  magM[k3]^2) - 843*(2*(dot[k1, k2] + dot[k1, k3]) + 
                  2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
              6*magM[k3]^2*(5*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
                 (2*(dot[k1, k2] + dot[k1, k3]) + 2*dot[k2, k3] + 
                  magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + (2*dot[k1, k3] + 
                  magM[k1]^2 + magM[k3]^2)*(236*(2*dot[k2, k3] + magM[k2]^2 + 
                    magM[k3]^2) - 22*(2*(dot[k1, k2] + dot[k1, k3]) + 
                    2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^
                     2)))))))/(1008*magM[k1]^2*magM[k2]^2*
        (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*magM[k3]^2*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2))))/(2*(dot[k1, k2] + dot[k1, k3]) + 
     2*dot[k2, k3] + magM[k1]^2 + magM[k2]^2 + magM[k3]^2))/6 + 
 ((f1^2*dot[k2, hat[z]]*dot[k3, hat[z]]*(dot[k1, hat[z]] + dot[k2, hat[z]] + 
       dot[k3, hat[z]])^2)/(2*magM[k2]^2*magM[k3]^2) + 
   (f1^3*dot[k1, hat[z]]*dot[k2, hat[z]]*dot[k3, hat[z]]*
     (dot[k1, hat[z]] + dot[k2, hat[z]] + dot[k3, hat[z]])^3)/
    (6*magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
   (f1*dot[k2, hat[z]]*(dot[k1, hat[z]] + dot[k2, hat[z]] + dot[k3, hat[z]])*
     (dot[k1, k3]/magM[k3]^2 + (9*magM[k1]^4 - 5*magM[k3]^4 - 
        11*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
        2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 + 
        3*magM[k3]^2*(2*dot[k1, k3] + 9*magM[k1]^2 + magM[k3]^2))/
       (28*magM[k1]^2*magM[k3]^2)))/magM[k2]^2 - 
   ((-2*dot[k1, k2] - 2*dot[k1, k3])*(9*magM[k2]^4 - 5*magM[k3]^4 + 
      3*magM[k3]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
      2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
      magM[k2]^2*(24*magM[k3]^2 - 11*(2*dot[k2, k3] + magM[k2]^2 + 
          magM[k3]^2))))/(56*magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
   (f1*(dot[k2, hat[z]] + dot[k3, hat[z]])*(dot[k1, hat[z]] + 
      dot[k2, hat[z]] + dot[k3, hat[z]])*(-1 + dot[k2, k3]/magM[k2]^2 + 
      (-5*magM[k2]^4 + 9*magM[k3]^4 - 11*magM[k3]^2*(2*dot[k2, k3] + 
          magM[k2]^2 + magM[k3]^2) + 2*(2*dot[k2, k3] + magM[k2]^2 + 
           magM[k3]^2)^2 + 3*magM[k2]^2*(2*dot[k2, k3] + magM[k2]^2 + 
          9*magM[k3]^2))/(14*magM[k2]^2*magM[k3]^2)))/
    (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
   (f1^2*dot[k1, hat[z]]*(dot[k2, hat[z]] + dot[k3, hat[z]])*
     (dot[k1, hat[z]] + dot[k2, hat[z]] + dot[k3, hat[z]])^2*
     (-1 + dot[k2, k3]/magM[k2]^2 + (-5*magM[k2]^4 + 9*magM[k3]^4 - 
        11*magM[k3]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
        2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
        3*magM[k2]^2*(2*dot[k2, k3] + magM[k2]^2 + 9*magM[k3]^2))/
       (14*magM[k2]^2*magM[k3]^2)))/(magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + 
      magM[k3]^2)) + (3*magM[k1]^6 - 3*magM[k1]^4*(2*dot[k1, k2] + 
       magM[k1]^2 + magM[k2]^2) + 3*magM[k3]^6 + 
     magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
     14*magM[k2]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
     magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
     4*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 + 
     4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 - 
     3*magM[k1]^4*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
     29*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
      (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
     14*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
       magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
     18*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*
      (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
     3*magM[k3]^4*(2*dot[k1, k2] + 2*dot[k2, k3] + 2*magM[k1]^2 + 
       2*magM[k2]^2 + magM[k3]^2 - 5*(2*dot[k1, k3] + magM[k1]^2 + 
         magM[k3]^2)) + 3*magM[k3]^2*(-magM[k1]^4 - 
       5*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
         magM[k1]^2 + magM[k3]^2) - 6*(2*dot[k1, k3] + magM[k1]^2 + 
          magM[k3]^2)^2 + (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
        (2*magM[k1]^2 - 5*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
       2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2 + 
         5*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2))) + 
     2*magM[k2]^2*(3*magM[k1]^4 + 3*magM[k3]^4 + 15*magM[k1]^2*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
       magM[k3]^2*(-6*magM[k1]^2 + 15*(2*dot[k1, k3] + magM[k1]^2 + 
           magM[k3]^2)) - (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (7*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
         11*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
         7*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2))))/
    (112*magM[k1]^2*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
   (magM[k3]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
      (141*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
         magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^
         2 + (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2)*(176*magM[k1]^2 - 
         139*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2)) - magM[k1]^4*(2*dot[k1, k3] + 
         magM[k1]^2 + magM[k3]^2)*(49*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2) + 15*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
           magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
       (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
         magM[k1]^2 + magM[k3]^2)*(42*(2*dot[k1, k2] + magM[k1]^2 + 
            magM[k2]^2)^2 - 21*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 + 
         20*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
           2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
           magM[k3]^2) + 23*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) - 
         4*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + 2*magM[k1]^2*
        (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (7*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
           magM[k1]^2 + magM[k3]^2) - 35*(2*dot[k1, k3] + magM[k1]^2 + 
            magM[k3]^2)^2 + 24*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) + 
         6*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2)) + 
     (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
      (94*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
         magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^
         3 + 6*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2*(25*magM[k1]^2 - 
         17*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2)) + magM[k1]^2*(2*dot[k1, k2] + 
         magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (-21*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 - 
         21*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 + 
         23*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
           2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
           magM[k3]^2) + 23*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) - 
         4*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + 4*(2*dot[k1, k2] + magM[k1]^2 + 
         magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(-7*magM[k1]^4 + 
         5*magM[k1]^2*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
           magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
         2*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + 2*(2*dot[k1, k2] + magM[k1]^2 + 
         magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (-7*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^3 - 
         7*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^3 + 
         3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*(2*dot[k1, k3] + 
           2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
           magM[k3]^2) + 3*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*
          (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) + 4*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
            magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2 + 
         4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + magM[k1]^4*
        (35*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*(2*dot[k1, k3] + 
           magM[k1]^2 + magM[k3]^2) - 6*(2*dot[k1, k3] + magM[k1]^2 + 
           magM[k3]^2)*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
            magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2 + 
         (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (35*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 - 
           58*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k1, k3] + 
             2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
             magM[k3]^2) - 6*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
              magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2))) - 
     magM[k3]^4*(235*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
       3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
         magM[k1]^2 + magM[k3]^2)*(-7*magM[k1]^4 + 5*magM[k1]^2*
          (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) + 
         2*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + (2*dot[k2, k3] + magM[k2]^2 + 
         magM[k3]^2)*(-21*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
           magM[k3]^2) + 319*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
         (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (28*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
             magM[k1]^2 + magM[k3]^2) - 35*(2*dot[k1, k3] + magM[k1]^2 + 
              magM[k3]^2)^2 - 212*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
            (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2) + 6*(2*dot[k1, k3] + 2*(dot[k1, k2] + 
                dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2))) + 
     magM[k2]^4*(143*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
       3*magM[k3]^4*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
        (-20*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
         7*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
       3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
         magM[k1]^2 + magM[k3]^2)*(7*magM[k1]^4 - 5*magM[k1]^2*
          (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) - 
         2*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + magM[k3]^2*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2)*(120*magM[k1]^2*(2*dot[k1, k2] + 
           magM[k1]^2 + magM[k2]^2) - (2*dot[k1, k3] + magM[k1]^2 + 
           magM[k3]^2)*(76*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
           15*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2))) + (2*dot[k2, k3] + magM[k2]^2 + 
         magM[k3]^2)*(-60*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2) + 32*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
         (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (35*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 - 
           6*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)^2 + 2*(2*dot[k1, k2] + magM[k1]^2 + 
             magM[k2]^2)*(40*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
             83*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^
                2 + magM[k2]^2 + magM[k3]^2))))) + 
     magM[k2]^2*(-2*magM[k3]^4*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
        (21*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
         (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (65*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
           33*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2))) - (2*dot[k2, k3] + magM[k2]^2 + 
         magM[k3]^2)*(237*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
         (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
           magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          (202*magM[k1]^2 - 239*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, 
                k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
         2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (65*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
           33*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2)) + (2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (21*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 - 
           150*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 - 
           23*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
             2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
             magM[k3]^2) + 88*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
            (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2) + 4*(2*dot[k1, k3] + 2*(dot[k1, k2] + 
                dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
         magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (70*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 - 
           12*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)^2 + (2*dot[k1, k2] + magM[k1]^2 + 
             magM[k2]^2)*(13*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
             75*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^
                2 + magM[k2]^2 + magM[k3]^2)))) + 
       magM[k3]^2*(848*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
         6*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
           magM[k1]^2 + magM[k3]^2)*(-7*magM[k1]^4 + 5*magM[k1]^2*
            (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2) + 2*(2*dot[k1, k3] + 2*(dot[k1, k2] + 
                dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
         (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          ((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
             magM[k1]^2 + magM[k3]^2)*(14*(2*dot[k1, k2] + magM[k1]^2 + 
               magM[k2]^2) - 13*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
             843*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^
                2 + magM[k2]^2 + magM[k3]^2)) + 6*magM[k1]^2*
            (5*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k1, k3] + 2*
                (dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
               magM[k3]^2) + (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
              (236*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 22*
                (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
                 magM[k2]^2 + magM[k3]^2)))))))/(3024*magM[k1]^2*magM[k2]^2*
     (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*magM[k3]^2*
     (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
      magM[k3]^2)) + (f1*(dot[k1, hat[z]] + dot[k2, hat[z]] + 
       dot[k3, hat[z]])^2*(1 - (2*dot[k1, k3])/magM[k1]^2 - 
      ((-2*dot[k1, k2] - 2*dot[k1, k3])*(9*magM[k2]^4 - 5*magM[k3]^4 + 
         3*magM[k3]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
         2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
         magM[k2]^2*(24*magM[k3]^2 - 11*(2*dot[k2, k3] + magM[k2]^2 + 
             magM[k3]^2))))/(28*magM[k1]^2*magM[k2]^2*magM[k3]^2) - 
      (3*(24 - (5*magM[k2]^2)/magM[k3]^2 + (14*magM[k3]^2)/magM[k1]^2 - 
         (14*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2))/magM[k1]^2 + 
         (3*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2))/magM[k3]^2 + 
         (-5*magM[k3]^2 + 3*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
           (2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2)/magM[k3]^2)/
          magM[k2]^2))/28 + (3*magM[k1]^6 - 3*magM[k1]^4*
         (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 3*magM[k3]^6 + 
        magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
        14*magM[k2]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
        magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
         (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
        4*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 + 
        4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
         (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 - 
        3*magM[k1]^4*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
        29*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
         (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
        14*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
          magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
          magM[k3]^2) + 18*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*
         (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
        3*magM[k3]^4*(2*dot[k1, k2] + 2*dot[k2, k3] + 2*magM[k1]^2 + 
          2*magM[k2]^2 + magM[k3]^2 - 5*(2*dot[k1, k3] + magM[k1]^2 + 
            magM[k3]^2)) + 3*magM[k3]^2*(-magM[k1]^4 - 
          5*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2) - 6*(2*dot[k1, k3] + magM[k1]^2 + 
             magM[k3]^2)^2 + (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
           (2*magM[k1]^2 - 5*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
          2*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2 + 
            5*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2))) + 
        2*magM[k2]^2*(3*magM[k1]^4 + 3*magM[k3]^4 + 15*magM[k1]^2*
           (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
          magM[k3]^2*(-6*magM[k1]^2 + 15*(2*dot[k1, k3] + magM[k1]^2 + 
              magM[k3]^2)) - (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
           (7*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
            11*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
            7*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2))))/
       (112*magM[k1]^2*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + 
         magM[k3]^2)) + (magM[k3]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
         (141*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
             magM[k3]^2)^2 + (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2)*(176*magM[k1]^2 - 
            139*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)) - magM[k1]^4*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(49*(2*dot[k1, k2] + magM[k1]^2 + 
              magM[k2]^2) + 15*(2*dot[k1, k3] + 2*(dot[k1, k2] + 
                dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
          (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(42*(2*dot[k1, k2] + magM[k1]^2 + 
               magM[k2]^2)^2 - 21*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^
              2 + 20*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) + 23*(2*dot[k1, k3] + magM[k1]^2 + 
              magM[k3]^2)*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
              magM[k1]^2 + magM[k2]^2 + magM[k3]^2) - 
            4*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2) + 2*magM[k1]^2*(2*dot[k1, k2] + 
            magM[k1]^2 + magM[k2]^2)*(7*(2*dot[k1, k2] + magM[k1]^2 + 
              magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
            35*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 + 
            24*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k1, k3] + 
              2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
              magM[k3]^2) + 6*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, 
                  k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2)) + 
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
         (94*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
             magM[k3]^2)^3 + 6*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
           (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2*(25*magM[k1]^2 - 
            17*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)) + magM[k1]^2*(2*dot[k1, k2] + 
            magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + 
            magM[k3]^2)*(-21*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 - 
            21*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 + 
            23*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
              2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
              magM[k3]^2) + 23*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) - 4*(2*dot[k1, k3] + 2*(dot[k1, k2] + 
                 dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
          4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
            magM[k3]^2)*(-7*magM[k1]^4 + 5*magM[k1]^2*(2*dot[k1, k3] + 
              2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
              magM[k3]^2) + 2*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, 
                  k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
          2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(-7*(2*dot[k1, k2] + magM[k1]^2 + 
               magM[k2]^2)^3 - 7*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^
              3 + 3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
             (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) + 3*(2*dot[k1, k3] + magM[k1]^2 + 
               magM[k3]^2)^2*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
              magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
            4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2 + 4*(2*dot[k1, k3] + magM[k1]^2 + 
              magM[k3]^2)*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
               magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
          magM[k1]^4*(35*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
             (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
            6*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2 + (2*dot[k1, k2] + magM[k1]^2 + 
              magM[k2]^2)*(35*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 - 
              58*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k1, k3] + 
                2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
                magM[k3]^2) - 6*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, 
                    k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2))) - 
        magM[k3]^4*(235*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
           (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
          3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(-7*magM[k1]^4 + 5*magM[k1]^2*
             (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) + 2*(2*dot[k1, k3] + 2*(dot[k1, k2] + 
                 dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
          (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
           (-21*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
            319*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
            (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (28*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
                magM[k1]^2 + magM[k3]^2) - 35*(2*dot[k1, k3] + magM[k1]^2 + 
                 magM[k3]^2)^2 - 212*(2*dot[k1, k3] + magM[k1]^2 + 
                magM[k3]^2)*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 6*(2*dot[k1, k3] + 
                 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
                 magM[k3]^2)^2))) + magM[k2]^4*
         (143*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
             magM[k3]^2)^2 + 3*magM[k3]^4*(2*dot[k2, k3] + magM[k2]^2 + 
            magM[k3]^2)*(-20*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
            7*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
          3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(7*magM[k1]^4 - 5*magM[k1]^2*
             (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) - 2*(2*dot[k1, k3] + 2*(dot[k1, k2] + 
                 dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
          magM[k3]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
           (120*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
            (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (76*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
              15*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2))) + 
          (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
           (-60*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
            32*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
            (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (35*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 - 
              6*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
                 magM[k2]^2 + magM[k3]^2)^2 + 2*(2*dot[k1, k2] + magM[k1]^2 + 
                magM[k2]^2)*(40*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
                83*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
                  magM[k1]^2 + magM[k2]^2 + magM[k3]^2))))) + 
        magM[k2]^2*(-2*magM[k3]^4*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
           (21*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
            (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (65*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
              33*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2))) - 
          (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
           (237*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
              magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^
                2)^2 + (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
              magM[k2]^2 + magM[k3]^2)*(202*magM[k1]^2 - 239*(2*dot[k1, k3] + 
                2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
                magM[k3]^2)) + 2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
              magM[k2]^2)*(65*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
              33*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
            (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
              magM[k1]^2 + magM[k3]^2)*(21*(2*dot[k1, k2] + magM[k1]^2 + 
                 magM[k2]^2)^2 - 150*(2*dot[k1, k3] + magM[k1]^2 + 
                 magM[k3]^2)^2 - 23*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
               (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
                magM[k2]^2 + magM[k3]^2) + 88*(2*dot[k1, k3] + magM[k1]^2 + 
                magM[k3]^2)*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 4*(2*dot[k1, k3] + 
                 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
                 magM[k3]^2)^2) + magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 
              magM[k3]^2)*(70*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 - 
              12*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
                 magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2 + (2*dot[k1, k2] + 
                magM[k1]^2 + magM[k2]^2)*(13*(2*dot[k1, k3] + magM[k1]^2 + 
                  magM[k3]^2) - 75*(2*dot[k1, k3] + 2*(dot[k1, k2] + 
                    dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)))) + 
          magM[k3]^2*(848*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
            6*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
              magM[k1]^2 + magM[k3]^2)*(-7*magM[k1]^4 + 5*magM[k1]^2*(
                2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
                magM[k2]^2 + magM[k3]^2) + 2*(2*dot[k1, k3] + 
                 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
                 magM[k3]^2)^2) + (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
             ((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
                magM[k1]^2 + magM[k3]^2)*(14*(2*dot[k1, k2] + magM[k1]^2 + 
                  magM[k2]^2) - 13*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^
                   2) - 843*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
                  magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 6*magM[k1]^2*(
                5*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k1, k3] + 
                  2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
                  magM[k3]^2) + (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
                 (236*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
                  22*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
                    magM[k1]^2 + magM[k2]^2 + magM[k3]^2)))))))/
       (1008*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2))))/
    (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
     magM[k2]^2 + magM[k3]^2))/6 + 
 ((f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]*(dot[k1, hat[z]] + dot[k2, hat[z]] + 
       dot[k3, hat[z]])^2)/(2*magM[k1]^2*magM[k2]^2) + 
   (f1*(dot[k1, hat[z]] + dot[k2, hat[z]])*(dot[k1, hat[z]] + 
      dot[k2, hat[z]] + dot[k3, hat[z]])*(-1 + dot[k1, k2]/magM[k2]^2 + 
      (9*magM[k1]^4 - 5*magM[k2]^4 - 11*magM[k1]^2*(2*dot[k1, k2] + 
          magM[k1]^2 + magM[k2]^2) + 2*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)^2 + 3*magM[k2]^2*(2*dot[k1, k2] + 9*magM[k1]^2 + 
          magM[k2]^2))/(14*magM[k1]^2*magM[k2]^2)))/
    (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
   (f1^3*dot[k1, hat[z]]*dot[k2, hat[z]]*dot[k3, hat[z]]*
     (dot[k1, hat[z]] + dot[k2, hat[z]] + dot[k3, hat[z]])^3)/
    (6*magM[k1]^2*magM[k2]^2*magM[k3]^2) - 
   ((-2*dot[k1, k3] - 2*dot[k2, k3])*(-5*magM[k1]^4 + 9*magM[k2]^4 + 
      3*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
      2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 + 
      magM[k2]^2*(24*magM[k1]^2 - 11*(2*dot[k1, k2] + magM[k1]^2 + 
          magM[k2]^2))))/(56*magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
   (f1^2*(dot[k1, hat[z]] + dot[k2, hat[z]])*dot[k3, hat[z]]*
     (dot[k1, hat[z]] + dot[k2, hat[z]] + dot[k3, hat[z]])^2*
     (-1 + dot[k1, k2]/magM[k2]^2 + (9*magM[k1]^4 - 5*magM[k2]^4 - 
        11*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
        2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 + 
        3*magM[k2]^2*(2*dot[k1, k2] + 9*magM[k1]^2 + magM[k2]^2))/
       (14*magM[k1]^2*magM[k2]^2)))/((2*dot[k1, k2] + magM[k1]^2 + 
      magM[k2]^2)*magM[k3]^2) + 
   (f1*dot[k2, hat[z]]*(dot[k1, hat[z]] + dot[k2, hat[z]] + dot[k3, hat[z]])*
     (dot[k1, k3]/magM[k1]^2 + (-5*magM[k1]^4 + 9*magM[k3]^4 - 
        11*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
        2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 + 
        3*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + 9*magM[k3]^2))/
       (28*magM[k1]^2*magM[k3]^2)))/magM[k2]^2 + 
   (3*magM[k1]^6 - 3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*magM[k3]^4 + 
     3*magM[k3]^6 + 14*magM[k2]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
     29*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*magM[k3]^2*
      (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
     magM[k3]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
     18*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 - 
     4*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 - 
     3*magM[k3]^4*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
     14*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
       magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
     magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
      (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
     4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*(2*dot[k2, k3] + 
       magM[k2]^2 + magM[k3]^2) - 3*magM[k1]^4*(2*dot[k1, k2] + 
       2*dot[k2, k3] + magM[k1]^2 + 2*magM[k2]^2 + 2*magM[k3]^2 - 
       5*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
     3*magM[k1]^2*(-magM[k3]^4 - 6*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^
         2 - 5*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
       (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*magM[k3]^2 - 
         5*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
       2*magM[k3]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2 + 
         5*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2))) + 
     2*magM[k2]^2*(3*magM[k1]^4 + 3*magM[k3]^4 + 15*magM[k3]^2*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
       magM[k1]^2*(-6*magM[k3]^2 + 15*(2*dot[k1, k3] + magM[k1]^2 + 
           magM[k3]^2)) - (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (7*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
         11*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
         7*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2))))/
    (112*magM[k1]^2*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
   (magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      (141*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2) + (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2)*(176*magM[k3]^2 - 
         139*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2)) - magM[k3]^4*(2*dot[k1, k3] + 
         magM[k1]^2 + magM[k3]^2)*(49*(2*dot[k2, k3] + magM[k2]^2 + 
           magM[k3]^2) + 15*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
           magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
       (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2)*(-21*(2*dot[k1, k3] + magM[k1]^2 + 
            magM[k3]^2)^2 + 42*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
         23*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k1, k3] + 
           2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
           magM[k3]^2) + 20*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) - 
         4*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + 2*magM[k3]^2*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
        (-35*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 + 
         7*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
           magM[k2]^2 + magM[k3]^2) + 24*(2*dot[k1, k3] + magM[k1]^2 + 
           magM[k3]^2)*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
           magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
         6*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2)) + 
     (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      (94*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^3*(2*dot[k1, k3] + 
         magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
       6*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*(2*dot[k1, k3] + 
         magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
        (25*magM[k3]^2 - 17*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
           magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
       magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
        (-21*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 - 
         21*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
         23*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k1, k3] + 
           2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
           magM[k3]^2) + 23*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) - 
         4*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + 4*(2*dot[k1, k2] + magM[k1]^2 + 
         magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(-7*magM[k3]^4 + 
         5*magM[k3]^2*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
           magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
         2*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + 2*(2*dot[k1, k3] + magM[k1]^2 + 
         magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
        (-7*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^3 - 
         7*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^3 + 
         3*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*(2*dot[k1, k3] + 
           2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
           magM[k3]^2) + 3*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2*
          (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) + 4*(2*dot[k1, k3] + magM[k1]^2 + 
           magM[k3]^2)*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
            magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2 + 
         4*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + magM[k3]^4*
        (35*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 - 
         6*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2 + (2*dot[k2, k3] + magM[k2]^2 + 
           magM[k3]^2)*(35*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 - 
           58*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k1, k3] + 
             2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
             magM[k3]^2) - 6*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
              magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2))) - 
     magM[k1]^4*(235*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2) + 3*(2*dot[k1, k3] + magM[k1]^2 + 
         magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
        (-7*magM[k3]^4 + 5*magM[k3]^2*(2*dot[k1, k3] + 
           2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
           magM[k3]^2) + 2*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
            magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
       (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (-21*magM[k3]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
         319*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
         (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          (-35*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 + 
           28*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
             magM[k2]^2 + magM[k3]^2) - 212*(2*dot[k1, k3] + magM[k1]^2 + 
             magM[k3]^2)*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
             magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
           6*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)^2))) + 
     magM[k2]^4*(143*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2) + 3*magM[k1]^4*(2*dot[k1, k2] + 
         magM[k1]^2 + magM[k2]^2)*(7*(2*dot[k1, k3] + magM[k1]^2 + 
           magM[k3]^2) - 20*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
       3*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2)*(7*magM[k3]^4 - 5*magM[k3]^2*
          (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) - 
         2*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + magM[k1]^2*(2*dot[k1, k2] + 
         magM[k1]^2 + magM[k2]^2)*(120*magM[k3]^2*(2*dot[k2, k3] + 
           magM[k2]^2 + magM[k3]^2) - (2*dot[k1, k3] + magM[k1]^2 + 
           magM[k3]^2)*(76*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
           15*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2))) + (2*dot[k1, k2] + magM[k1]^2 + 
         magM[k2]^2)*(-60*magM[k3]^4*(2*dot[k2, k3] + magM[k2]^2 + 
           magM[k3]^2) + 32*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + 
           magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
         (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (35*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 - 
           6*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)^2 + 2*(2*dot[k2, k3] + magM[k2]^2 + 
             magM[k3]^2)*(40*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
             83*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^
                2 + magM[k2]^2 + magM[k3]^2))))) + 
     magM[k2]^2*(-2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (21*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
         (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          (65*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
           33*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2))) - (2*dot[k1, k2] + magM[k1]^2 + 
         magM[k2]^2)*(237*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
          (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
           magM[k2]^2 + magM[k3]^2) + (2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(202*magM[k3]^2 - 
           239*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2)) + 2*magM[k3]^4*(2*dot[k2, k3] + 
           magM[k2]^2 + magM[k3]^2)*(65*(2*dot[k1, k3] + magM[k1]^2 + 
             magM[k3]^2) - 33*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, 
                k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
         (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
           magM[k2]^2 + magM[k3]^2)*(-150*(2*dot[k1, k3] + magM[k1]^2 + 
              magM[k3]^2)^2 + 21*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^
             2 + 88*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
            (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2) - 23*(2*dot[k2, k3] + magM[k2]^2 + 
             magM[k3]^2)*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
             magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
           4*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)^2) + magM[k3]^2*(2*dot[k1, k3] + 
           magM[k1]^2 + magM[k3]^2)*(70*(2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2)^2 - 12*(2*dot[k1, k3] + 2*(dot[k1, k2] + 
                dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2 + 
           (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
            (13*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
             75*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^
                2 + magM[k2]^2 + magM[k3]^2)))) + 
       magM[k1]^2*(848*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
          (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
           magM[k2]^2 + magM[k3]^2) + 6*(2*dot[k1, k3] + magM[k1]^2 + 
           magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          (-7*magM[k3]^4 + 5*magM[k3]^2*(2*dot[k1, k3] + 
             2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
             magM[k3]^2) + 2*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
              magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
         (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          ((2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
             magM[k2]^2 + magM[k3]^2)*(-13*(2*dot[k1, k3] + magM[k1]^2 + 
               magM[k3]^2) + 14*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
             843*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^
                2 + magM[k2]^2 + magM[k3]^2)) + 6*magM[k3]^2*
            (5*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k1, k3] + 2*
                (dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
               magM[k3]^2) + (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
              (236*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 22*
                (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
                 magM[k2]^2 + magM[k3]^2)))))))/(3024*magM[k1]^2*magM[k2]^2*
     (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*magM[k3]^2*
     (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
      magM[k3]^2)) + (f1*(dot[k1, hat[z]] + dot[k2, hat[z]] + 
       dot[k3, hat[z]])^2*(1 - (2*dot[k1, k3])/magM[k3]^2 - 
      ((-2*dot[k1, k3] - 2*dot[k2, k3])*(-5*magM[k1]^4 + 9*magM[k2]^4 + 
         3*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
         2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 + 
         magM[k2]^2*(24*magM[k1]^2 - 11*(2*dot[k1, k2] + magM[k1]^2 + 
             magM[k2]^2))))/(28*magM[k1]^2*magM[k2]^2*magM[k3]^2) - 
      (3*(24 - (5*magM[k2]^2)/magM[k1]^2 + 
         (3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2))/magM[k1]^2 + 
         (-5*magM[k1]^2 + 3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
           (2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2)/magM[k1]^2)/
          magM[k2]^2 + (14*magM[k1]^2)/magM[k3]^2 - 
         (14*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2))/magM[k3]^2))/28 + 
      (3*magM[k1]^6 - 3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
         magM[k3]^4 + 3*magM[k3]^6 + 14*magM[k2]^4*(2*dot[k1, k3] + 
          magM[k1]^2 + magM[k3]^2) - 29*(2*dot[k1, k2] + magM[k1]^2 + 
          magM[k2]^2)*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
        magM[k3]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
        18*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
         (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 - 
        4*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 - 
        3*magM[k3]^4*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
        14*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
          magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
          magM[k3]^2) - magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
         (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
        4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*(2*dot[k2, k3] + 
          magM[k2]^2 + magM[k3]^2) - 3*magM[k1]^4*(2*dot[k1, k2] + 
          2*dot[k2, k3] + magM[k1]^2 + 2*magM[k2]^2 + 2*magM[k3]^2 - 
          5*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
        3*magM[k1]^2*(-magM[k3]^4 - 6*(2*dot[k1, k3] + magM[k1]^2 + 
             magM[k3]^2)^2 - 5*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
           (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
          (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*magM[k3]^2 - 
            5*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
          2*magM[k3]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2 + 
            5*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2))) + 
        2*magM[k2]^2*(3*magM[k1]^4 + 3*magM[k3]^4 + 15*magM[k3]^2*
           (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
          magM[k1]^2*(-6*magM[k3]^2 + 15*(2*dot[k1, k3] + magM[k1]^2 + 
              magM[k3]^2)) - (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
           (7*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
            11*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
            7*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2))))/
       (112*magM[k1]^2*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + 
         magM[k3]^2)) + (magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
         (141*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
            magM[k3]^2) + (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2)*(176*magM[k3]^2 - 
            139*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)) - magM[k3]^4*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(49*(2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2) + 15*(2*dot[k1, k3] + 2*(dot[k1, k2] + 
                dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
          (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2)*(-21*(2*dot[k1, k3] + magM[k1]^2 + 
               magM[k3]^2)^2 + 42*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^
              2 + 23*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) + 20*(2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2)*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
              magM[k1]^2 + magM[k2]^2 + magM[k3]^2) - 
            4*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2) + 2*magM[k3]^2*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2)*(-35*(2*dot[k1, k3] + magM[k1]^2 + 
               magM[k3]^2)^2 + 7*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
            24*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k1, k3] + 
              2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
              magM[k3]^2) + 6*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, 
                  k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2)) + 
        (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
         (94*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^3*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
            magM[k3]^2) + 6*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
           (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2)*(25*magM[k3]^2 - 
            17*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)) + magM[k3]^2*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
            magM[k3]^2)*(-21*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 - 
            21*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
            23*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k1, k3] + 
              2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
              magM[k3]^2) + 23*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
             (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) - 4*(2*dot[k1, k3] + 2*(dot[k1, k2] + 
                 dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
          4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
            magM[k3]^2)*(-7*magM[k3]^4 + 5*magM[k3]^2*(2*dot[k1, k3] + 
              2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
              magM[k3]^2) + 2*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, 
                  k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
          2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2)*(-7*(2*dot[k1, k3] + magM[k1]^2 + 
               magM[k3]^2)^3 - 7*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^
              3 + 3*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*
             (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) + 3*(2*dot[k2, k3] + magM[k2]^2 + 
               magM[k3]^2)^2*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
              magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
            4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2 + 4*(2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2)*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
               magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
          magM[k3]^4*(35*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 - 
            6*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2 + (2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2)*(35*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 - 
              58*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k1, k3] + 
                2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
                magM[k3]^2) - 6*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, 
                    k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2))) - 
        magM[k1]^4*(235*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
           (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2) + 3*(2*dot[k1, k3] + magM[k1]^2 + 
            magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
           (-7*magM[k3]^4 + 5*magM[k3]^2*(2*dot[k1, k3] + 2*(dot[k1, k2] + 
                dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
            2*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2) + (2*dot[k1, k2] + magM[k1]^2 + 
            magM[k2]^2)*(-21*magM[k3]^4*(2*dot[k1, k3] + magM[k1]^2 + 
              magM[k3]^2) + 319*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + 
              magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
            (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
             (-35*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 + 
              28*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
                magM[k2]^2 + magM[k3]^2) - 212*(2*dot[k1, k3] + magM[k1]^2 + 
                magM[k3]^2)*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 6*(2*dot[k1, k3] + 
                 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
                 magM[k3]^2)^2))) + magM[k2]^4*
         (143*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
            magM[k3]^2) + 3*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
            magM[k2]^2)*(7*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
            20*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
          3*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2)*(7*magM[k3]^4 - 5*magM[k3]^2*
             (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) - 2*(2*dot[k1, k3] + 2*(dot[k1, k2] + 
                 dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
          magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (120*magM[k3]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
            (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (76*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
              15*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2))) + 
          (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (-60*magM[k3]^4*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
            32*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
            (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (35*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 - 
              6*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
                 magM[k2]^2 + magM[k3]^2)^2 + 2*(2*dot[k2, k3] + magM[k2]^2 + 
                magM[k3]^2)*(40*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
                83*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
                  magM[k1]^2 + magM[k2]^2 + magM[k3]^2))))) + 
        magM[k2]^2*(-2*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (21*magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
            (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
             (65*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
              33*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2))) - 
          (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (237*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*(2*dot[k1, k3] + 
              magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2) + (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
              magM[k2]^2 + magM[k3]^2)*(202*magM[k3]^2 - 239*(2*dot[k1, k3] + 
                2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
                magM[k3]^2)) + 2*magM[k3]^4*(2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2)*(65*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
              33*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
            (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
              magM[k2]^2 + magM[k3]^2)*(-150*(2*dot[k1, k3] + magM[k1]^2 + 
                 magM[k3]^2)^2 + 21*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^
                2 + 88*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(
                2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
                magM[k2]^2 + magM[k3]^2) - 23*(2*dot[k2, k3] + magM[k2]^2 + 
                magM[k3]^2)*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 4*(2*dot[k1, k3] + 
                 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
                 magM[k3]^2)^2) + magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + 
              magM[k3]^2)*(70*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 - 
              12*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
                 magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2 + (2*dot[k2, k3] + 
                magM[k2]^2 + magM[k3]^2)*(13*(2*dot[k1, k3] + magM[k1]^2 + 
                  magM[k3]^2) - 75*(2*dot[k1, k3] + 2*(dot[k1, k2] + 
                    dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)))) + 
          magM[k1]^2*(848*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
             (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
              magM[k2]^2 + magM[k3]^2) + 6*(2*dot[k1, k3] + magM[k1]^2 + 
              magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
             (-7*magM[k3]^4 + 5*magM[k3]^2*(2*dot[k1, k3] + 
                2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
                magM[k3]^2) + 2*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, 
                    k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
            (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             ((2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
                magM[k2]^2 + magM[k3]^2)*(-13*(2*dot[k1, k3] + magM[k1]^2 + 
                  magM[k3]^2) + 14*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^
                   2) - 843*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
                  magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 6*magM[k3]^2*(
                5*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k1, k3] + 
                  2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
                  magM[k3]^2) + (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
                 (236*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
                  22*(2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + 
                    magM[k1]^2 + magM[k2]^2 + magM[k3]^2)))))))/
       (1008*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2))))/
    (2*dot[k1, k3] + 2*(dot[k1, k2] + dot[k2, k3]) + magM[k1]^2 + 
     magM[k2]^2 + magM[k3]^2))/6 + 
 ((f1^2*dot[k2, hat[z]]*dot[k3, hat[z]]*(dot[k1, hat[z]] + dot[k2, hat[z]] + 
       dot[k3, hat[z]])^2)/(2*magM[k2]^2*magM[k3]^2) + 
   (f1^3*dot[k1, hat[z]]*dot[k2, hat[z]]*dot[k3, hat[z]]*
     (dot[k1, hat[z]] + dot[k2, hat[z]] + dot[k3, hat[z]])^3)/
    (6*magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
   (f1*dot[k3, hat[z]]*(dot[k1, hat[z]] + dot[k2, hat[z]] + dot[k3, hat[z]])*
     (dot[k1, k2]/magM[k2]^2 + (9*magM[k1]^4 - 5*magM[k2]^4 - 
        11*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
        2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 + 
        3*magM[k2]^2*(2*dot[k1, k2] + 9*magM[k1]^2 + magM[k2]^2))/
       (28*magM[k1]^2*magM[k2]^2)))/magM[k3]^2 - 
   ((-2*dot[k1, k2] - 2*dot[k1, k3])*(-5*magM[k2]^4 + 9*magM[k3]^4 + 
      3*magM[k2]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
      2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
      magM[k3]^2*(24*magM[k2]^2 - 11*(2*dot[k2, k3] + magM[k2]^2 + 
          magM[k3]^2))))/(56*magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
   (f1*(dot[k2, hat[z]] + dot[k3, hat[z]])*(dot[k1, hat[z]] + 
      dot[k2, hat[z]] + dot[k3, hat[z]])*(-1 + dot[k2, k3]/magM[k3]^2 + 
      (9*magM[k2]^4 - 5*magM[k3]^4 - 11*magM[k2]^2*(2*dot[k2, k3] + 
          magM[k2]^2 + magM[k3]^2) + 2*(2*dot[k2, k3] + magM[k2]^2 + 
           magM[k3]^2)^2 + 3*magM[k3]^2*(2*dot[k2, k3] + 9*magM[k2]^2 + 
          magM[k3]^2))/(14*magM[k2]^2*magM[k3]^2)))/
    (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
   (f1^2*dot[k1, hat[z]]*(dot[k2, hat[z]] + dot[k3, hat[z]])*
     (dot[k1, hat[z]] + dot[k2, hat[z]] + dot[k3, hat[z]])^2*
     (-1 + dot[k2, k3]/magM[k3]^2 + (9*magM[k2]^4 - 5*magM[k3]^4 - 
        11*magM[k2]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
        2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
        3*magM[k3]^2*(2*dot[k2, k3] + 9*magM[k2]^2 + magM[k3]^2))/
       (14*magM[k2]^2*magM[k3]^2)))/(magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + 
      magM[k3]^2)) + (3*magM[k1]^6 + 3*magM[k2]^6 + 
     magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
     4*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 + 
     14*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*magM[k3]^4 - 
     3*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
     magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
     4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*(2*dot[k1, k3] + 
       magM[k1]^2 + magM[k3]^2) - 3*magM[k1]^4*(2*dot[k2, k3] + magM[k2]^2 + 
       magM[k3]^2) - 29*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
     18*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
      (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
     14*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
       magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
     3*magM[k2]^4*(2*dot[k1, k3] + 2*dot[k2, k3] + 2*magM[k1]^2 + 
       magM[k2]^2 - 5*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
       2*magM[k3]^2) + 3*magM[k2]^2*(-magM[k1]^4 - 
       6*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 - 
       5*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
         magM[k1]^2 + magM[k3]^2) + (2*magM[k1]^2 - 
         5*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2))*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2) + 2*magM[k1]^2*(2*dot[k1, k3] + 
         magM[k1]^2 + 5*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
         magM[k3]^2)) + 2*magM[k3]^2*(3*magM[k1]^4 + 3*magM[k2]^4 + 
       15*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
       magM[k2]^2*(-6*magM[k1]^2 + 15*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)) - (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (11*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
         7*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
         7*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2))))/
    (112*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
   (magM[k2]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
      (141*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
         magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^
         2 + (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2)*(176*magM[k1]^2 - 
         139*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2)) - magM[k1]^4*(2*dot[k1, k2] + 
         magM[k1]^2 + magM[k2]^2)*(49*(2*dot[k1, k3] + magM[k1]^2 + 
           magM[k3]^2) + 15*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
           magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
       (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
         magM[k1]^2 + magM[k3]^2)*(-21*(2*dot[k1, k2] + magM[k1]^2 + 
            magM[k2]^2)^2 + 42*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 + 
         23*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k2] + 
           2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
           magM[k3]^2) + 20*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) - 
         4*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + 2*magM[k1]^2*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (-35*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 + 
         7*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
           magM[k1]^2 + magM[k3]^2) + 24*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
           magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
         6*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2)) + 
     (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
      (94*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
         magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^
         3 + 6*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2*(25*magM[k1]^2 - 
         17*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2)) + magM[k1]^2*(2*dot[k1, k2] + 
         magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (-21*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 - 
         21*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 + 
         23*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k2] + 
           2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
           magM[k3]^2) + 23*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) - 
         4*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + 4*(2*dot[k1, k2] + magM[k1]^2 + 
         magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(-7*magM[k1]^4 + 
         5*magM[k1]^2*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
           magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
         2*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + 2*(2*dot[k1, k2] + magM[k1]^2 + 
         magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (-7*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^3 - 
         7*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^3 + 
         3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*(2*dot[k1, k2] + 
           2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
           magM[k3]^2) + 3*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*
          (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) + 4*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
            magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2 + 
         4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + magM[k1]^4*
        (35*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 - 
         6*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2 + (2*dot[k1, k3] + magM[k1]^2 + 
           magM[k3]^2)*(35*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 - 
           58*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k2] + 
             2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
             magM[k3]^2) - 6*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
              magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2))) - 
     magM[k2]^4*(235*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
       3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
         magM[k1]^2 + magM[k3]^2)*(-7*magM[k1]^4 + 5*magM[k1]^2*
          (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) + 
         2*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + (2*dot[k2, k3] + magM[k2]^2 + 
         magM[k3]^2)*(-21*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2) + 319*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
         (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (-35*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 + 
           28*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
             magM[k1]^2 + magM[k3]^2) - 212*(2*dot[k1, k2] + magM[k1]^2 + 
             magM[k2]^2)*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
             magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
           6*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)^2))) + 
     magM[k3]^4*(143*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
       3*magM[k2]^4*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
        (7*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
         20*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
       3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
         magM[k1]^2 + magM[k3]^2)*(7*magM[k1]^4 - 5*magM[k1]^2*
          (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) - 
         2*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + magM[k2]^2*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2)*(120*magM[k1]^2*(2*dot[k1, k3] + 
           magM[k1]^2 + magM[k3]^2) - (2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)*(76*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
           15*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2))) + (2*dot[k2, k3] + magM[k2]^2 + 
         magM[k3]^2)*(-60*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
           magM[k3]^2) + 32*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
         (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (35*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 - 
           6*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)^2 + 2*(2*dot[k1, k3] + magM[k1]^2 + 
             magM[k3]^2)*(40*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
             83*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^
                2 + magM[k2]^2 + magM[k3]^2))))) + 
     magM[k3]^2*(-2*magM[k2]^4*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
        (21*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
         (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (65*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
           33*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2))) - (2*dot[k2, k3] + magM[k2]^2 + 
         magM[k3]^2)*(237*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
         (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
           magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          (202*magM[k1]^2 - 239*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, 
                k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
         2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (65*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
           33*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2)) + (2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (-150*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 + 
           21*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 + 
           88*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k2] + 
             2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
             magM[k3]^2) - 23*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
            (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2) + 4*(2*dot[k1, k2] + 2*(dot[k1, k3] + 
                dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
         magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (70*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 - 
           12*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)^2 + (2*dot[k1, k3] + magM[k1]^2 + 
             magM[k3]^2)*(13*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
             75*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^
                2 + magM[k2]^2 + magM[k3]^2)))) + 
       magM[k2]^2*(848*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
         6*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
           magM[k1]^2 + magM[k3]^2)*(-7*magM[k1]^4 + 5*magM[k1]^2*
            (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2) + 2*(2*dot[k1, k2] + 2*(dot[k1, k3] + 
                dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
         (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          ((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
             magM[k1]^2 + magM[k3]^2)*(-13*(2*dot[k1, k2] + magM[k1]^2 + 
               magM[k2]^2) + 14*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
             843*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^
                2 + magM[k2]^2 + magM[k3]^2)) + 6*magM[k1]^2*
            (5*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k2] + 2*
                (dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
               magM[k3]^2) + (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
              (236*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 22*
                (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
                 magM[k2]^2 + magM[k3]^2)))))))/(3024*magM[k1]^2*magM[k2]^2*
     (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*magM[k3]^2*
     (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
      magM[k3]^2)) + (f1*(dot[k1, hat[z]] + dot[k2, hat[z]] + 
       dot[k3, hat[z]])^2*(1 - (2*dot[k1, k2])/magM[k1]^2 - 
      ((-2*dot[k1, k2] - 2*dot[k1, k3])*(-5*magM[k2]^4 + 9*magM[k3]^4 + 
         3*magM[k2]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
         2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
         magM[k3]^2*(24*magM[k2]^2 - 11*(2*dot[k2, k3] + magM[k2]^2 + 
             magM[k3]^2))))/(28*magM[k1]^2*magM[k2]^2*magM[k3]^2) - 
      (3*(24 + (14*magM[k2]^2)/magM[k1]^2 - 
         (14*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2))/magM[k1]^2 - 
         (5*magM[k3]^2)/magM[k2]^2 + (3*(2*dot[k2, k3] + magM[k2]^2 + 
            magM[k3]^2))/magM[k2]^2 + (-5*magM[k2]^2 + 
           3*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
           (2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2)/magM[k2]^2)/
          magM[k3]^2))/28 + (3*magM[k1]^6 + 3*magM[k2]^6 + 
        magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
        4*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 + 
        14*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*magM[k3]^4 - 
        3*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
        magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
         (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
        4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*(2*dot[k1, k3] + 
          magM[k1]^2 + magM[k3]^2) - 3*magM[k1]^4*(2*dot[k2, k3] + 
          magM[k2]^2 + magM[k3]^2) - 29*magM[k1]^2*(2*dot[k1, k2] + 
          magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
          magM[k3]^2) + 18*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
         (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
        14*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
          magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
          magM[k3]^2) - 3*magM[k2]^4*(2*dot[k1, k3] + 2*dot[k2, k3] + 
          2*magM[k1]^2 + magM[k2]^2 - 5*(2*dot[k1, k2] + magM[k1]^2 + 
            magM[k2]^2) + 2*magM[k3]^2) + 3*magM[k2]^2*
         (-magM[k1]^4 - 6*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 - 
          5*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2) + (2*magM[k1]^2 - 
            5*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2))*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2) + 2*magM[k1]^2*(2*dot[k1, k3] + 
            magM[k1]^2 + 5*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
            magM[k3]^2)) + 2*magM[k3]^2*(3*magM[k1]^4 + 3*magM[k2]^4 + 
          15*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
          magM[k2]^2*(-6*magM[k1]^2 + 15*(2*dot[k1, k2] + magM[k1]^2 + 
              magM[k2]^2)) - (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (11*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
            7*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
            7*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2))))/
       (112*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + 
         magM[k2]^2)) + (magM[k2]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
         (141*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
             magM[k3]^2)^2 + (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2)*(176*magM[k1]^2 - 
            139*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)) - magM[k1]^4*(2*dot[k1, k2] + 
            magM[k1]^2 + magM[k2]^2)*(49*(2*dot[k1, k3] + magM[k1]^2 + 
              magM[k3]^2) + 15*(2*dot[k1, k2] + 2*(dot[k1, k3] + 
                dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
          (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(-21*(2*dot[k1, k2] + magM[k1]^2 + 
               magM[k2]^2)^2 + 42*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^
              2 + 23*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) + 20*(2*dot[k1, k3] + magM[k1]^2 + 
              magM[k3]^2)*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
              magM[k1]^2 + magM[k2]^2 + magM[k3]^2) - 
            4*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2) + 2*magM[k1]^2*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(-35*(2*dot[k1, k2] + magM[k1]^2 + 
               magM[k2]^2)^2 + 7*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
            24*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k2] + 
              2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
              magM[k3]^2) + 6*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, 
                  k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2)) + 
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
         (94*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
             magM[k3]^2)^3 + 6*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
           (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2*(25*magM[k1]^2 - 
            17*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)) + magM[k1]^2*(2*dot[k1, k2] + 
            magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + 
            magM[k3]^2)*(-21*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 - 
            21*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 + 
            23*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k2] + 
              2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
              magM[k3]^2) + 23*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) - 4*(2*dot[k1, k2] + 2*(dot[k1, k3] + 
                 dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
          4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
            magM[k3]^2)*(-7*magM[k1]^4 + 5*magM[k1]^2*(2*dot[k1, k2] + 
              2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
              magM[k3]^2) + 2*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, 
                  k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
          2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(-7*(2*dot[k1, k2] + magM[k1]^2 + 
               magM[k2]^2)^3 - 7*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^
              3 + 3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
             (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) + 3*(2*dot[k1, k3] + magM[k1]^2 + 
               magM[k3]^2)^2*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
              magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
            4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2 + 4*(2*dot[k1, k3] + magM[k1]^2 + 
              magM[k3]^2)*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
               magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
          magM[k1]^4*(35*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 - 
            6*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2 + (2*dot[k1, k3] + magM[k1]^2 + 
              magM[k3]^2)*(35*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 - 
              58*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k2] + 
                2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
                magM[k3]^2) - 6*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, 
                    k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2))) - 
        magM[k2]^4*(235*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
           (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
          3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(-7*magM[k1]^4 + 5*magM[k1]^2*
             (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) + 2*(2*dot[k1, k2] + 2*(dot[k1, k3] + 
                 dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
          (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
           (-21*magM[k1]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
            319*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
            (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (-35*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 + 
              28*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
                magM[k1]^2 + magM[k3]^2) - 212*(2*dot[k1, k2] + magM[k1]^2 + 
                magM[k2]^2)*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 6*(2*dot[k1, k2] + 
                 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
                 magM[k3]^2)^2))) + magM[k3]^4*
         (143*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
             magM[k3]^2)^2 + 3*magM[k2]^4*(2*dot[k2, k3] + magM[k2]^2 + 
            magM[k3]^2)*(7*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
            20*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
          3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(7*magM[k1]^4 - 5*magM[k1]^2*
             (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) - 2*(2*dot[k1, k2] + 2*(dot[k1, k3] + 
                 dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
          magM[k2]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
           (120*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
            (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (76*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
              15*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2))) + 
          (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
           (-60*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
            32*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
            (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (35*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 - 
              6*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
                 magM[k2]^2 + magM[k3]^2)^2 + 2*(2*dot[k1, k3] + magM[k1]^2 + 
                magM[k3]^2)*(40*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
                83*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
                  magM[k1]^2 + magM[k2]^2 + magM[k3]^2))))) + 
        magM[k3]^2*(-2*magM[k2]^4*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
           (21*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
            (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (65*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
              33*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2))) - 
          (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
           (237*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
              magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^
                2)^2 + (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
              magM[k2]^2 + magM[k3]^2)*(202*magM[k1]^2 - 239*(2*dot[k1, k2] + 
                2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
                magM[k3]^2)) + 2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + 
              magM[k3]^2)*(65*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
              33*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
            (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
              magM[k1]^2 + magM[k3]^2)*(-150*(2*dot[k1, k2] + magM[k1]^2 + 
                 magM[k2]^2)^2 + 21*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^
                2 + 88*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(
                2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
                magM[k2]^2 + magM[k3]^2) - 23*(2*dot[k1, k3] + magM[k1]^2 + 
                magM[k3]^2)*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 4*(2*dot[k1, k2] + 
                 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
                 magM[k3]^2)^2) + magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 
              magM[k2]^2)*(70*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 - 
              12*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
                 magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2 + (2*dot[k1, k3] + 
                magM[k1]^2 + magM[k3]^2)*(13*(2*dot[k1, k2] + magM[k1]^2 + 
                  magM[k2]^2) - 75*(2*dot[k1, k2] + 2*(dot[k1, k3] + 
                    dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)))) + 
          magM[k2]^2*(848*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
            6*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
              magM[k1]^2 + magM[k3]^2)*(-7*magM[k1]^4 + 5*magM[k1]^2*(
                2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
                magM[k2]^2 + magM[k3]^2) + 2*(2*dot[k1, k2] + 
                 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
                 magM[k3]^2)^2) + (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
             ((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
                magM[k1]^2 + magM[k3]^2)*(-13*(2*dot[k1, k2] + magM[k1]^2 + 
                  magM[k2]^2) + 14*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^
                   2) - 843*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
                  magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 6*magM[k1]^2*(
                5*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k2] + 
                  2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
                  magM[k3]^2) + (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
                 (236*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
                  22*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
                    magM[k1]^2 + magM[k2]^2 + magM[k3]^2)))))))/
       (1008*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2))))/
    (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
     magM[k2]^2 + magM[k3]^2))/6 + 
 ((f1^2*dot[k1, hat[z]]*dot[k3, hat[z]]*(dot[k1, hat[z]] + dot[k2, hat[z]] + 
       dot[k3, hat[z]])^2)/(2*magM[k1]^2*magM[k3]^2) + 
   (f1^3*dot[k1, hat[z]]*dot[k2, hat[z]]*dot[k3, hat[z]]*
     (dot[k1, hat[z]] + dot[k2, hat[z]] + dot[k3, hat[z]])^3)/
    (6*magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
   (f1*dot[k3, hat[z]]*(dot[k1, hat[z]] + dot[k2, hat[z]] + dot[k3, hat[z]])*
     (dot[k1, k2]/magM[k1]^2 + (-5*magM[k1]^4 + 9*magM[k2]^4 - 
        11*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
        2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 + 
        3*magM[k1]^2*(2*dot[k1, k2] + magM[k1]^2 + 9*magM[k2]^2))/
       (28*magM[k1]^2*magM[k2]^2)))/magM[k3]^2 - 
   ((-2*dot[k1, k2] - 2*dot[k2, k3])*(-5*magM[k1]^4 + 9*magM[k3]^4 + 
      3*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
      2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 + 
      magM[k3]^2*(24*magM[k1]^2 - 11*(2*dot[k1, k3] + magM[k1]^2 + 
          magM[k3]^2))))/(56*magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
   (f1*(dot[k1, hat[z]] + dot[k3, hat[z]])*(dot[k1, hat[z]] + 
      dot[k2, hat[z]] + dot[k3, hat[z]])*(-1 + dot[k1, k3]/magM[k3]^2 + 
      (9*magM[k1]^4 - 5*magM[k3]^4 - 11*magM[k1]^2*(2*dot[k1, k3] + 
          magM[k1]^2 + magM[k3]^2) + 2*(2*dot[k1, k3] + magM[k1]^2 + 
           magM[k3]^2)^2 + 3*magM[k3]^2*(2*dot[k1, k3] + 9*magM[k1]^2 + 
          magM[k3]^2))/(14*magM[k1]^2*magM[k3]^2)))/
    (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
   (f1^2*dot[k2, hat[z]]*(dot[k1, hat[z]] + dot[k3, hat[z]])*
     (dot[k1, hat[z]] + dot[k2, hat[z]] + dot[k3, hat[z]])^2*
     (-1 + dot[k1, k3]/magM[k3]^2 + (9*magM[k1]^4 - 5*magM[k3]^4 - 
        11*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
        2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 + 
        3*magM[k3]^2*(2*dot[k1, k3] + 9*magM[k1]^2 + magM[k3]^2))/
       (14*magM[k1]^2*magM[k3]^2)))/(magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + 
      magM[k3]^2)) + (3*magM[k1]^6 + 3*magM[k2]^6 + 
     magM[k2]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
     4*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 + 
     14*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*magM[k3]^4 - 
     3*magM[k2]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
     29*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
     18*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
      (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
     3*magM[k2]^4*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
     magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
     4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*(2*dot[k2, k3] + 
       magM[k2]^2 + magM[k3]^2) + 14*(2*dot[k1, k2] + magM[k1]^2 + 
       magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
      (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
     3*magM[k1]^4*(2*dot[k1, k3] + 2*dot[k2, k3] + magM[k1]^2 + 
       2*magM[k2]^2 - 5*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
       2*magM[k3]^2) + 3*magM[k1]^2*(-magM[k2]^4 - 
       6*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 + 
       (2*magM[k2]^2 - 5*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2))*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
       5*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2) + 2*magM[k2]^2*(2*dot[k2, k3] + 
         magM[k2]^2 + 5*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
         magM[k3]^2)) + 2*magM[k3]^2*(3*magM[k1]^4 + 3*magM[k2]^4 + 
       15*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
       magM[k1]^2*(-6*magM[k2]^2 + 15*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)) - (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (11*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
         7*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
         7*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2))))/
    (112*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)) + 
   (magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
      (141*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2) + (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2)*(176*magM[k2]^2 - 
         139*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2)) - magM[k2]^4*(2*dot[k1, k2] + 
         magM[k1]^2 + magM[k2]^2)*(49*(2*dot[k2, k3] + magM[k2]^2 + 
           magM[k3]^2) + 15*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
           magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
       (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2)*(-21*(2*dot[k1, k2] + magM[k1]^2 + 
            magM[k2]^2)^2 + 42*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
         23*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k2] + 
           2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
           magM[k3]^2) + 20*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) - 
         4*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + 2*magM[k2]^2*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
        (-35*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 + 
         7*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
           magM[k2]^2 + magM[k3]^2) + 24*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
           magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
         6*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2)) + 
     (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
      (94*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^3*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2) + 6*(2*dot[k1, k2] + magM[k1]^2 + 
         magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(25*magM[k2]^2 - 
         17*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2)) + magM[k2]^2*(2*dot[k1, k2] + 
         magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
        (-21*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 - 
         21*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
         23*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k2] + 
           2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
           magM[k3]^2) + 23*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) - 
         4*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + 4*(2*dot[k1, k2] + magM[k1]^2 + 
         magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(-7*magM[k2]^4 + 
         5*magM[k2]^2*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
           magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
         2*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + 2*(2*dot[k1, k2] + magM[k1]^2 + 
         magM[k2]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
        (-7*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^3 - 
         7*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^3 + 
         3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*(2*dot[k1, k2] + 
           2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
           magM[k3]^2) + 3*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2*
          (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) + 4*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
            magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2 + 
         4*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + magM[k2]^4*
        (35*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 - 
         6*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2 + (2*dot[k2, k3] + magM[k2]^2 + 
           magM[k3]^2)*(35*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 - 
           58*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k2] + 
             2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
             magM[k3]^2) - 6*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
              magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2))) - 
     magM[k1]^4*(235*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2) + 3*(2*dot[k1, k2] + magM[k1]^2 + 
         magM[k2]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
        (-7*magM[k2]^4 + 5*magM[k2]^2*(2*dot[k1, k2] + 
           2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
           magM[k3]^2) + 2*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
            magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
       (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (-21*magM[k2]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
         319*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
         (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          (-35*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 + 
           28*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
             magM[k2]^2 + magM[k3]^2) - 212*(2*dot[k1, k2] + magM[k1]^2 + 
             magM[k2]^2)*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
             magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
           6*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)^2))) + 
     magM[k3]^4*(143*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2) + 3*magM[k1]^4*(2*dot[k1, k3] + 
         magM[k1]^2 + magM[k3]^2)*(7*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2) - 20*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
       3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
         magM[k2]^2 + magM[k3]^2)*(7*magM[k2]^4 - 5*magM[k2]^2*
          (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
           magM[k2]^2 + magM[k3]^2) - 
         2*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
            magM[k2]^2 + magM[k3]^2)^2) + magM[k1]^2*(2*dot[k1, k3] + 
         magM[k1]^2 + magM[k3]^2)*(120*magM[k2]^2*(2*dot[k2, k3] + 
           magM[k2]^2 + magM[k3]^2) - (2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)*(76*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
           15*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2))) + (2*dot[k1, k3] + magM[k1]^2 + 
         magM[k3]^2)*(-60*magM[k2]^4*(2*dot[k2, k3] + magM[k2]^2 + 
           magM[k3]^2) + 32*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
         (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (35*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 - 
           6*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)^2 + 2*(2*dot[k2, k3] + magM[k2]^2 + 
             magM[k3]^2)*(40*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
             83*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^
                2 + magM[k2]^2 + magM[k3]^2))))) + 
     magM[k3]^2*(-2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (21*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
         (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          (65*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
           33*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2))) - (2*dot[k1, k3] + magM[k1]^2 + 
         magM[k3]^2)*(237*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*(2*dot[k2, k3] + 
           magM[k2]^2 + magM[k3]^2) + (2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(202*magM[k2]^2 - 
           239*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2)) + 2*magM[k2]^4*(2*dot[k2, k3] + 
           magM[k2]^2 + magM[k3]^2)*(65*(2*dot[k1, k2] + magM[k1]^2 + 
             magM[k2]^2) - 33*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, 
                k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
         (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
           magM[k2]^2 + magM[k3]^2)*(-150*(2*dot[k1, k2] + magM[k1]^2 + 
              magM[k2]^2)^2 + 21*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^
             2 + 88*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
            (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
             magM[k2]^2 + magM[k3]^2) - 23*(2*dot[k2, k3] + magM[k2]^2 + 
             magM[k3]^2)*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
             magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
           4*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)^2) + magM[k2]^2*(2*dot[k1, k2] + 
           magM[k1]^2 + magM[k2]^2)*(70*(2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2)^2 - 12*(2*dot[k1, k2] + 2*(dot[k1, k3] + 
                dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2 + 
           (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
            (13*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
             75*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^
                2 + magM[k2]^2 + magM[k3]^2)))) + 
       magM[k1]^2*(848*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
          (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*(2*dot[k2, k3] + 
           magM[k2]^2 + magM[k3]^2) + 6*(2*dot[k1, k2] + magM[k1]^2 + 
           magM[k2]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
          (-7*magM[k2]^4 + 5*magM[k2]^2*(2*dot[k1, k2] + 
             2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
             magM[k3]^2) + 2*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
              magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
         (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
          ((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
             magM[k2]^2 + magM[k3]^2)*(-13*(2*dot[k1, k2] + magM[k1]^2 + 
               magM[k2]^2) + 14*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
             843*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^
                2 + magM[k2]^2 + magM[k3]^2)) + 6*magM[k2]^2*
            (5*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k2] + 2*
                (dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
               magM[k3]^2) + (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
              (236*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 22*
                (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
                 magM[k2]^2 + magM[k3]^2)))))))/(3024*magM[k1]^2*magM[k2]^2*
     (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*magM[k3]^2*
     (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
      magM[k3]^2)) + (f1*(dot[k1, hat[z]] + dot[k2, hat[z]] + 
       dot[k3, hat[z]])^2*(1 - (2*dot[k1, k2])/magM[k2]^2 - 
      ((-2*dot[k1, k2] - 2*dot[k2, k3])*(-5*magM[k1]^4 + 9*magM[k3]^4 + 
         3*magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
         2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2 + 
         magM[k3]^2*(24*magM[k1]^2 - 11*(2*dot[k1, k3] + magM[k1]^2 + 
             magM[k3]^2))))/(28*magM[k1]^2*magM[k2]^2*magM[k3]^2) - 
      (3*(24 + (14*magM[k1]^2)/magM[k2]^2 - 
         (14*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2))/magM[k2]^2 - 
         (5*magM[k3]^2)/magM[k1]^2 + (3*(2*dot[k1, k3] + magM[k1]^2 + 
            magM[k3]^2))/magM[k1]^2 + (-5*magM[k1]^2 + 
           3*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
           (2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2)/magM[k1]^2)/
          magM[k3]^2))/28 + (3*magM[k1]^6 + 3*magM[k2]^6 + 
        magM[k2]^4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
        4*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 + 
        14*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*magM[k3]^4 - 
        3*magM[k2]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
        29*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
         (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
        18*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*(2*dot[k1, k3] + 
          magM[k1]^2 + magM[k3]^2) - 3*magM[k2]^4*(2*dot[k2, k3] + 
          magM[k2]^2 + magM[k3]^2) - magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + 
          magM[k2]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
        4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*(2*dot[k2, k3] + 
          magM[k2]^2 + magM[k3]^2) + 14*(2*dot[k1, k2] + magM[k1]^2 + 
          magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
         (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
        3*magM[k1]^4*(2*dot[k1, k3] + 2*dot[k2, k3] + magM[k1]^2 + 
          2*magM[k2]^2 - 5*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
          2*magM[k3]^2) + 3*magM[k1]^2*(-magM[k2]^4 - 
          6*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 + 
          (2*magM[k2]^2 - 5*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2))*
           (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) - 
          5*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2) + 2*magM[k2]^2*(2*dot[k2, k3] + 
            magM[k2]^2 + 5*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
            magM[k3]^2)) + 2*magM[k3]^2*(3*magM[k1]^4 + 3*magM[k2]^4 + 
          15*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
          magM[k1]^2*(-6*magM[k2]^2 + 15*(2*dot[k1, k2] + magM[k1]^2 + 
              magM[k2]^2)) - (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (11*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
            7*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2) + 
            7*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2))))/
       (112*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + 
         magM[k2]^2)) + (magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
         (141*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2) + (2*dot[k1, k2] + magM[k1]^2 + 
            magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
           (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(176*magM[k2]^2 - 
            139*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)) - magM[k2]^4*(2*dot[k1, k2] + 
            magM[k1]^2 + magM[k2]^2)*(49*(2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2) + 15*(2*dot[k1, k2] + 2*(dot[k1, k3] + 
                dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
          (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2)*(-21*(2*dot[k1, k2] + magM[k1]^2 + 
               magM[k2]^2)^2 + 42*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^
              2 + 23*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) + 20*(2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2)*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
              magM[k1]^2 + magM[k2]^2 + magM[k3]^2) - 
            4*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2) + 2*magM[k2]^2*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2)*(-35*(2*dot[k1, k2] + magM[k1]^2 + 
               magM[k2]^2)^2 + 7*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
            24*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k2] + 
              2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
              magM[k3]^2) + 6*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, 
                  k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2)) + 
        (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
         (94*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^3*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2) + 6*(2*dot[k1, k2] + magM[k1]^2 + 
            magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*
           (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(25*magM[k2]^2 - 
            17*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2)) + magM[k2]^2*(2*dot[k1, k2] + 
            magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
            magM[k3]^2)*(-21*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 - 
            21*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 + 
            23*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k2] + 
              2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
              magM[k3]^2) + 23*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
             (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) - 4*(2*dot[k1, k2] + 2*(dot[k1, k3] + 
                 dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
          4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(2*dot[k2, k3] + magM[k2]^2 + 
            magM[k3]^2)*(-7*magM[k2]^4 + 5*magM[k2]^2*(2*dot[k1, k2] + 
              2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
              magM[k3]^2) + 2*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, 
                  k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
          2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2)*(-7*(2*dot[k1, k2] + magM[k1]^2 + 
               magM[k2]^2)^3 - 7*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^
              3 + 3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2*
             (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) + 3*(2*dot[k2, k3] + magM[k2]^2 + 
               magM[k3]^2)^2*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
              magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
            4*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2 + 4*(2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2)*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
               magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
          magM[k2]^4*(35*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 - 
            6*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2 + (2*dot[k2, k3] + magM[k2]^2 + 
              magM[k3]^2)*(35*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 - 
              58*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k2] + 
                2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
                magM[k3]^2) - 6*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, 
                    k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2))) - 
        magM[k1]^4*(235*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2) + 3*(2*dot[k1, k2] + magM[k1]^2 + 
            magM[k2]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
           (-7*magM[k2]^4 + 5*magM[k2]^2*(2*dot[k1, k2] + 2*(dot[k1, k3] + 
                dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 
            2*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
               magM[k2]^2 + magM[k3]^2)^2) + (2*dot[k1, k3] + magM[k1]^2 + 
            magM[k3]^2)*(-21*magM[k2]^4*(2*dot[k1, k2] + magM[k1]^2 + 
              magM[k2]^2) + 319*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + 
              magM[k2]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
            (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
             (-35*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)^2 + 
              28*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
                magM[k2]^2 + magM[k3]^2) - 212*(2*dot[k1, k2] + magM[k1]^2 + 
                magM[k2]^2)*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 6*(2*dot[k1, k2] + 
                 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
                 magM[k3]^2)^2))) + magM[k3]^4*
         (143*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
           (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2) + 3*magM[k1]^4*(2*dot[k1, k3] + 
            magM[k1]^2 + magM[k3]^2)*(7*(2*dot[k1, k2] + magM[k1]^2 + 
              magM[k2]^2) - 20*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
          3*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
            magM[k2]^2 + magM[k3]^2)*(7*magM[k2]^4 - 5*magM[k2]^2*
             (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
              magM[k2]^2 + magM[k3]^2) - 2*(2*dot[k1, k2] + 2*(dot[k1, k3] + 
                 dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
          magM[k1]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
           (120*magM[k2]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) - 
            (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (76*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
              15*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2))) + 
          (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
           (-60*magM[k2]^4*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
            32*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2) + 
            (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (35*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 - 
              6*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
                 magM[k2]^2 + magM[k3]^2)^2 + 2*(2*dot[k2, k3] + magM[k2]^2 + 
                magM[k3]^2)*(40*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
                83*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
                  magM[k1]^2 + magM[k2]^2 + magM[k3]^2))))) + 
        magM[k3]^2*(-2*magM[k1]^4*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
           (21*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) + 
            (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
             (65*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
              33*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2))) - 
          (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
           (237*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*(2*dot[k2, k3] + 
              magM[k2]^2 + magM[k3]^2) + (2*dot[k1, k2] + magM[k1]^2 + 
              magM[k2]^2)*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*(202*magM[k2]^2 - 
              239*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 2*magM[k2]^4*
             (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
             (65*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
              33*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 
            (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
              magM[k2]^2 + magM[k3]^2)*(-150*(2*dot[k1, k2] + magM[k1]^2 + 
                 magM[k2]^2)^2 + 21*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^
                2 + 88*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(
                2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
                magM[k2]^2 + magM[k3]^2) - 23*(2*dot[k2, k3] + magM[k2]^2 + 
                magM[k3]^2)*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
                magM[k1]^2 + magM[k2]^2 + magM[k3]^2) + 4*(2*dot[k1, k2] + 
                 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
                 magM[k3]^2)^2) + magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + 
              magM[k2]^2)*(70*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)^2 - 
              12*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
                 magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2 + (2*dot[k2, k3] + 
                magM[k2]^2 + magM[k3]^2)*(13*(2*dot[k1, k2] + magM[k1]^2 + 
                  magM[k2]^2) - 75*(2*dot[k1, k2] + 2*(dot[k1, k3] + 
                    dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)))) + 
          magM[k1]^2*(848*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
             (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)^2*(2*dot[k2, k3] + 
              magM[k2]^2 + magM[k3]^2) + 6*(2*dot[k1, k2] + magM[k1]^2 + 
              magM[k2]^2)*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
             (-7*magM[k2]^4 + 5*magM[k2]^2*(2*dot[k1, k2] + 
                2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
                magM[k3]^2) + 2*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, 
                    k3]) + magM[k1]^2 + magM[k2]^2 + magM[k3]^2)^2) + 
            (2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
             ((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k2, k3] + 
                magM[k2]^2 + magM[k3]^2)*(-13*(2*dot[k1, k2] + magM[k1]^2 + 
                  magM[k2]^2) + 14*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^
                   2) - 843*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
                  magM[k1]^2 + magM[k2]^2 + magM[k3]^2)) + 6*magM[k2]^2*(
                5*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*(2*dot[k1, k2] + 
                  2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + magM[k2]^2 + 
                  magM[k3]^2) + (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)*
                 (236*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2) - 
                  22*(2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + 
                    magM[k1]^2 + magM[k2]^2 + magM[k3]^2)))))))/
       (1008*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
        magM[k3]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)*
        (2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2))))/
    (2*dot[k1, k2] + 2*(dot[k1, k3] + dot[k2, k3]) + magM[k1]^2 + 
     magM[k2]^2 + magM[k3]^2))/6
