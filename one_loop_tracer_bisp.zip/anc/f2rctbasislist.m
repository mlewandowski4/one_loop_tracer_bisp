(* Created with the Wolfram Language : www.wolfram.com *)
{-1/2772*(448*dot[k1, k2]^3*magM[k1]^2 + 896*f1*dot[k1, k2]^2*
     dot[k1, hat[z]]^2*magM[k1]^2 + 1792*f1*dot[k1, k2]^2*dot[k1, hat[z]]*
     dot[k2, hat[z]]*magM[k1]^2 + 924*f1^2*dot[k1, k2]*dot[k1, hat[z]]^3*
     dot[k2, hat[z]]*magM[k1]^2 + 896*f1*dot[k1, k2]^2*dot[k2, hat[z]]^2*
     magM[k1]^2 + 1848*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
     magM[k1]^2 + 924*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]^3*
     magM[k1]^2 + 532*dot[k1, k2]^2*magM[k1]^4 + 
    462*f1*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^4 + 
    1232*f1*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^4 + 
    462*f1^2*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k1]^4 + 
    770*f1*dot[k1, k2]*dot[k2, hat[z]]^2*magM[k1]^4 + 
    924*f1^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^4 + 
    462*f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k1]^4 + 
    154*dot[k1, k2]*magM[k1]^6 + 154*f1*dot[k1, hat[z]]*dot[k2, hat[z]]*
     magM[k1]^6 + 154*f1*dot[k2, hat[z]]^2*magM[k1]^6 + 
    448*dot[k1, k2]^3*magM[k2]^2 + 896*f1*dot[k1, k2]^2*dot[k1, hat[z]]^2*
     magM[k2]^2 + 1792*f1*dot[k1, k2]^2*dot[k1, hat[z]]*dot[k2, hat[z]]*
     magM[k2]^2 + 924*f1^2*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
     magM[k2]^2 + 896*f1*dot[k1, k2]^2*dot[k2, hat[z]]^2*magM[k2]^2 + 
    1848*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k2]^2 + 
    924*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k2]^2 + 
    1064*dot[k1, k2]^2*magM[k1]^2*magM[k2]^2 + 1232*f1*dot[k1, k2]*
     dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2 + 2464*f1*dot[k1, k2]*
     dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*magM[k2]^2 + 
    924*f1^2*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k1]^2*magM[k2]^2 + 
    1232*f1*dot[k1, k2]*dot[k2, hat[z]]^2*magM[k1]^2*magM[k2]^2 + 
    1848*f1^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^2*magM[k2]^2 + 
    924*f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k1]^2*magM[k2]^2 + 
    630*dot[k1, k2]*magM[k1]^4*magM[k2]^2 + 182*f1*dot[k1, hat[z]]^2*
     magM[k1]^4*magM[k2]^2 + 518*f1*dot[k1, hat[z]]*dot[k2, hat[z]]*
     magM[k1]^4*magM[k2]^2 + 336*f1*dot[k2, hat[z]]^2*magM[k1]^4*magM[k2]^2 + 
    84*magM[k1]^6*magM[k2]^2 + 532*dot[k1, k2]^2*magM[k2]^4 + 
    770*f1*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k2]^4 + 
    1232*f1*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^4 + 
    462*f1^2*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^4 + 
    462*f1*dot[k1, k2]*dot[k2, hat[z]]^2*magM[k2]^4 + 
    924*f1^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k2]^4 + 
    462*f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k2]^4 + 
    630*dot[k1, k2]*magM[k1]^2*magM[k2]^4 + 336*f1*dot[k1, hat[z]]^2*
     magM[k1]^2*magM[k2]^4 + 518*f1*dot[k1, hat[z]]*dot[k2, hat[z]]*
     magM[k1]^2*magM[k2]^4 + 182*f1*dot[k2, hat[z]]^2*magM[k1]^2*magM[k2]^4 + 
    168*magM[k1]^4*magM[k2]^4 + 154*dot[k1, k2]*magM[k2]^6 + 
    154*f1*dot[k1, hat[z]]^2*magM[k2]^6 + 154*f1*dot[k1, hat[z]]*
     dot[k2, hat[z]]*magM[k2]^6 + 84*magM[k1]^2*magM[k2]^6)/
   (knl^2*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)), 
 -1/2772*(192*dot[k1, k2]^4 + 384*f1*dot[k1, k2]^3*dot[k1, hat[z]]^2 + 
    768*f1*dot[k1, k2]^3*dot[k1, hat[z]]*dot[k2, hat[z]] + 
    384*f1*dot[k1, k2]^3*dot[k2, hat[z]]^2 + 192*dot[k1, k2]^3*magM[k1]^2 + 
    192*f1*dot[k1, k2]^2*dot[k1, hat[z]]^2*magM[k1]^2 + 
    384*f1*dot[k1, k2]^2*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2 + 
    192*f1*dot[k1, k2]^2*dot[k2, hat[z]]^2*magM[k1]^2 + 
    48*dot[k1, k2]^2*magM[k1]^4 + 192*dot[k1, k2]^3*magM[k2]^2 + 
    192*f1*dot[k1, k2]^2*dot[k1, hat[z]]^2*magM[k2]^2 + 
    384*f1*dot[k1, k2]^2*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2 + 
    192*f1*dot[k1, k2]^2*dot[k2, hat[z]]^2*magM[k2]^2 + 
    576*dot[k1, k2]^2*magM[k1]^2*magM[k2]^2 + 960*f1*dot[k1, k2]*
     dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2 + 1920*f1*dot[k1, k2]*
     dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*magM[k2]^2 + 
    960*f1*dot[k1, k2]*dot[k2, hat[z]]^2*magM[k1]^2*magM[k2]^2 + 
    480*dot[k1, k2]*magM[k1]^4*magM[k2]^2 + 480*f1*dot[k1, hat[z]]^2*
     magM[k1]^4*magM[k2]^2 + 960*f1*dot[k1, hat[z]]*dot[k2, hat[z]]*
     magM[k1]^4*magM[k2]^2 + 480*f1*dot[k2, hat[z]]^2*magM[k1]^4*magM[k2]^2 + 
    120*magM[k1]^6*magM[k2]^2 + 48*dot[k1, k2]^2*magM[k2]^4 + 
    480*dot[k1, k2]*magM[k1]^2*magM[k2]^4 + 480*f1*dot[k1, hat[z]]^2*
     magM[k1]^2*magM[k2]^4 + 960*f1*dot[k1, hat[z]]*dot[k2, hat[z]]*
     magM[k1]^2*magM[k2]^4 + 480*f1*dot[k2, hat[z]]^2*magM[k1]^2*magM[k2]^4 + 
    240*magM[k1]^4*magM[k2]^4 + 120*magM[k1]^2*magM[k2]^6)/
   (knl^2*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)), 
 -1/2772*(168*dot[k1, k2]^3*magM[k1]^2 + 28*f1*dot[k1, k2]^2*
     dot[k1, hat[z]]^2*magM[k1]^2 + 672*f1*dot[k1, k2]^2*dot[k1, hat[z]]*
     dot[k2, hat[z]]*magM[k1]^2 + 644*f1*dot[k1, k2]^2*dot[k2, hat[z]]^2*
     magM[k1]^2 + 84*dot[k1, k2]^2*magM[k1]^4 + 308*f1*dot[k1, k2]*
     dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^4 + 
    308*f1*dot[k1, k2]*dot[k2, hat[z]]^2*magM[k1]^4 + 
    168*dot[k1, k2]^3*magM[k2]^2 + 644*f1*dot[k1, k2]^2*dot[k1, hat[z]]^2*
     magM[k2]^2 + 672*f1*dot[k1, k2]^2*dot[k1, hat[z]]*dot[k2, hat[z]]*
     magM[k2]^2 + 28*f1*dot[k1, k2]^2*dot[k2, hat[z]]^2*magM[k2]^2 + 
    840*dot[k1, k2]^2*magM[k1]^2*magM[k2]^2 + 1036*f1*dot[k1, k2]*
     dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2 + 2072*f1*dot[k1, k2]*
     dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*magM[k2]^2 + 
    1036*f1*dot[k1, k2]*dot[k2, hat[z]]^2*magM[k1]^2*magM[k2]^2 + 
    504*dot[k1, k2]*magM[k1]^4*magM[k2]^2 + 336*f1*dot[k1, hat[z]]^2*
     magM[k1]^4*magM[k2]^2 + 672*f1*dot[k1, hat[z]]*dot[k2, hat[z]]*
     magM[k1]^4*magM[k2]^2 + 336*f1*dot[k2, hat[z]]^2*magM[k1]^4*magM[k2]^2 + 
    84*magM[k1]^6*magM[k2]^2 + 84*dot[k1, k2]^2*magM[k2]^4 + 
    308*f1*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k2]^4 + 
    308*f1*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^4 + 
    504*dot[k1, k2]*magM[k1]^2*magM[k2]^4 + 336*f1*dot[k1, hat[z]]^2*
     magM[k1]^2*magM[k2]^4 + 672*f1*dot[k1, hat[z]]*dot[k2, hat[z]]*
     magM[k1]^2*magM[k2]^4 + 336*f1*dot[k2, hat[z]]^2*magM[k1]^2*magM[k2]^4 + 
    168*magM[k1]^4*magM[k2]^4 + 84*magM[k1]^2*magM[k2]^6)/
   (knl^2*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)), 
 -1/2772*(672*dot[k1, k2]^2*magM[k1]^2*magM[k2]^2 + 
    1344*f1*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2 + 
    2688*f1*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*
     magM[k2]^2 + 1344*f1*dot[k1, k2]*dot[k2, hat[z]]^2*magM[k1]^2*
     magM[k2]^2 + 672*dot[k1, k2]*magM[k1]^4*magM[k2]^2 + 
    672*f1*dot[k1, hat[z]]^2*magM[k1]^4*magM[k2]^2 + 
    1344*f1*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^4*magM[k2]^2 + 
    672*f1*dot[k2, hat[z]]^2*magM[k1]^4*magM[k2]^2 + 
    168*magM[k1]^6*magM[k2]^2 + 672*dot[k1, k2]*magM[k1]^2*magM[k2]^4 + 
    672*f1*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^4 + 
    1344*f1*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*magM[k2]^4 + 
    672*f1*dot[k2, hat[z]]^2*magM[k1]^2*magM[k2]^4 + 
    336*magM[k1]^4*magM[k2]^4 + 168*magM[k1]^2*magM[k2]^6)/
   (knl^2*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)), 
 -1/2772*(1386*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]^4 + 
    2772*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]^3*dot[k2, hat[z]] + 
    1386*f1^3*dot[k1, k2]*dot[k1, hat[z]]^5*dot[k2, hat[z]] + 
    2772*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2 + 
    5544*f1^3*dot[k1, k2]*dot[k1, hat[z]]^4*dot[k2, hat[z]]^2 + 
    2772*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]*dot[k2, hat[z]]^3 + 
    8316*f1^3*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]^3 + 
    1386*f1^2*dot[k1, k2]^2*dot[k2, hat[z]]^4 + 5544*f1^3*dot[k1, k2]*
     dot[k1, hat[z]]^2*dot[k2, hat[z]]^4 + 1386*f1^3*dot[k1, k2]*
     dot[k1, hat[z]]*dot[k2, hat[z]]^5 + 693*f1^2*dot[k1, k2]*
     dot[k1, hat[z]]^4*magM[k1]^2 + 1386*f1^2*dot[k1, k2]*dot[k1, hat[z]]^3*
     dot[k2, hat[z]]*magM[k1]^2 + 693*f1^3*dot[k1, hat[z]]^5*dot[k2, hat[z]]*
     magM[k1]^2 + 1386*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
     magM[k1]^2 + 2772*f1^3*dot[k1, hat[z]]^4*dot[k2, hat[z]]^2*magM[k1]^2 + 
    1386*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k1]^2 + 
    4158*f1^3*dot[k1, hat[z]]^3*dot[k2, hat[z]]^3*magM[k1]^2 + 
    693*f1^2*dot[k1, k2]*dot[k2, hat[z]]^4*magM[k1]^2 + 
    2772*f1^3*dot[k1, hat[z]]^2*dot[k2, hat[z]]^4*magM[k1]^2 + 
    693*f1^3*dot[k1, hat[z]]*dot[k2, hat[z]]^5*magM[k1]^2 + 
    693*f1^2*dot[k1, k2]*dot[k1, hat[z]]^4*magM[k2]^2 + 
    1386*f1^2*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2 + 
    693*f1^3*dot[k1, hat[z]]^5*dot[k2, hat[z]]*magM[k2]^2 + 
    1386*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k2]^2 + 
    2772*f1^3*dot[k1, hat[z]]^4*dot[k2, hat[z]]^2*magM[k2]^2 + 
    1386*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k2]^2 + 
    4158*f1^3*dot[k1, hat[z]]^3*dot[k2, hat[z]]^3*magM[k2]^2 + 
    693*f1^2*dot[k1, k2]*dot[k2, hat[z]]^4*magM[k2]^2 + 
    2772*f1^3*dot[k1, hat[z]]^2*dot[k2, hat[z]]^4*magM[k2]^2 + 
    693*f1^3*dot[k1, hat[z]]*dot[k2, hat[z]]^5*magM[k2]^2)/
   (knl^2*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)), 
 -1/2772*(-990*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]^4 - 
    1188*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]^3*dot[k2, hat[z]] - 
    396*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2 - 
    1188*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]*dot[k2, hat[z]]^3 - 
    990*f1^2*dot[k1, k2]^2*dot[k2, hat[z]]^4 + 1386*f1^2*dot[k1, k2]*
     dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k1]^2 + 
    2772*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^2 + 
    1386*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k1]^2 + 
    1386*f1^2*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2 + 
    2772*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k2]^2 + 
    1386*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k2]^2 + 
    990*f1^2*dot[k1, hat[z]]^4*magM[k1]^2*magM[k2]^2 + 
    3960*f1^2*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k1]^2*magM[k2]^2 + 
    5940*f1^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^2*magM[k2]^2 + 
    3960*f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k1]^2*magM[k2]^2 + 
    990*f1^2*dot[k2, hat[z]]^4*magM[k1]^2*magM[k2]^2)/
   (knl^2*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)), 
 -1/2772*(1386*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]^2*magM[k1]^2 + 
    2772*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2 + 
    1386*f1^3*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k1]^2 + 
    1386*f1^2*dot[k1, k2]^2*dot[k2, hat[z]]^2*magM[k1]^2 + 
    4158*f1^3*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^2 + 
    4158*f1^3*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k1]^2 + 
    1386*f1^3*dot[k1, k2]*dot[k2, hat[z]]^4*magM[k1]^2 + 
    693*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^4 + 
    1386*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^4 + 
    693*f1^3*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k1]^4 + 
    693*f1^2*dot[k1, k2]*dot[k2, hat[z]]^2*magM[k1]^4 + 
    2079*f1^3*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^4 + 
    2079*f1^3*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k1]^4 + 
    693*f1^3*dot[k2, hat[z]]^4*magM[k1]^4 + 1386*f1^2*dot[k1, k2]^2*
     dot[k1, hat[z]]^2*magM[k2]^2 + 1386*f1^3*dot[k1, k2]*dot[k1, hat[z]]^4*
     magM[k2]^2 + 2772*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]*dot[k2, hat[z]]*
     magM[k2]^2 + 4158*f1^3*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*
     magM[k2]^2 + 1386*f1^2*dot[k1, k2]^2*dot[k2, hat[z]]^2*magM[k2]^2 + 
    4158*f1^3*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k2]^2 + 
    1386*f1^3*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k2]^2 + 
    1386*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2 + 
    693*f1^3*dot[k1, hat[z]]^4*magM[k1]^2*magM[k2]^2 + 
    2772*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*
     magM[k2]^2 + 2772*f1^3*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k1]^2*
     magM[k2]^2 + 1386*f1^2*dot[k1, k2]*dot[k2, hat[z]]^2*magM[k1]^2*
     magM[k2]^2 + 4158*f1^3*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^2*
     magM[k2]^2 + 2772*f1^3*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k1]^2*
     magM[k2]^2 + 693*f1^3*dot[k2, hat[z]]^4*magM[k1]^2*magM[k2]^2 + 
    693*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k2]^4 + 
    693*f1^3*dot[k1, hat[z]]^4*magM[k2]^4 + 1386*f1^2*dot[k1, k2]*
     dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^4 + 2079*f1^3*dot[k1, hat[z]]^3*
     dot[k2, hat[z]]*magM[k2]^4 + 693*f1^2*dot[k1, k2]*dot[k2, hat[z]]^2*
     magM[k2]^4 + 2079*f1^3*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k2]^4 + 
    693*f1^3*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k2]^4)/
   (knl^2*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)), 
 -1/2772*(792*f1^2*dot[k1, k2]^3*dot[k1, hat[z]]^2 + 
    1584*f1^2*dot[k1, k2]^3*dot[k1, hat[z]]*dot[k2, hat[z]] + 
    792*f1^2*dot[k1, k2]^3*dot[k2, hat[z]]^2 + 396*f1^2*dot[k1, k2]^2*
     dot[k1, hat[z]]^2*magM[k1]^2 + 792*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]*
     dot[k2, hat[z]]*magM[k1]^2 + 396*f1^2*dot[k1, k2]^2*dot[k2, hat[z]]^2*
     magM[k1]^2 + 396*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]^2*magM[k2]^2 + 
    792*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k2]^2 + 
    396*f1^2*dot[k1, k2]^2*dot[k2, hat[z]]^2*magM[k2]^2 + 
    1980*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2 + 
    3960*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*
     magM[k2]^2 + 1980*f1^2*dot[k1, k2]*dot[k2, hat[z]]^2*magM[k1]^2*
     magM[k2]^2 + 990*f1^2*dot[k1, hat[z]]^2*magM[k1]^4*magM[k2]^2 + 
    1980*f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^4*magM[k2]^2 + 
    990*f1^2*dot[k2, hat[z]]^2*magM[k1]^4*magM[k2]^2 + 
    990*f1^2*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^4 + 
    1980*f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*magM[k2]^4 + 
    990*f1^2*dot[k2, hat[z]]^2*magM[k1]^2*magM[k2]^4)/
   (knl^2*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)), 
 -1/2772*(1386*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*
     magM[k1]^2 + 2772*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]^3*
     magM[k1]^2 + 1386*f1^2*dot[k1, k2]*dot[k2, hat[z]]^4*magM[k1]^2 + 
    693*f1^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^4 + 
    1386*f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k1]^4 + 
    693*f1^2*dot[k2, hat[z]]^4*magM[k1]^4 + 1386*f1^2*dot[k1, k2]*
     dot[k1, hat[z]]^4*magM[k2]^2 + 2772*f1^2*dot[k1, k2]*dot[k1, hat[z]]^3*
     dot[k2, hat[z]]*magM[k2]^2 + 1386*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*
     dot[k2, hat[z]]^2*magM[k2]^2 + 693*f1^2*dot[k1, hat[z]]^4*magM[k1]^2*
     magM[k2]^2 + 1386*f1^2*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k1]^2*
     magM[k2]^2 + 1386*f1^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^2*
     magM[k2]^2 + 1386*f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k1]^2*
     magM[k2]^2 + 693*f1^2*dot[k2, hat[z]]^4*magM[k1]^2*magM[k2]^2 + 
    693*f1^2*dot[k1, hat[z]]^4*magM[k2]^4 + 1386*f1^2*dot[k1, hat[z]]^3*
     dot[k2, hat[z]]*magM[k2]^4 + 693*f1^2*dot[k1, hat[z]]^2*
     dot[k2, hat[z]]^2*magM[k2]^4)/(knl^2*magM[k1]^2*magM[k2]^2*
    (2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)), 
 -1/2772*(2772*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]^3*dot[k2, hat[z]] + 
    5544*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2 + 
    2772*f1^2*dot[k1, k2]^2*dot[k1, hat[z]]*dot[k2, hat[z]]^3 + 
    1386*f1^2*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k1]^2 + 
    2772*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k1]^2 + 
    1386*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k1]^2 + 
    1386*f1^2*dot[k1, k2]*dot[k1, hat[z]]^3*dot[k2, hat[z]]*magM[k2]^2 + 
    2772*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*dot[k2, hat[z]]^2*magM[k2]^2 + 
    1386*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]^3*magM[k2]^2)/
   (knl^2*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)), 
 -1/2772*(2772*f1^2*dot[k1, k2]*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^2 + 
    5544*f1^2*dot[k1, k2]*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*
     magM[k2]^2 + 2772*f1^2*dot[k1, k2]*dot[k2, hat[z]]^2*magM[k1]^2*
     magM[k2]^2 + 1386*f1^2*dot[k1, hat[z]]^2*magM[k1]^4*magM[k2]^2 + 
    2772*f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^4*magM[k2]^2 + 
    1386*f1^2*dot[k2, hat[z]]^2*magM[k1]^4*magM[k2]^2 + 
    1386*f1^2*dot[k1, hat[z]]^2*magM[k1]^2*magM[k2]^4 + 
    2772*f1^2*dot[k1, hat[z]]*dot[k2, hat[z]]*magM[k1]^2*magM[k2]^4 + 
    1386*f1^2*dot[k2, hat[z]]^2*magM[k1]^2*magM[k2]^4)/
   (knl^2*magM[k1]^2*magM[k2]^2*(2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2))}
